"""
api/main_fastapi.py
Modul 6: Dashboard icin REST ve WebSocket API endpoints.

DEMO_MODE=true iken uygulama, SimulatedMarketDataSource + InMemoryPubSub
ile HICBIR harici servise (Redis, gercek borsa baglantisi) ihtiyac
duymadan calisir. Calistirmak icin:

    uvicorn api.main_fastapi:app --reload
"""
from __future__ import annotations

import asyncio
import json
from contextlib import asynccontextmanager
from typing import Dict, List, Optional

from fastapi import FastAPI, WebSocket, WebSocketDisconnect

from config.logging_config import configure_logging, get_logger
from config.settings import settings
from core.analytics.institutional import InstitutionalTracker
from core.analytics.spoofing_detector import SpoofingDetector
from core.ingestion.data_parser import parse_akd, parse_order_book, parse_order_event
from core.ingestion.websocket_client import SimulatedMarketDataSource
from db.postgres_models import AlertRecord, init_db
from db.redis_client import get_pubsub_client
from models.schemas import Alert

configure_logging()
logger = get_logger(__name__)

ALERT_CHANNEL = "bist:alerts"

detectors: Dict[str, SpoofingDetector] = {s: SpoofingDetector(s) for s in settings.tracked_symbols}
trackers: Dict[str, InstitutionalTracker] = {s: InstitutionalTracker(symbol=s) for s in settings.tracked_symbols}
pubsub = get_pubsub_client(settings.demo_mode, settings.redis_url)
SessionLocal = init_db(settings.database_url)

recent_alerts: List[Alert] = []
latest_books: Dict[str, dict] = {}
latest_akd: Dict[str, dict] = {}

_ingestion_task: Optional[asyncio.Task] = None


def _persist_alert(alert: Alert) -> None:
    """Alarmi veritabanina yazar (demo modda SQLite, uretimde PostgreSQL). Hata
    ana akisi kesmemeli - sadece loglanir."""
    try:
        with SessionLocal() as session:
            session.add(AlertRecord(
                symbol=alert.symbol,
                alert_type=alert.type.value,
                severity=alert.severity.value,
                message=alert.message,
                timestamp=alert.timestamp,
            ))
            session.commit()
    except Exception as exc:  # noqa: BLE001
        logger.warning("Alarm veritabanina yazilamadi: %s", exc)


async def _publish_alert(alert: Alert) -> None:
    recent_alerts.append(alert)
    del recent_alerts[:-200]  # bellekte sadece son 200 alarm tutulur
    _persist_alert(alert)
    await pubsub.publish(ALERT_CHANNEL, json.loads(alert.model_dump_json()))
    logger.info("ALARM: %s", alert.message)


async def _ingestion_loop() -> None:
    if not settings.demo_mode:
        logger.warning(
            "DEMO_MODE=false ayarlanmis ama gercek bir MarketDataSource "
            "baglanmadi. Bu fonksiyon icinde BISTWebSocketClient'i kendi "
            "saglayici bilgilerinizle olusturup kullanmaniz gerekiyor "
            "(core/ingestion/websocket_client.py)."
        )
        return

    source = SimulatedMarketDataSource(symbols=settings.tracked_symbols)
    async for message in source.stream():
        channel = message.get("channel")
        payload = message.get("payload", {})
        symbol = payload.get("symbol")
        if symbol is None:
            continue

        if channel == "order_book":
            book = parse_order_book(payload)
            latest_books[symbol] = payload
            for alert in detectors[symbol].on_book_update(book):
                await _publish_alert(alert)

        elif channel == "order_event":
            event = parse_order_event(payload)
            for alert in detectors[symbol].on_order_event(event):
                await _publish_alert(alert)

        elif channel == "akd":
            akd = parse_akd(payload)
            latest_akd[symbol] = payload
            alert = trackers[symbol].ingest(akd)
            if alert:
                await _publish_alert(alert)


@asynccontextmanager
async def lifespan(app: FastAPI):
    global _ingestion_task
    _ingestion_task = asyncio.create_task(_ingestion_loop())
    logger.info("BIST-AlgoTracker API baslatildi (demo_mode=%s)", settings.demo_mode)
    yield
    if _ingestion_task:
        _ingestion_task.cancel()


app = FastAPI(title="BIST-AlgoTracker API", lifespan=lifespan)


@app.get("/health")
async def health():
    return {"status": "ok", "demo_mode": settings.demo_mode, "symbols": settings.tracked_symbols}


@app.get("/alerts")
async def get_alerts(limit: int = 50):
    return [json.loads(a.model_dump_json()) for a in recent_alerts[-limit:]]


@app.get("/orderbook/{symbol}")
async def get_orderbook(symbol: str):
    return latest_books.get(symbol, {})


@app.get("/akd/{symbol}")
async def get_akd(symbol: str):
    return latest_akd.get(symbol, {})


@app.get("/symbols")
async def get_symbols():
    return settings.tracked_symbols


@app.websocket("/ws/alerts")
async def ws_alerts(websocket: WebSocket):
    await websocket.accept()
    try:
        async for message in pubsub.subscribe(ALERT_CHANNEL):
            await websocket.send_json(message)
    except WebSocketDisconnect:
        logger.info("Dashboard baglantisi kesildi (/ws/alerts).")
