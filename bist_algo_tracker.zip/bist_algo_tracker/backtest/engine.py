"""
backtest/engine.py
Modul 7: BacktestEngine - HistoricalDataPlayer'dan gelen mesajlari
CANLI sistemle AYNI analitik hattindan (SpoofingDetector,
InstitutionalTracker) gecirir; boylece "canliya gecmeden once" ayni
mantik test edilmis olur.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, Iterable, List

from core.analytics.institutional import InstitutionalTracker
from core.analytics.spoofing_detector import SpoofingDetector
from core.execution.order_manager import PaperBrokerAdapter
from core.execution.risk_engine import RiskEngine
from core.ingestion.data_parser import parse_akd, parse_order_book, parse_order_event
from models.schemas import Alert


@dataclass
class BacktestSummary:
    symbol: str
    tick_count: int
    alert_count: int
    alerts_by_type: Dict[str, int] = field(default_factory=dict)


class BacktestEngine:
    def __init__(self, symbols: List[str]) -> None:
        self.detectors: Dict[str, SpoofingDetector] = {s: SpoofingDetector(s) for s in symbols}
        self.institutional: Dict[str, InstitutionalTracker] = {s: InstitutionalTracker(symbol=s) for s in symbols}
        self.risk_engine = RiskEngine()
        self.broker = PaperBrokerAdapter()
        self.alerts: List[Alert] = []

    def run(self, messages: Iterable[Dict]) -> BacktestSummary:
        tick_count = 0
        symbols_seen: List[str] = []

        for msg in messages:
            channel = msg.get("channel")
            payload = msg.get("payload", {})
            symbol = payload.get("symbol")
            if symbol is None:
                continue
            if symbol not in symbols_seen:
                symbols_seen.append(symbol)

            detector = self.detectors.setdefault(symbol, SpoofingDetector(symbol))
            tracker = self.institutional.setdefault(symbol, InstitutionalTracker(symbol=symbol))

            if channel == "order_book":
                book = parse_order_book(payload)
                self.alerts.extend(detector.on_book_update(book))
                tick_count += 1
            elif channel == "order_event":
                event = parse_order_event(payload)
                self.alerts.extend(detector.on_order_event(event))
            elif channel == "akd":
                akd = parse_akd(payload)
                alert = tracker.ingest(akd)
                if alert:
                    self.alerts.append(alert)

        alerts_by_type: Dict[str, int] = {}
        for alert in self.alerts:
            alerts_by_type[alert.type.value] = alerts_by_type.get(alert.type.value, 0) + 1

        return BacktestSummary(
            symbol=symbols_seen[0] if symbols_seen else "N/A",
            tick_count=tick_count,
            alert_count=len(self.alerts),
            alerts_by_type=alerts_by_type,
        )
