from datetime import datetime, timezone

from core.analytics.spoofing_detector import SpoofingDetector
from models.schemas import AlertType, OrderBookLevel, OrderBookSnapshot, OrderEvent, Side


def _ts(offset: float = 0.0) -> datetime:
    return datetime.fromtimestamp(1_700_000_000 + offset, tz=timezone.utc)


def test_spoofing_alarm_on_repeated_large_order_flicker():
    detector = SpoofingDetector("TEST", dwell_flicker_seconds=0.5)
    alerts = []
    for i in range(3):
        placed = OrderEvent(
            symbol="TEST", order_id=f"o{i}", side=Side.BID, price=100.0,
            lot=60_000, timestamp=_ts(i), event_type="PLACED",
        )
        detector.on_order_event(placed)
        canceled = OrderEvent(
            symbol="TEST", order_id=f"o{i}", side=Side.BID, price=100.0,
            lot=60_000, timestamp=_ts(i + 0.2), event_type="CANCELED",
        )
        alerts.extend(detector.on_order_event(canceled))
    assert any(a.type == AlertType.SPOOFING_ALARM for a in alerts)


def test_no_alarm_for_genuine_execution():
    detector = SpoofingDetector("TEST")
    placed = OrderEvent(
        symbol="TEST", order_id="o1", side=Side.BID, price=100.0,
        lot=60_000, timestamp=_ts(0), event_type="PLACED",
    )
    detector.on_order_event(placed)
    executed = OrderEvent(
        symbol="TEST", order_id="o1", side=Side.BID, price=100.0,
        lot=60_000, timestamp=_ts(0.1), event_type="EXECUTED",
    )
    alerts = detector.on_order_event(executed)
    assert not any(a.type == AlertType.SPOOFING_ALARM for a in alerts)


def test_sahte_likidite_flag_on_high_otr_without_execution():
    detector = SpoofingDetector("TEST", otr_threshold=0.90)
    alerts = []
    # Ayni kademede defalarca buyuk lot iptal edilsin, hic gerceklesme olmasin.
    for i in range(5):
        placed = OrderEvent(
            symbol="TEST", order_id=f"p{i}", side=Side.ASK, price=50.0,
            lot=10_000, timestamp=_ts(i), event_type="PLACED",
        )
        detector.on_order_event(placed)
        canceled = OrderEvent(
            symbol="TEST", order_id=f"p{i}", side=Side.ASK, price=50.0,
            lot=10_000, timestamp=_ts(i + 2.0), event_type="CANCELED",  # flicker esiginin ustunde bekleme
        )
        alerts.extend(detector.on_order_event(canceled))
    assert any(a.type == AlertType.SAHTE_LIKIDITE for a in alerts)


def test_no_sahte_likidite_when_execution_is_significant():
    detector = SpoofingDetector("TEST", otr_threshold=0.90)
    alerts = []
    placed = OrderEvent(
        symbol="TEST", order_id="e1", side=Side.ASK, price=50.0,
        lot=10_000, timestamp=_ts(0), event_type="PLACED",
    )
    detector.on_order_event(placed)
    executed = OrderEvent(
        symbol="TEST", order_id="e1", side=Side.ASK, price=50.0,
        lot=9_000, timestamp=_ts(1), event_type="EXECUTED",
    )
    alerts.extend(detector.on_order_event(executed))
    canceled = OrderEvent(
        symbol="TEST", order_id="e1", side=Side.ASK, price=50.0,
        lot=1_000, timestamp=_ts(2), event_type="CANCELED",
    )
    alerts.extend(detector.on_order_event(canceled))
    assert not any(a.type == AlertType.SAHTE_LIKIDITE for a in alerts)


def test_obi_spoofing_warning_via_book_updates():
    detector = SpoofingDetector("TEST", obi_threshold=0.80)
    alerts = []
    for i in range(12):
        book = OrderBookSnapshot(
            symbol="TEST", timestamp=_ts(i),
            bids=[OrderBookLevel(price=99.0, lot=950)],
            asks=[OrderBookLevel(price=100.0, lot=50)],
        )
        alerts.extend(detector.on_book_update(book))
    assert any(a.type == AlertType.SPOOFING_UYARISI for a in alerts)


def test_no_obi_warning_when_price_rises_with_book():
    detector = SpoofingDetector("TEST", obi_threshold=0.80)
    alerts = []
    price = 99.0
    for i in range(12):
        price += 0.5
        book = OrderBookSnapshot(
            symbol="TEST", timestamp=_ts(i),
            bids=[OrderBookLevel(price=price, lot=950)],
            asks=[OrderBookLevel(price=price + 1, lot=50)],
        )
        alerts.extend(detector.on_book_update(book))
    assert not any(a.type == AlertType.SPOOFING_UYARISI for a in alerts)
