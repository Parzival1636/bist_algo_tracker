from core.analytics.metrics import (
    DwellTimeTracker,
    OBIPriceTracker,
    OrderFlowWindow,
    compute_obi,
    compute_otr,
)


def test_compute_obi_balanced():
    assert compute_obi(100, 100) == 0.0


def test_compute_obi_bid_heavy():
    assert compute_obi(300, 100) == 0.5


def test_compute_obi_zero_volume():
    assert compute_obi(0, 0) == 0.0


def test_compute_otr_basic():
    assert compute_otr(90, 100) == 0.9


def test_compute_otr_no_execution_with_cancels():
    assert compute_otr(500, 0) == float("inf")


def test_compute_otr_no_activity():
    assert compute_otr(0, 0) == 0.0


def test_order_flow_window_rolling():
    window = OrderFlowWindow(symbol="TEST", price_level=10.0)
    window.record_cancel(1000)
    window.record_execution(50)
    assert window.total_canceled == 1000
    assert window.total_executed == 50
    assert window.otr == 20.0


def test_dwell_time_tracker_triggers_alarm_on_repeated_flicker():
    tracker = DwellTimeTracker(
        large_order_lot=50_000, flicker_seconds=0.5,
        repeat_window_seconds=5.0, repeat_count_for_alarm=3,
    )
    ts = 1000.0
    alarm = False
    for i in range(3):
        tracker.on_order_placed(f"o{i}", price_level=100.0, lot=60_000, ts=ts)
        alarm = tracker.on_order_canceled(f"o{i}", ts=ts + 0.2)  # 0.2s < 0.5s esik
        ts += 0.5
    assert alarm is True


def test_dwell_time_tracker_no_alarm_for_normal_dwell():
    tracker = DwellTimeTracker()
    tracker.on_order_placed("o1", price_level=100.0, lot=60_000, ts=1000.0)
    alarm = tracker.on_order_canceled("o1", ts=1005.0)  # 5s bekleme -> flicker degil
    assert alarm is False


def test_dwell_time_tracker_ignores_small_orders():
    tracker = DwellTimeTracker(large_order_lot=50_000)
    tracker.on_order_placed("o1", price_level=100.0, lot=1000, ts=1000.0)  # esik altinda
    alarm = tracker.on_order_canceled("o1", ts=1000.1)
    assert alarm is False


def test_dwell_time_tracker_execution_does_not_count_as_flicker():
    tracker = DwellTimeTracker(
        large_order_lot=50_000, flicker_seconds=0.5, repeat_count_for_alarm=2,
    )
    ts = 1000.0
    for i in range(5):
        tracker.on_order_placed(f"o{i}", price_level=100.0, lot=60_000, ts=ts)
        tracker.on_order_executed(f"o{i}", ts=ts + 0.1)  # hizli GERCEKLESME - spoofing degil
        ts += 0.5
    # Ayni fiyat seviyesinde artik iptal olayi olmadigi icin alarm hicbir zaman True olmamali
    alarm = tracker.on_order_canceled("nonexistent", ts=ts)
    assert alarm is False


def test_obi_price_tracker_flags_sustained_imbalance_without_price_move():
    tracker = OBIPriceTracker(threshold=0.8, lookback=5)
    triggered = False
    price = 100.0
    for _ in range(5):
        triggered = tracker.update(obi=0.85, mid_price=price)
    assert triggered is True


def test_obi_price_tracker_does_not_flag_when_price_rises():
    tracker = OBIPriceTracker(threshold=0.8, lookback=5)
    triggered = False
    price = 100.0
    for _ in range(5):
        price += 1
        triggered = tracker.update(obi=0.85, mid_price=price)
    assert triggered is False


def test_obi_price_tracker_needs_full_lookback():
    tracker = OBIPriceTracker(threshold=0.8, lookback=5)
    triggered = tracker.update(obi=0.9, mid_price=100.0)
    assert triggered is False  # henuz lookback dolmadi
