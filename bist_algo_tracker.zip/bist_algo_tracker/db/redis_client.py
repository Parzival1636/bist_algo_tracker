"""
db/redis_client.py
Modul 1/6: Redis Pub/Sub katmani (anlik derinlik ve AKD yayini icin).

DEMO_MODE=true iken gercek bir Redis sunucusu GEREKMEZ: InMemoryPubSub
ayni arayuzu bellek icinde saglar, boylece tum sistem tek bir Redis
kurulumu yapmadan da uctan uca calisir. Uretimde get_pubsub_client()
otomatik olarak RedisPubSub'a gecer.
"""
from __future__ import annotations

import asyncio
import json
from typing import Any, AsyncIterator, Dict, List, Protocol, Union


class PubSubClient(Protocol):
    async def publish(self, channel: str, message: Dict[str, Any]) -> None: ...
    def subscribe(self, channel: str) -> AsyncIterator[Dict[str, Any]]: ...


class InMemoryPubSub:
    """Redis olmadan calisan, tek-process bellek ici pub/sub (demo mode)."""

    def __init__(self) -> None:
        self._queues: Dict[str, List[asyncio.Queue]] = {}

    async def publish(self, channel: str, message: Dict[str, Any]) -> None:
        for queue in self._queues.get(channel, []):
            await queue.put(message)

    async def subscribe(self, channel: str) -> AsyncIterator[Dict[str, Any]]:
        queue: asyncio.Queue = asyncio.Queue()
        self._queues.setdefault(channel, []).append(queue)
        try:
            while True:
                yield await queue.get()
        finally:
            self._queues[channel].remove(queue)


class RedisPubSub:
    """Gercek Redis baglantisi (redis.asyncio uzerinden)."""

    def __init__(self, redis_url: str) -> None:
        self.redis_url = redis_url
        self._redis = None

    async def _get_client(self):
        if self._redis is None:
            import redis.asyncio as redis  # yerel import: sadece gercek modda gerekli
            self._redis = redis.from_url(self.redis_url, decode_responses=True)
        return self._redis

    async def publish(self, channel: str, message: Dict[str, Any]) -> None:
        client = await self._get_client()
        await client.publish(channel, json.dumps(message))

    async def subscribe(self, channel: str) -> AsyncIterator[Dict[str, Any]]:
        client = await self._get_client()
        pubsub = client.pubsub()
        await pubsub.subscribe(channel)
        try:
            async for message in pubsub.listen():
                if message["type"] == "message":
                    yield json.loads(message["data"])
        finally:
            await pubsub.unsubscribe(channel)


def get_pubsub_client(demo_mode: bool, redis_url: str) -> Union[InMemoryPubSub, RedisPubSub]:
    if demo_mode:
        return InMemoryPubSub()
    return RedisPubSub(redis_url)
