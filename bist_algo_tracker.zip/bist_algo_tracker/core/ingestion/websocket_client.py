"""
core/ingestion/websocket_client.py
Modul 1: Canli Veri Akisi ve Veri Toplama (Data Ingestion Engine)

Iki implementasyon icerir:

  1) SimulatedMarketDataSource - gercek veri gerektirmez; demo mode,
     dashboard ve backtest icin varsayilan kaynak. Rastgele-yuruyus
     (random-walk) fiyat + Duzey2 + AKD verisi + ara sira "yapay
     likidite" senaryolari uretir (boylece spoofing_detector.py'nin
     uctan uca calistigini gorebilirsiniz).

  2) BISTWebSocketClient - gercek bir saglayiciya (Matriks, İdeal Data,
     Borsa Istanbul BISTECH/VERDA, vb.) baglanmak icin ISKELET.
     Baglanti/yeniden-baglanma mantigi hazirdir; ANCAK mesaj ayristirma
     (`_parse_raw_message`) saglayiciya OZELDIR ve burada tahmin
     edilerek YAZILMAMISTIR - yanlis varsayilan bir sema, sessizce
     hatali analiz sonuclarina yol acabilir. Kendi saglayicinizin
     dokumantasyonuna gore doldurun.
"""
from __future__ import annotations

import asyncio
import json
import random
from abc import ABC, abstractmethod
from collections import deque
from datetime import datetime, timezone
from typing import AsyncIterator, Deque, Dict, List, Optional

from config.logging_config import get_logger

logger = get_logger(__name__)

ROLLING_WINDOW = 1000  # spec: collections.deque ile max 1000 elemanli kayan pencere


class MarketDataSource(ABC):
    """Tum veri kaynaklarinin uyguladigi ortak arayuz."""

    @abstractmethod
    def stream(self) -> AsyncIterator[Dict]:
        """
        Ham (dict) mesajlari asenkron olarak, dondurmadan (non-blocking)
        uretir. Her mesaj `{"channel": "order_book"|"akd"|"order_event",
        "payload": {...}}` seklindedir.
        """
        raise NotImplementedError


class SimulatedMarketDataSource(MarketDataSource):
    """Gercekci bir random-walk fiyat + Duzey2 + AKD veri uretici (demo/test/backtest icin)."""

    INSTITUTIONS = ["BofA", "İş Yatırım", "Yatırım Finansman", "A1 Capital", "Garanti BBVA Yatırım"]

    def __init__(
        self,
        symbols: List[str],
        tick_interval_seconds: float = 0.25,
        seed: Optional[int] = None,
        realtime: bool = True,
    ) -> None:
        """
        realtime=False: gercek zamanli bekleme (asyncio.sleep) yapilmaz;
        HistoricalDataPlayer.generate_synthetic() gibi toplu/hizli veri
        uretimi icin kullanilir.
        """
        self.symbols = symbols
        self.tick_interval_seconds = tick_interval_seconds
        self.realtime = realtime
        # nosec B311: kriptografik olmayan sentetik veri uretimi icin kullanilir
        # (fiyat/lot simulasyonu) - guvenlik/kimlik dogrulama baglaminda DEGIL.
        self._rng = random.Random(seed)  # nosec B311
        self._prices: Dict[str, float] = {s: self._rng.uniform(20, 200) for s in symbols}
        self._order_windows: Dict[str, Deque[Dict]] = {s: deque(maxlen=ROLLING_WINDOW) for s in symbols}
        self._order_seq = 0

    async def _maybe_sleep(self, seconds: float) -> None:
        if self.realtime and seconds > 0:
            await asyncio.sleep(seconds)

    def _next_order_id(self) -> str:
        self._order_seq += 1
        return f"SIM-{self._order_seq}"

    def _make_book(self, symbol: str, mid: float, spoof_bias: bool) -> Dict:
        levels = 10
        tick = max(0.01, round(mid * 0.001, 2))
        bids, asks = [], []
        for i in range(levels):
            bid_lot = self._rng.uniform(100, 5000)
            ask_lot = self._rng.uniform(100, 5000)
            if spoof_bias and i == 0:
                bid_lot = self._rng.uniform(60_000, 120_000)  # yapay buyuk emir senaryosu
            bids.append({"price": round(mid - tick * (i + 1), 2), "lot": round(bid_lot)})
            asks.append({"price": round(mid + tick * (i + 1), 2), "lot": round(ask_lot)})
        return {
            "symbol": symbol,
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "bids": bids,
            "asks": asks,
        }

    def _make_akd(self, symbol: str) -> Dict:
        entries = []
        for inst in self.INSTITUTIONS:
            buy = self._rng.uniform(0, 50_000)
            sell = self._rng.uniform(0, 50_000)
            entries.append({
                "institution": inst,
                "buy_lot": round(buy),
                "sell_lot": round(sell),
                "avg_cost": round(self._prices[symbol], 2),
            })
        return {
            "symbol": symbol,
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "is_end_of_day": False,
            "entries": entries,
        }

    async def stream(self) -> AsyncIterator[Dict]:
        while True:
            for symbol in self.symbols:
                drift = self._rng.uniform(-0.3, 0.3)
                self._prices[symbol] = max(0.1, self._prices[symbol] + drift)
                spoof_bias = self._rng.random() < 0.05  # %5 ihtimalle yapay likidite senaryosu

                book = self._make_book(symbol, self._prices[symbol], spoof_bias)
                yield {"channel": "order_book", "payload": book}

                if spoof_bias:
                    order_id = self._next_order_id()
                    lot = book["bids"][0]["lot"]
                    price = book["bids"][0]["price"]
                    now = datetime.now(timezone.utc).isoformat()
                    yield {"channel": "order_event", "payload": {
                        "symbol": symbol, "order_id": order_id, "side": "BID", "price": price,
                        "lot": lot, "timestamp": now, "event_type": "PLACED",
                    }}
                    await self._maybe_sleep(0.1)  # 0.5sn esiginin altinda iptal edilecek
                    yield {"channel": "order_event", "payload": {
                        "symbol": symbol, "order_id": order_id, "side": "BID", "price": price,
                        "lot": lot, "timestamp": datetime.now(timezone.utc).isoformat(),
                        "event_type": "CANCELED",
                    }}

                if self._rng.random() < 0.3:
                    yield {"channel": "akd", "payload": self._make_akd(symbol)}

            await self._maybe_sleep(self.tick_interval_seconds)


class BISTWebSocketClient(MarketDataSource):
    """
    GERCEK saglayici baglantisi icin iskelet.

    Kullanmadan once:
      1) `url` ve `api_key` degerlerini .env / config/settings.py uzerinden
         saglayin (MARKET_DATA_WS_URL, MARKET_DATA_API_KEY).
      2) `_parse_raw_message` metodunu saglayicinizin GERCEK mesaj
         semasina gore doldurun (asagida NotImplementedError firlatiyor).
      3) Bazi saglayicilar header tabanli kimlik dogrulama ister; bu
         durumda `websockets.connect(...)` cagrisina kutuphane
         versiyonunuza uygun parametreyi (extra_headers / additional_headers)
         ekleyin. Bu implementasyon, cogu veri saglayicisinin kullandigi
         "baglan + auth mesaji gonder" desenini varsayar.
    """

    def __init__(self, url: str, api_key: Optional[str] = None, reconnect_delay: float = 2.0) -> None:
        self.url = url
        self.api_key = api_key
        self.reconnect_delay = reconnect_delay

    async def stream(self) -> AsyncIterator[Dict]:
        import websockets  # yerel import: sadece gercek modda gerekli

        while True:
            try:
                async with websockets.connect(self.url) as ws:
                    logger.info("Veri saglayiciya baglanildi: %s", self.url)
                    if self.api_key:
                        await ws.send(json.dumps({"action": "auth", "api_key": self.api_key}))
                    async for raw_message in ws:
                        parsed = self._parse_raw_message(raw_message)
                        if parsed is not None:
                            yield parsed
            except Exception as exc:  # noqa: BLE001 - baglanti kesilirse yeniden dene
                logger.warning(
                    "WebSocket baglantisi koptu (%s), %ss sonra tekrar denenecek.",
                    exc, self.reconnect_delay,
                )
                await asyncio.sleep(self.reconnect_delay)

    def _parse_raw_message(self, raw_message: str) -> Optional[Dict]:
        """
        TODO: Saglayicinizin gercek JSON/binary semasina gore doldurun.
        Beklenen cikti formati SimulatedMarketDataSource ile AYNI olmalidir:
          {"channel": "order_book" | "akd" | "order_event", "payload": {...}}
        """
        raise NotImplementedError(
            "BISTWebSocketClient._parse_raw_message henuz implemente edilmedi. "
            "Gercek veri saglayicinizin mesaj semasina gore doldurun."
        )
