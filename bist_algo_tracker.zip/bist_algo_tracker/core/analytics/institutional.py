"""
core/analytics/institutional.py
Modul 3: Kurumsal Takip ve Karanlik Oda (Kapanis Seansi) Modulu

- concentration_index / InstitutionalTracker: BofA vb. kurumlarin tek
  tarafli mi (yogunlasmis) yoksa dagitik mi (coklu kurum) alim yaptigini
  Herfindahl-Hirschman tarzi bir endeksle olcer.
- DarkRoomAnalyzer: 18:05-18:10 kapanis seansi eslesme verisini, ertesi
  gunun acilis korelasyonu icin saklar.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, time as dtime
from typing import Dict, List, Optional

from models.schemas import AKDSnapshot, Alert, AlertSeverity, AlertType


def concentration_index(net_positions: Dict[str, float]) -> float:
    """
    Herfindahl-Hirschman tarzi yogunlasma endeksi (sadece net ALICI
    kurumlar uzerinden hesaplanir).

      1.0       -> tek kurum baskin (tek tarafli birikim)
      1/N       -> N kurum arasinda esit dagitik birikim
      0.0       -> hic net alici yok

    Bu, spec'teki "BofA ve diger ana aktorlerin tek tarafli mi yoksa
    coklu kurumlar uzerinden dagitik mi islem yaptigini tespit et"
    gereksiniminin sayisal karsiligidir.
    """
    buyers = {k: v for k, v in net_positions.items() if v > 0}
    total = sum(buyers.values())
    if total <= 0:
        return 0.0
    return sum((v / total) ** 2 for v in buyers.values())


@dataclass
class InstitutionalTracker:
    """Sembol basina AKD gecmisini tutar ve yogunlasma tespit eder."""

    symbol: str
    concentration_threshold: float = 0.5  # bu deger ve uzerinde 'tek tarafli' kabul edilir
    _history: List[AKDSnapshot] = field(default_factory=list, init=False, repr=False)

    def ingest(self, snapshot: AKDSnapshot) -> Optional[Alert]:
        self._history.append(snapshot)
        net_positions = {e.institution: e.net_lot for e in snapshot.entries}
        hhi = concentration_index(net_positions)
        if hhi >= self.concentration_threshold:
            buyers = {k: v for k, v in net_positions.items() if v > 0}
            dominant = max(buyers.items(), key=lambda kv: kv[1])[0] if buyers else "Bilinmiyor"
            return Alert(
                type=AlertType.KURUMSAL_YOGUNLASMA,
                severity=AlertSeverity.INFO,
                symbol=self.symbol,
                message=(
                    f"{self.symbol} - Alim yogunlasmasi tek bir kuruma odaklanmis olabilir "
                    f"(baskin: {dominant}, HHI={hhi:.2f})."
                ),
                data={"hhi": hhi},
            )
        return None

    @property
    def latest(self) -> Optional[AKDSnapshot]:
        return self._history[-1] if self._history else None


def is_dark_room_session(
    dt: datetime, start_hour: int = 18, start_minute: int = 5, end_minute: int = 10
) -> bool:
    """Spec: Karanlik Oda (kapanis seansi) 18:05 - 18:10 arasi calisir."""
    t = dt.time()
    return dtime(start_hour, start_minute) <= t <= dtime(start_hour, end_minute)


@dataclass
class DarkRoomRecord:
    symbol: str
    timestamp: datetime
    match_price: float
    match_lot: float
    institution_net_changes: Dict[str, float] = field(default_factory=dict)


class DarkRoomAnalyzer:
    """
    Modul 3: Gun sonu karanlik oda esleşme verisini (fiyat, lot, kurum
    degisimleri) ertesi gunun acilis korelasyonu icin saklar.
    """

    def __init__(self) -> None:
        self._records: List[DarkRoomRecord] = []

    def record(self, dark_room_record: DarkRoomRecord) -> None:
        self._records.append(dark_room_record)

    def records_for_symbol(self, symbol: str) -> List[DarkRoomRecord]:
        return [r for r in self._records if r.symbol == symbol]

    @staticmethod
    def correlate_with_next_open(
        dark_room_net_imbalance: List[float], next_open_return_pct: List[float]
    ) -> Optional[float]:
        """
        Basit Pearson korelasyon katsayisi (numpy ile). En az 2 eslesen
        veri noktasi gerekir; aksi halde None doner.
        """
        if len(dark_room_net_imbalance) < 2 or len(dark_room_net_imbalance) != len(next_open_return_pct):
            return None
        import numpy as np

        matrix = np.corrcoef(dark_room_net_imbalance, next_open_return_pct)
        return float(matrix[0, 1])
