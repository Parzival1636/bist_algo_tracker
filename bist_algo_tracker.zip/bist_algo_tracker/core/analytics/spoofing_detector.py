"""
core/analytics/spoofing_detector.py
Modul 2: Anomali ve Spoofing (Tuzak) Tespit Motoru

Spec'teki 3 kurali birlestiren facade sinif:
  1) OTR > %90 ve gerceklesen islem yok/cok az -> SAHTE_LİKİDİTE
  2) OBI > +0.8 surdugu halde fiyat yukselmiyor -> SPOOFING_UYARISI (yemleme)
  3) 50.000+ lotluk emir < 0.5sn icinde silinip tekrarlaniyor -> SPOOFING_ALARM

SpoofingDetector sembol basina bir kez olusturulur; on_order_event() ve
on_book_update() cagrilarindan uretilen Alert nesneleri dogrudan
bildirim (Modul 8) ve veritabani (Modul 6/7) katmanlarina iletilebilir.
"""
from __future__ import annotations

from typing import Dict, List, Tuple

from core.analytics.metrics import DwellTimeTracker, OBIPriceTracker, OrderFlowWindow, compute_obi
from models.schemas import Alert, AlertSeverity, AlertType, OrderBookSnapshot, OrderEvent, Side


class SpoofingDetector:
    """Sembol basina calisan durum makinesi."""

    def __init__(
        self,
        symbol: str,
        otr_threshold: float = 0.90,
        obi_threshold: float = 0.80,
        large_order_lot_threshold: float = 50_000,
        dwell_flicker_seconds: float = 0.5,
    ) -> None:
        self.symbol = symbol
        self.otr_threshold = otr_threshold
        self._flow_windows: Dict[Tuple[float, Side], OrderFlowWindow] = {}
        self._obi_tracker = OBIPriceTracker(threshold=obi_threshold)
        self._dwell_tracker = DwellTimeTracker(
            large_order_lot=large_order_lot_threshold,
            flicker_seconds=dwell_flicker_seconds,
        )
        # Ayni kademeyi tekrar tekrar SAHTE_LİKİDİTE olarak raporlamamak icin
        # basit bir "zaten bildirildi" bayragi (gercek islem gorulunce temizlenir).
        self._flagged_levels: Dict[Tuple[float, Side], bool] = {}

    def _get_window(self, price: float, side: Side) -> OrderFlowWindow:
        key = (price, side)
        if key not in self._flow_windows:
            self._flow_windows[key] = OrderFlowWindow(self.symbol, price)
        return self._flow_windows[key]

    def on_order_event(self, event: OrderEvent) -> List[Alert]:
        alerts: List[Alert] = []
        window = self._get_window(event.price, event.side)
        key = (event.price, event.side)
        ts = event.timestamp.timestamp()

        if event.event_type == "PLACED":
            self._dwell_tracker.on_order_placed(event.order_id, event.price, event.lot, ts)

        elif event.event_type == "CANCELED":
            window.record_cancel(event.lot)

            if self._dwell_tracker.on_order_canceled(event.order_id, ts):
                alerts.append(Alert(
                    type=AlertType.SPOOFING_ALARM,
                    severity=AlertSeverity.CRITICAL,
                    symbol=self.symbol,
                    message=(
                        f"{self.symbol} - {event.price:g} kademesinde {event.lot:,.0f} lotluk "
                        f"emir tekrar tekrar hizli iptal edildi (SPOOFING_ALARM)."
                    ),
                    data={"price": event.price, "lot": event.lot},
                ))

            otr = window.otr
            executed = window.total_executed
            canceled = window.total_canceled
            # "gerceklesen islem olmadan surekli emir siliniyorsa": gerceklesen
            # hacim, iptal edilen hacmin %10'undan azsa "ihmal edilebilir" kabul edilir.
            negligible_execution = executed < canceled * 0.1
            if otr > self.otr_threshold and negligible_execution and not self._flagged_levels.get(key):
                self._flagged_levels[key] = True
                alerts.append(Alert(
                    type=AlertType.SAHTE_LIKIDITE,
                    severity=AlertSeverity.WARNING,
                    symbol=self.symbol,
                    message=(
                        f"{self.symbol} - {event.price:g} kademesi SAHTE_LİKİDİTE olarak "
                        f"isaretlendi (OTR={'sonsuz' if otr == float('inf') else f'{otr:.2f}'})."
                    ),
                    data={"price": event.price, "otr": -1.0 if otr == float("inf") else otr},
                ))

        elif event.event_type == "EXECUTED":
            window.record_execution(event.lot)
            self._dwell_tracker.on_order_executed(event.order_id, ts)
            self._flagged_levels[key] = False  # gercek islem oldu, isaretlemeyi temizle

        return alerts

    def on_book_update(self, snapshot: OrderBookSnapshot) -> List[Alert]:
        alerts: List[Alert] = []
        obi = compute_obi(snapshot.total_bid_volume, snapshot.total_ask_volume)
        mid = snapshot.mid_price
        if mid is not None:
            triggered = self._obi_tracker.update(obi, mid)
            if triggered:
                alerts.append(Alert(
                    type=AlertType.SPOOFING_UYARISI,
                    severity=AlertSeverity.WARNING,
                    symbol=self.symbol,
                    message=(
                        f"{self.symbol} - OBI {obi:+.2f} seviyesinde surdugu halde fiyat "
                        f"yukselmedi (olasi yemleme)."
                    ),
                    data={"obi": obi, "mid_price": mid},
                ))
        return alerts
