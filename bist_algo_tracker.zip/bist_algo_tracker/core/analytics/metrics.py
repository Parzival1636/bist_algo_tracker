"""
core/analytics/metrics.py
Modul 2: Anomali ve Spoofing (Tuzak) Tespit Motoru - Temel Metrikler

Bu modul, spoofing_detector.py tarafindan kullanilan 3 temel metrigi
hesaplar:
  - OTR  (Order-to-Trade Ratio / Emir-Islem Orani)
  - OBI  (Order Book Imbalance / Emir Defteri Dengesizligi)
  - Dwell Time (Emir Bekleme Suresi)

Tum hesaplamalar sifira bolme (division-by-zero) durumlarina karsi
korumali sekilde yazildi ve bagimsiz olarak birim testi (tests/test_metrics.py)
ile dogrulandi.
"""
from __future__ import annotations

import time
from collections import deque
from dataclasses import dataclass, field
from typing import Deque, Dict, Optional

MAX_WINDOW = 1000  # spec: collections.deque ile maksimum 1000 elemanli kayan pencere


def compute_otr(canceled_lot: float, executed_lot: float) -> float:
    """
    OTR = Iptal Edilen Lot / Gerceklesen Islem Lot

    executed_lot == 0 iken canceled_lot > 0 ise oran matematiksel olarak
    sonsuzdur; bunu float('inf') ile temsil ediyoruz ki esik kontrolu
    (OTR > 0.90) dogru calissin. Ikisi de 0 ise piyasada bu kademede
    hicbir hareket yok demektir -> 0.0 don.
    """
    if executed_lot <= 0:
        return float("inf") if canceled_lot > 0 else 0.0
    return canceled_lot / executed_lot


def compute_obi(bid_volume: float, ask_volume: float) -> float:
    """
    OBI = (V_bid - V_ask) / (V_bid + V_ask)

    Sonuc [-1, +1] araliginda. Kitap tamamen bossa (iki taraf da 0
    hacim) 0.0 don.
    """
    denom = bid_volume + ask_volume
    if denom <= 0:
        return 0.0
    return (bid_volume - ask_volume) / denom


@dataclass
class OrderFlowWindow:
    """
    Bir sembol + fiyat kademesi (price level) icin emir olaylarinin
    kayan penceresi. OTR hesabi icin toplam iptal / toplam gerceklesen
    lot miktarini tutar.
    """
    symbol: str
    price_level: float
    canceled_events: Deque[float] = field(default_factory=lambda: deque(maxlen=MAX_WINDOW))
    executed_events: Deque[float] = field(default_factory=lambda: deque(maxlen=MAX_WINDOW))

    def record_cancel(self, lot: float) -> None:
        self.canceled_events.append(lot)

    def record_execution(self, lot: float) -> None:
        self.executed_events.append(lot)

    @property
    def total_canceled(self) -> float:
        return sum(self.canceled_events)

    @property
    def total_executed(self) -> float:
        return sum(self.executed_events)

    @property
    def otr(self) -> float:
        return compute_otr(self.total_canceled, self.total_executed)


@dataclass
class LargeOrderEvent:
    order_id: str
    price_level: float
    lot: float
    entered_at: float
    removed_at: Optional[float] = None

    @property
    def dwell_seconds(self) -> Optional[float]:
        if self.removed_at is None:
            return None
        return self.removed_at - self.entered_at


class DwellTimeTracker:
    """
    50.000+ lotluk (varsayilan esik) emirlerin tahtada kalma suresini izler.

    Spec: "Kademeye giren 50.000+ lotluk emirlerin tahtada kalma suresini
    ol. Eger bir emir 0.5 saniyeden kisa surede silinip tekrarlaniyorsa
    SPOOFING_ALARM tetikle."

    Yorumlama karari: "silinip tekrarlaniyorsa" ifadesi tek bir flicker
    degil, TEKRARLANAN bir deseni ifade eder; bu yuzden ayni fiyat
    kademesinde REPEAT_WINDOW_SECONDS icinde REPEAT_COUNT_FOR_ALARM kez
    "hizli iptal" gorulunce alarm tetiklenir. Esikler .env / settings
    uzerinden ayarlanabilir.

    ONEMLI: Sadece IPTAL edilen emirler flicker sayilir - gercek islem
    (EXECUTED) gormezden gelinir, cunku hizli gerceklesen buyuk bir emir
    spoofing degil, aksine gercek/likit bir piyasanin gostergesidir.
    """

    def __init__(
        self,
        large_order_lot: float = 50_000,
        flicker_seconds: float = 0.5,
        repeat_window_seconds: float = 5.0,
        repeat_count_for_alarm: int = 3,
    ) -> None:
        self.large_order_lot = large_order_lot
        self.flicker_seconds = flicker_seconds
        self.repeat_window_seconds = repeat_window_seconds
        self.repeat_count_for_alarm = repeat_count_for_alarm
        self._open_orders: Dict[str, LargeOrderEvent] = {}
        self._flicker_log: Dict[float, Deque[float]] = {}

    def on_order_placed(self, order_id: str, price_level: float, lot: float, ts: Optional[float] = None) -> None:
        if lot < self.large_order_lot:
            return
        ts = ts if ts is not None else time.time()
        self._open_orders[order_id] = LargeOrderEvent(order_id, price_level, lot, ts)

    def on_order_executed(self, order_id: str, ts: Optional[float] = None) -> None:
        """Gercek islem: takip listesinden temizle, flicker sayilmaz."""
        self._open_orders.pop(order_id, None)

    def on_order_canceled(self, order_id: str, ts: Optional[float] = None) -> bool:
        """Emir iptal edildiginde cagrilir. True donerse SPOOFING_ALARM tetiklenmeli."""
        event = self._open_orders.pop(order_id, None)
        if event is None:
            return False
        ts = ts if ts is not None else time.time()
        event.removed_at = ts
        dwell = event.dwell_seconds
        if dwell is not None and dwell < self.flicker_seconds:
            log = self._flicker_log.setdefault(event.price_level, deque())
            log.append(ts)
            while log and ts - log[0] > self.repeat_window_seconds:
                log.popleft()
            if len(log) >= self.repeat_count_for_alarm:
                return True
        return False


class OBIPriceTracker:
    """
    Spec: "OBI > +0.8 olmasina ragmen fiyat yukari gitmiyorsa, tahtada
    satis yapmak icin alici cekilmeye calisildigi (Spoofing/yemleme)
    uyarisini uret."

    Yorumlama karari: son `lookback` tick boyunca OBI surekli esigin
    UZERINDE kaldiysa VE bu sure zarfinda orta fiyat (mid price)
    yukselmediyse (duz kaldi veya dustuyse) uyari tetiklenir.
    """

    def __init__(self, threshold: float = 0.8, lookback: int = 10) -> None:
        self.threshold = threshold
        self.lookback = lookback
        self._obi_history: Deque[float] = deque(maxlen=lookback)
        self._price_history: Deque[float] = deque(maxlen=lookback)

    def update(self, obi: float, mid_price: float) -> bool:
        self._obi_history.append(obi)
        self._price_history.append(mid_price)
        if len(self._price_history) < self.lookback:
            return False
        sustained_high_obi = all(o > self.threshold for o in self._obi_history)
        price_change = self._price_history[-1] - self._price_history[0]
        return sustained_high_obi and price_change <= 0
