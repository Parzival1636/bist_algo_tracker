"""
core/execution/risk_engine.py
Modul 4: Infaz ve Risk Yonetimi Motoru - Risk Kurallari

Temel ilke (spec): "Ana Sart Sermayeyi Korumaktir."

Uc kural:
  1) Sabit stop-loss: girisin %2 asagisi
  2) Trailing stop: fiyat yukseldikce stop seviyesi yukari cekilir, ASLA
     asagi cekilmez
  3) Sermaye limiti: tek bir hisseye portfoyun %20'sinden fazlasi
     ayrilamaz
"""
from __future__ import annotations

from models.schemas import Position


class RiskEngine:
    def __init__(
        self,
        fixed_stop_loss_pct: float = 0.02,
        trailing_stop_pct: float = 0.02,
        max_portfolio_pct_per_symbol: float = 0.20,
    ) -> None:
        self.fixed_stop_loss_pct = fixed_stop_loss_pct
        self.trailing_stop_pct = trailing_stop_pct
        self.max_portfolio_pct_per_symbol = max_portfolio_pct_per_symbol

    def initial_stop_price(self, entry_price: float) -> float:
        """Sabit stop-loss: giristen %2 asagisi (long pozisyon icin)."""
        return entry_price * (1 - self.fixed_stop_loss_pct)

    def update_trailing_stop(self, position: Position, current_price: float) -> Position:
        """Fiyat yukseldikce trailing stop seviyesini yukari ceker; asla asagi cekmez."""
        if position.highest_price_seen is None or current_price > position.highest_price_seen:
            position.highest_price_seen = current_price

        candidate = position.highest_price_seen * (1 - self.trailing_stop_pct)
        if position.trailing_stop_price is None or candidate > position.trailing_stop_price:
            position.trailing_stop_price = candidate
        return position

    def effective_stop(self, position: Position) -> float:
        """Sabit stop ile trailing stop'tan HANGISI daha yuksekse (koruyucuysa) o gecerlidir."""
        if position.trailing_stop_price is not None:
            return max(position.stop_price, position.trailing_stop_price)
        return position.stop_price

    def should_stop_out(self, position: Position, current_price: float) -> bool:
        return current_price <= self.effective_stop(position)

    def can_open_position(
        self,
        proposed_value: float,
        portfolio_value: float,
        existing_symbol_value: float = 0.0,
    ) -> bool:
        """Tek bir hisseye toplam portfoyun %20'sinden fazlasini ayirma kurali."""
        if portfolio_value <= 0 or proposed_value < 0:
            return False
        total_after = existing_symbol_value + proposed_value
        return (total_after / portfolio_value) <= self.max_portfolio_pct_per_symbol
