"""
db/timeseries_client.py
Modul 6/7 v2: Zaman serisi (tick-level) veri istemcisi soyutlamasi.

Uretimde ClickHouse veya TimescaleDB onerilir (sutun-bazli depolama,
saniyede binlerce tick yazimi + zaman-serisi sorgularinda PostgreSQL'e
gore 10-100x hiz kazanci - bkz. SYSTEM_PROMPT_BIST_AlgoTracker_v2.md
Bolum 1.3). Bu ortamda gercek bir ClickHouse/TimescaleDB kurulu DEGIL;
SQLiteTimeseriesStore ayni TimeseriesStore arayuzunu saglayan bir
demo/test implementasyonudur - uretimde ClickHouseTimeseriesStore'a
gecis sadece bu dosyanin degismesini gerektirir.
"""
from __future__ import annotations

import sqlite3
from abc import ABC, abstractmethod
from dataclasses import dataclass
from datetime import datetime
from typing import List


@dataclass
class TickRecord:
    symbol: str
    metric_name: str  # "otr" | "obi" | "dwell_ms" | ...
    value: float
    timestamp: datetime


class TimeseriesStore(ABC):
    @abstractmethod
    def write(self, record: TickRecord) -> None: ...

    @abstractmethod
    def write_many(self, records: List[TickRecord]) -> None: ...

    @abstractmethod
    def query_recent(self, symbol: str, metric_name: str, limit: int = 100) -> List[TickRecord]: ...


class SQLiteTimeseriesStore(TimeseriesStore):
    """
    Demo/test implementasyonu. UYARI: SQLite satir-bazlidir; production'da
    yuksek hacimli tick yazimi icin ClickHouse/TimescaleDB kullanin.
    """

    def __init__(self, db_path: str = "timeseries_demo.db") -> None:
        self.db_path = db_path.replace("sqlite:///", "") if db_path.startswith("sqlite:///") else db_path
        self._init_schema()

    def _connect(self) -> sqlite3.Connection:
        return sqlite3.connect(self.db_path)

    def _init_schema(self) -> None:
        with self._connect() as conn:
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS ticks (
                    symbol TEXT NOT NULL,
                    metric_name TEXT NOT NULL,
                    value REAL NOT NULL,
                    timestamp TEXT NOT NULL
                )
                """
            )
            conn.execute("CREATE INDEX IF NOT EXISTS idx_ticks_symbol_metric ON ticks(symbol, metric_name, timestamp)")

    def write(self, record: TickRecord) -> None:
        self.write_many([record])

    def write_many(self, records: List[TickRecord]) -> None:
        if not records:
            return
        with self._connect() as conn:
            conn.executemany(
                "INSERT INTO ticks (symbol, metric_name, value, timestamp) VALUES (?, ?, ?, ?)",
                [(r.symbol, r.metric_name, r.value, r.timestamp.isoformat()) for r in records],
            )

    def query_recent(self, symbol: str, metric_name: str, limit: int = 100) -> List[TickRecord]:
        with self._connect() as conn:
            rows = conn.execute(
                "SELECT symbol, metric_name, value, timestamp FROM ticks "
                "WHERE symbol = ? AND metric_name = ? ORDER BY timestamp DESC LIMIT ?",
                (symbol, metric_name, limit),
            ).fetchall()
        return [
            TickRecord(symbol=r[0], metric_name=r[1], value=r[2], timestamp=datetime.fromisoformat(r[3]))
            for r in rows
        ]
