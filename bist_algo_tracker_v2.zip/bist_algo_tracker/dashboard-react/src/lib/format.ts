/**
 * lib/format.ts - sayisal bicimlendirme yardimcilari (Turkce yerel ayar).
 */

export function formatLot(lot: number): string {
  return new Intl.NumberFormat('tr-TR').format(Math.round(lot))
}

export function formatPrice(price: number): string {
  return price.toFixed(2)
}

export function formatPctChange(from: number, to: number): string {
  if (from === 0) return '—'
  const pct = ((to - from) / from) * 100
  const sign = pct >= 0 ? '+' : ''
  return `${sign}${pct.toFixed(2)}%`
}

export function formatTime(isoTimestamp: string): string {
  const d = new Date(isoTimestamp)
  if (Number.isNaN(d.getTime())) return '--:--:--'
  return d.toLocaleTimeString('tr-TR', { hour12: false })
}
