import type { ConnectionStatus } from '../state/useAppStore'
import type { HealthResponse } from '../types'

interface TopBarProps {
  health: HealthResponse | null
  alertsConnection: ConnectionStatus
  soundEnabled: boolean
  onToggleSound: () => void
}

const STATUS_LABEL: Record<ConnectionStatus, string> = {
  connected: 'Bağlı',
  connecting: 'Bağlanıyor…',
  disconnected: 'Bağlantı Kesildi',
}
const STATUS_COLOR: Record<ConnectionStatus, string> = {
  connected: 'var(--color-buy)',
  connecting: 'var(--color-warning)',
  disconnected: 'var(--color-sell)',
}

export function TopBar({ health, alertsConnection, soundEnabled, onToggleSound }: TopBarProps) {
  const modeLabel = health ? (health.demo_mode ? 'DEMO (sentetik veri)' : 'CANLI') : '—'

  return (
    <header className="flex shrink-0 items-center justify-between border-b border-[var(--color-border)] bg-[var(--color-panel)] px-4 py-2.5">
      <div className="flex items-center gap-3">
        <span className="font-mono text-sm font-bold tracking-tight text-[var(--color-text)]">📈 BIST-AlgoTracker v2</span>
        <span className="rounded bg-[var(--color-accent)]/15 px-2 py-0.5 font-mono text-[11px] font-semibold text-[var(--color-accent)]">
          {modeLabel}
        </span>
        {health && (
          <span className="font-mono text-[11px] text-[var(--color-muted)]">
            bus: {health.message_bus} · devre: {health.db_breaker_state} · atlanan: {health.dropped_messages}
          </span>
        )}
      </div>
      <div className="flex items-center gap-4">
        <span className="flex items-center gap-1.5 font-mono text-[11px] text-[var(--color-muted)]">
          <span className="inline-block h-1.5 w-1.5 rounded-full" style={{ background: STATUS_COLOR[alertsConnection] }} />
          {STATUS_LABEL[alertsConnection]}
        </span>
        <button
          onClick={onToggleSound}
          className="font-mono text-[11px] text-[var(--color-muted)] hover:text-[var(--color-text)]"
          title="Alarm sesini aç/kapat"
        >
          {soundEnabled ? '🔊 Ses Açık' : '🔇 Ses Kapalı'}
        </button>
        <span className="font-mono text-[10px] text-[var(--color-muted)]">F1 Alış · F2 Satış · Esc İptal</span>
      </div>
    </header>
  )
}
