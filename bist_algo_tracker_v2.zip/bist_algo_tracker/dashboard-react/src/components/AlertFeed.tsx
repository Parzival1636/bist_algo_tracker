import { useEffect, useMemo, useRef } from 'react'
import { List, type RowComponentProps } from 'react-window'
import { formatTime } from '../lib/format'
import { playAlertSound } from '../lib/soundAlert'
import type { Alert, AlertSeverity } from '../types'

interface AlertFeedProps {
  alerts: Alert[]
  soundEnabled: boolean
}

const SEVERITY_COLOR: Record<AlertSeverity, string> = {
  CRITICAL: 'var(--color-alarm)',
  WARNING: 'var(--color-warning)',
  INFO: 'var(--color-info)',
}

interface RowData {
  items: Alert[]
}

/**
 * v2 spec Bolum 4.9: "Uzun listeler (watchlist, alarm log) react-window
 * ile sanallastirilmali - DOM'da sadece gorunen satirlar var olmali."
 * Alarm sayisi bir oturumda kabaraiblecegi icin (bellekte son 200 tutulur
 * - bkz. useAppStore) bu panel DOM dugum sayisini sabit tutar.
 */
function AlertRow({ index, style, items }: RowComponentProps<RowData>) {
  const alert = items[index]
  const color = SEVERITY_COLOR[alert.severity]
  return (
    <div style={style} className="flex items-center font-mono text-[11px] leading-tight">
      <div style={{ borderColor: color }} className="border-l-2 py-0.5 pl-2">
        <span className="text-[var(--color-muted)]">{formatTime(alert.timestamp)}</span>{' '}
        <span className="font-semibold" style={{ color }}>
          [{alert.type}]
        </span>{' '}
        <span className="text-[var(--color-text)]">{alert.message}</span>
      </div>
    </div>
  )
}

export function AlertFeed({ alerts, soundEnabled }: AlertFeedProps) {
  const lastSeenCount = useRef(0)

  useEffect(() => {
    if (!soundEnabled) {
      lastSeenCount.current = alerts.length
      return
    }
    const newOnes = alerts.slice(lastSeenCount.current)
    lastSeenCount.current = alerts.length
    for (const alert of newOnes) {
      playAlertSound(alert.severity)
    }
  }, [alerts, soundEnabled])

  // En yeni ustte
  const reversed = useMemo(() => [...alerts].reverse(), [alerts])
  const rowProps = useMemo<RowData>(() => ({ items: reversed }), [reversed])

  if (alerts.length === 0) {
    return <div className="p-2 text-xs text-[var(--color-muted)]">Henüz alarm yok.</div>
  }

  return (
    <List
      rowComponent={AlertRow}
      rowCount={reversed.length}
      rowHeight={26}
      rowProps={rowProps}
      defaultHeight={280}
      style={{ height: '100%', width: '100%' }}
    />
  )
}
