import { useWebSocketStream } from '../hooks/useWebSocketStream'
import { useAppStore } from '../state/useAppStore'
import { wsUrl } from '../api/client'
import type { AKDSnapshot, OrderBookSnapshot } from '../types'

/**
 * Gorunmez "abone" bileşenleri: her sembol icin kendi WS baglantisini
 * acar (React hook kurallarina uymak icin dongu yerine .map() ile
 * birden fazla bilesen ornegi kullanilir). Boylece Watchlist TUM
 * sembollerin fiyatini REST POLLING OLMADAN, canli gosterebilir.
 */
export function OrderbookSubscriber({ symbol }: { symbol: string }) {
  const updateOrderbook = useAppStore((s) => s.updateOrderbook)
  useWebSocketStream<OrderBookSnapshot>(wsUrl(`/ws/orderbook/${symbol}`), (book) => updateOrderbook(symbol, book))
  return null
}

export function AkdSubscriber({ symbol }: { symbol: string }) {
  const updateAkd = useAppStore((s) => s.updateAkd)
  useWebSocketStream<AKDSnapshot>(wsUrl(`/ws/akd/${symbol}`), (akd) => updateAkd(symbol, akd))
  return null
}
