/**
 * state/useAppStore.ts
 * Zustand: selector-bazli, ince-taneli state yonetimi (v2 spec Bolum 4.9)
 * - bir bilesen sadece kullandigi dilimi okudugunda, ilgisiz state
 * degisikliklerinde YENIDEN RENDER OLMAZ (Redux'un "her degisiklikte
 * tum agac render olur" sorunundan boyle kacinilir).
 */
import { create } from 'zustand'
import type { AKDSnapshot, Alert, HealthResponse, Order, OrderBookSnapshot } from '../types'

export type ConnectionStatus = 'connecting' | 'connected' | 'disconnected'

interface AppState {
  health: HealthResponse | null
  selectedSymbol: string | null
  orderbooks: Record<string, OrderBookSnapshot>
  akd: Record<string, AKDSnapshot>
  alerts: Alert[]
  orders: Order[]
  alertsConnection: ConnectionStatus
  orderbookConnection: ConnectionStatus
  soundEnabled: boolean

  setHealth: (health: HealthResponse) => void
  selectSymbol: (symbol: string) => void
  updateOrderbook: (symbol: string, book: OrderBookSnapshot) => void
  updateAkd: (symbol: string, akd: AKDSnapshot) => void
  addAlert: (alert: Alert) => void
  setOrders: (orders: Order[]) => void
  setAlertsConnection: (status: ConnectionStatus) => void
  setOrderbookConnection: (status: ConnectionStatus) => void
  toggleSound: () => void
}

const MAX_ALERTS_IN_MEMORY = 200

export const useAppStore = create<AppState>((set) => ({
  health: null,
  selectedSymbol: null,
  orderbooks: {},
  akd: {},
  alerts: [],
  orders: [],
  alertsConnection: 'connecting',
  orderbookConnection: 'connecting',
  soundEnabled: true,

  setHealth: (health) =>
    set((state) => ({
      health,
      selectedSymbol: state.selectedSymbol ?? health.symbols[0] ?? null,
    })),

  selectSymbol: (symbol) => set({ selectedSymbol: symbol }),

  updateOrderbook: (symbol, book) =>
    set((state) => ({ orderbooks: { ...state.orderbooks, [symbol]: book } })),

  updateAkd: (symbol, akd) =>
    set((state) => ({ akd: { ...state.akd, [symbol]: akd } })),

  addAlert: (alert) =>
    set((state) => ({ alerts: [...state.alerts, alert].slice(-MAX_ALERTS_IN_MEMORY) })),

  setOrders: (orders) => set({ orders }),

  setAlertsConnection: (status) => set({ alertsConnection: status }),
  setOrderbookConnection: (status) => set({ orderbookConnection: status }),

  toggleSound: () => set((state) => ({ soundEnabled: !state.soundEnabled })),
}))
