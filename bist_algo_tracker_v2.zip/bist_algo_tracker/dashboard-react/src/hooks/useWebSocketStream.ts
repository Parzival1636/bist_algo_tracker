/**
 * hooks/useWebSocketStream.ts
 * Genel amacli, OTOMATIK YENIDEN BAGLANAN WebSocket hook'u. Backend'in
 * anlik push'unu tuketir - REST polling YOKTUR (v2 spec: "gecikme
 * kabul edilemez").
 *
 * useEffectEvent kullanir (React 19.2+): callback/onStatusChange'in en
 * guncel halini, Effect'i her render'da yeniden calistirmadan okumamizi
 * saglar - eskiden yaygin olan "render sirasinda ref mutasyonu" deseninden
 * daha dogrudur (bkz. https://react.dev/reference/react/useEffectEvent).
 */
import { useEffect, useEffectEvent } from 'react'
import type { ConnectionStatus } from '../state/useAppStore'

const RECONNECT_DELAY_MS = 2000

export function useWebSocketStream<T>(
  url: string | null,
  onMessage: (data: T) => void,
  onStatusChange?: (status: ConnectionStatus) => void,
): void {
  const handleMessage = useEffectEvent((data: T) => {
    onMessage(data)
  })
  const handleStatusChange = useEffectEvent((status: ConnectionStatus) => {
    onStatusChange?.(status)
  })

  useEffect(() => {
    if (!url) return

    let ws: WebSocket | null = null
    let retryTimer: ReturnType<typeof setTimeout> | null = null
    let closedByCleanup = false

    function connect() {
      handleStatusChange('connecting')
      ws = new WebSocket(url as string)

      ws.onopen = () => {
        handleStatusChange('connected')
      }
      ws.onmessage = (event: MessageEvent<string>) => {
        try {
          const data = JSON.parse(event.data) as T
          handleMessage(data)
        } catch {
          // Bozuk/ayristirilamayan mesaj - sessizce yoksay, akisi kesme.
        }
      }
      ws.onclose = () => {
        handleStatusChange('disconnected')
        if (!closedByCleanup) {
          retryTimer = setTimeout(connect, RECONNECT_DELAY_MS)
        }
      }
      ws.onerror = () => {
        ws?.close()
      }
    }

    connect()

    return () => {
      closedByCleanup = true
      if (retryTimer) clearTimeout(retryTimer)
      ws?.close()
    }
    // handleMessage/handleStatusChange birer Effect Event'tir - React kurallarina
    // gore bagimlilik dizisine EKLENMEMELIDIR (her zaman en guncel halleri okunur).
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [url])
}
