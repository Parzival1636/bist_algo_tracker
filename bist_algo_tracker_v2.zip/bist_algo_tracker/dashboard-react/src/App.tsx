import { useCallback, useEffect, useMemo, useState } from 'react'
import type { Layout } from 'react-grid-layout/legacy'
import { fetchHealth, fetchOrders, placeOrder, cancelOrder, wsUrl } from './api/client'
import { AkdPanel } from './components/AkdPanel'
import { AlertFeed } from './components/AlertFeed'
import { ChartPanel } from './components/ChartPanel'
import { DomLadder } from './components/DomLadder'
import { AkdSubscriber, OrderbookSubscriber } from './components/OrderbookSubscriber'
import { OrderTicket } from './components/OrderTicket'
import { OrdersPanel } from './components/OrdersPanel'
import { TopBar } from './components/TopBar'
import { Watchlist } from './components/Watchlist'
import { WorkspaceGrid, type WorkspacePanel } from './components/WorkspaceGrid'
import { useTraderHotkeys } from './hooks/useTraderHotkeys'
import { useWebSocketStream } from './hooks/useWebSocketStream'
import { bestAsk, bestBid, midPrice } from './lib/priceLadder'
import { useAppStore } from './state/useAppStore'
import type { Alert, Side } from './types'

const DEFAULT_LAYOUT: Layout = [
  { i: 'watchlist', x: 0, y: 0, w: 2, h: 18, minW: 2 },
  { i: 'ladder', x: 2, y: 0, w: 3, h: 18, minW: 2 },
  { i: 'ticket', x: 5, y: 0, w: 2, h: 9, minW: 2 },
  { i: 'akd', x: 5, y: 9, w: 2, h: 9, minW: 2 },
  { i: 'chart', x: 7, y: 0, w: 5, h: 9, minW: 3 },
  { i: 'orders', x: 7, y: 9, w: 5, h: 9, minW: 3 },
  { i: 'alerts', x: 0, y: 18, w: 12, h: 10, minW: 3 },
]

export default function App() {
  const health = useAppStore((s) => s.health)
  const setHealth = useAppStore((s) => s.setHealth)
  const selectedSymbol = useAppStore((s) => s.selectedSymbol)
  const selectSymbol = useAppStore((s) => s.selectSymbol)
  const orderbooks = useAppStore((s) => s.orderbooks)
  const akdMap = useAppStore((s) => s.akd)
  const alerts = useAppStore((s) => s.alerts)
  const addAlert = useAppStore((s) => s.addAlert)
  const orders = useAppStore((s) => s.orders)
  const setOrders = useAppStore((s) => s.setOrders)
  const alertsConnection = useAppStore((s) => s.alertsConnection)
  const setAlertsConnection = useAppStore((s) => s.setAlertsConnection)
  const soundEnabled = useAppStore((s) => s.soundEnabled)
  const toggleSound = useAppStore((s) => s.toggleSound)

  const [ticketPrice, setTicketPrice] = useState<number | null>(null)
  const [ticketSide, setTicketSide] = useState<Side | null>(null)
  const [layout, setLayout] = useState<Layout>(DEFAULT_LAYOUT)

  // --- Ilk yukleme + hafif periyodik saglik kontrolu ---
  useEffect(() => {
    fetchHealth().then(setHealth).catch(() => {})
    const id = setInterval(() => {
      fetchHealth().then(setHealth).catch(() => {})
    }, 5000)
    return () => clearInterval(id)
  }, [setHealth])

  // --- Acik emirler: WS akisi yok (bkz. README), kisa periyotla yenilenir ---
  const refreshOrders = useCallback(() => {
    fetchOrders().then(setOrders).catch(() => {})
  }, [setOrders])

  useEffect(() => {
    refreshOrders()
    const id = setInterval(refreshOrders, 3000)
    return () => clearInterval(id)
  }, [refreshOrders])

  // --- Alarmlar: TEK global WebSocket, tum semboller icin ---
  const handleAlert = useCallback((alert: Alert) => addAlert(alert), [addAlert])
  useWebSocketStream<Alert>(wsUrl('/ws/alerts'), handleAlert, setAlertsConnection)

  const symbols = health?.symbols ?? []

  const book = selectedSymbol ? orderbooks[selectedSymbol] : null
  const akd = selectedSymbol ? (akdMap[selectedSymbol] ?? null) : null

  const symbolAlerts = useMemo(
    () => (selectedSymbol ? alerts.filter((a) => a.symbol === selectedSymbol).slice(-30) : []),
    [alerts, selectedSymbol],
  )

  const alertCounts = useMemo(() => {
    const counts: Record<string, number> = {}
    for (const a of alerts) counts[a.symbol] = (counts[a.symbol] ?? 0) + 1
    return counts
  }, [alerts])

  const latestMid = book ? midPrice(book) : null

  const handleSelectPrice = useCallback((price: number, side: Side) => {
    setTicketPrice(price)
    setTicketSide(side)
  }, [])

  // --- Trader hotkey'leri (v2 spec Bolum 4.4) ---
  useTraderHotkeys({
    onMarketBuy: () => {
      if (!selectedSymbol || !book) return
      const ask = bestAsk(book)
      if (ask) placeOrder(selectedSymbol, 'BID', ask.price, 100).then(refreshOrders).catch(() => {})
    },
    onMarketSell: () => {
      if (!selectedSymbol || !book) return
      const bid = bestBid(book)
      if (bid) placeOrder(selectedSymbol, 'ASK', bid.price, 100).then(refreshOrders).catch(() => {})
    },
    onCancelAll: () => {
      if (!selectedSymbol) return
      const toCancel = orders.filter((o) => o.symbol === selectedSymbol)
      Promise.all(toCancel.map((o) => cancelOrder(o.order_id))).then(refreshOrders).catch(() => {})
    },
  })

  const panels: WorkspacePanel[] = [
    {
      id: 'watchlist',
      title: 'İzleme Listesi',
      content: (
        <Watchlist
          symbols={symbols}
          selectedSymbol={selectedSymbol}
          orderbooks={orderbooks}
          alertCounts={alertCounts}
          onSelect={selectSymbol}
        />
      ),
    },
    {
      id: 'ladder',
      title: `Emir Defteri Derinliği${selectedSymbol ? ' — ' + selectedSymbol : ''}`,
      content: <DomLadder book={book} recentAlerts={symbolAlerts} onSelectPrice={handleSelectPrice} />,
    },
    {
      id: 'ticket',
      title: 'Emir Formu',
      content: (
        <OrderTicket symbol={selectedSymbol} prefillPrice={ticketPrice} prefillSide={ticketSide} onOrderPlaced={refreshOrders} />
      ),
    },
    { id: 'akd', title: 'Aracı Kurum Dağılımı', content: <AkdPanel akd={akd} /> },
    { id: 'chart', title: `Fiyat Grafiği${selectedSymbol ? ' — ' + selectedSymbol : ''}`, content: <ChartPanel symbol={selectedSymbol} latestMidPrice={latestMid} /> },
    { id: 'orders', title: 'Açık Emirler', content: <OrdersPanel orders={orders} onChanged={refreshOrders} /> },
    { id: 'alerts', title: 'Anomali Bildirim Akışı', content: <AlertFeed alerts={alerts} soundEnabled={soundEnabled} /> },
  ]

  return (
    <div className="flex h-screen flex-col">
      <TopBar health={health} alertsConnection={alertsConnection} soundEnabled={soundEnabled} onToggleSound={toggleSound} />
      {symbols.map((s) => (
        <OrderbookSubscriber key={`ob-${s}`} symbol={s} />
      ))}
      {symbols.map((s) => (
        <AkdSubscriber key={`akd-${s}`} symbol={s} />
      ))}
      <div className="min-h-0 flex-1 overflow-auto p-2">
        <WorkspaceGrid panels={panels} layout={layout} onLayoutChange={setLayout} />
      </div>
    </div>
  )
}
