"""
api/main_fastapi.py
Modul 6 (v1 temeli) + v2 performans/dayaniklilik/analitik katmani.

v2 eklemeleri:
  - orjson: REST yanitlarinda DEGIL (canli testte yakalandi: kurulu
    FastAPI surumunde `ORJSONResponse` artik deprecated - FastAPI,
    donus tipi/response_model tanimliyken veriyi Pydantic uzerinden
    zaten dogrudan ve hizli JSON'a serilestiriyor, ozel bir response
    sinifina gerek yok). orjson'un GERCEK kazanci bu kod tabaninda
    messaging/nats_bus.py'dedir: yuksek frekansli mesaj-veriyolu
    trafiginde ham orjson.dumps/loads kullanilir (bkz. o dosya, gercek
    bir nats-server'a karsi test edildi).
  - uvloop: `uvicorn api.main_fastapi:app` ile calistirildiginda
    OTOMATIK devreye girer. uvicorn'un "auto" loop factory'si (bkz.
    uvicorn/loops/auto.py kaynak kodu) uvloop paketi kuruluysa onu
    otomatik secer - ek kod GEREKMEZ, sadece requirements.txt'de
    bulunmasi yeterlidir (dogrulandi).
  - messaging.factory uzerinden MessageBus soyutlamasi (v1'deki
    db.redis_client yerine gecti; demo modda ayni davranan
    InMemoryMessageBus, MESSAGE_BUS=nats ile gercek NATS'a baglanir -
    bkz. messaging/nats_bus.py, gercek bir nats-server'a karsi test
    edildi).
  - Yeni v2 dedektorleri devreye alindi: LayeringDetector,
    IcebergDetector, AdaptiveThresholdTracker (OBI uzerinde, sabit
    esige EK bir sinyal olarak), CrossSymbolCorrelationEngine.
  - Ingestion (veri uretimi) ile processing (analiz) BoundedDropOldestQueue
    araciligiyla ayristirildi (backpressure - v2 spec Bolum 1.7).
  - DB yazimi artik circuit breaker ile sarmalanmis (bkz.
    core/resilience/circuit_breaker.py) - DB art arda hata verirse alarm
    akisi (WebSocket/mesaj yayini) KESINTIYE UGRAMAZ, sadece kalici
    yazim gecici olarak durur.
  - Yeni /ws/orderbook/{symbol}: React DOM ladder'in REST polling
    yerine dogrudan push ile beslenmesi icin.
"""
from __future__ import annotations

import asyncio
import json
import time
from contextlib import asynccontextmanager
from typing import Dict, List, Optional, Tuple

import pybreaker
from fastapi import FastAPI, WebSocket, WebSocketDisconnect

from config.logging_config import configure_logging, get_logger
from config.settings import settings
from core.analytics.adaptive_thresholds import AdaptiveThresholdTracker
from core.analytics.correlation_engine import CrossSymbolCorrelationEngine
from core.analytics.iceberg_detector import IcebergDetector
from core.analytics.institutional import InstitutionalTracker
from core.analytics.layering_detector import LayeringDetector
from core.analytics.metrics import compute_obi
from core.analytics.spoofing_detector import SpoofingDetector
from core.ingestion.data_parser import parse_akd, parse_order_book, parse_order_event
from core.ingestion.websocket_client import SimulatedMarketDataSource
from core.resilience.backpressure import BoundedDropOldestQueue
from core.resilience.circuit_breaker import make_breaker
from core.execution.order_manager import PaperBrokerAdapter
from db.postgres_models import AlertRecord, init_db
from messaging.factory import get_message_bus
from models.schemas import Alert, AlertSeverity, AlertType, Side
from pydantic import BaseModel

configure_logging()
logger = get_logger(__name__)

ALERT_SUBJECT = "bist.alerts"
ORDERBOOK_SUBJECT_PREFIX = "bist.orderbook"
AKD_SUBJECT_PREFIX = "bist.akd"

detectors: Dict[str, SpoofingDetector] = {s: SpoofingDetector(s) for s in settings.tracked_symbols}
trackers: Dict[str, InstitutionalTracker] = {s: InstitutionalTracker(symbol=s) for s in settings.tracked_symbols}
layering_detectors: Dict[str, LayeringDetector] = {s: LayeringDetector() for s in settings.tracked_symbols}
iceberg_detectors: Dict[str, IcebergDetector] = {s: IcebergDetector() for s in settings.tracked_symbols}
obi_adaptive: Dict[str, AdaptiveThresholdTracker] = {s: AdaptiveThresholdTracker() for s in settings.tracked_symbols}
correlation_engine = CrossSymbolCorrelationEngine()
broker = PaperBrokerAdapter()  # v2: React DOM ladder'daki click-to-trade icin - GERCEK PARA KULLANMAZ

bus = get_message_bus(settings.message_bus, settings.nats_url)
SessionLocal = init_db(settings.database_url)
db_breaker = make_breaker(
    "db-persist", fail_max=settings.circuit_breaker_fail_max, reset_timeout=settings.circuit_breaker_reset_timeout
)
ingestion_queue: BoundedDropOldestQueue = BoundedDropOldestQueue(maxsize=settings.ingestion_queue_maxsize)

recent_alerts: List[Alert] = []
latest_books: Dict[str, dict] = {}
latest_akd: Dict[str, dict] = {}
_iceberg_flagged: Dict[Tuple[str, float], bool] = {}

_ingestion_task: Optional[asyncio.Task] = None
_processing_task: Optional[asyncio.Task] = None


def _do_persist(alert: Alert) -> None:
    with SessionLocal() as session:
        session.add(AlertRecord(
            symbol=alert.symbol, alert_type=alert.type.value, severity=alert.severity.value,
            message=alert.message, timestamp=alert.timestamp,
        ))
        session.commit()


def _persist_alert(alert: Alert) -> None:
    try:
        db_breaker.call(_do_persist, alert)
    except pybreaker.CircuitBreakerError:
        logger.warning("DB devresi ACIK - alarm kalici olarak yazilamadi (mesaj hatti/bellekte kaldi).")
    except Exception as exc:  # noqa: BLE001
        logger.warning("Alarm veritabanina yazilamadi: %s", exc)


async def _publish_alert(alert: Alert) -> None:
    recent_alerts.append(alert)
    del recent_alerts[:-200]
    _persist_alert(alert)
    payload = json.loads(alert.model_dump_json())
    await bus.publish(ALERT_SUBJECT, payload)
    logger.info("ALARM: %s", alert.message)


async def _ingestion_loop() -> None:
    """Ham mesajlari uretir, BACKPRESSURE kuyruguna koyar - analiz yavaslasa
    bile veri uretimi bloklanmaz; kuyruk dolarsa en eski mesaj atilir."""
    if not settings.demo_mode:
        logger.warning("DEMO_MODE=false ama gercek bir MarketDataSource baglanmadi.")
        return
    source = SimulatedMarketDataSource(symbols=settings.tracked_symbols)
    async for message in source.stream():
        await ingestion_queue.put(message)


async def _try_fill_open_orders(symbol: str, book) -> None:
    """
    v2: DOM ladder'dan gonderilen paper emirleri, piyasa fiyati kesince
    OTOMATIK doldurur - click-to-trade akisi gercekten islevsel bir emir
    yasam dongusune baglanir. Hala PaperBrokerAdapter'dir - GERCEK PARA
    KULLANILMAZ (bkz. core/execution/order_manager.py ust dokstring'i).
    """
    best_bid = book.best_bid
    best_ask = book.best_ask
    for order in await broker.get_open_orders():
        if order.symbol != symbol:
            continue
        if order.side == Side.BID and best_ask and order.price >= best_ask.price:
            broker.simulate_fill(order.order_id, order.lot - order.filled_lot)
        elif order.side == Side.ASK and best_bid and order.price <= best_bid.price:
            broker.simulate_fill(order.order_id, order.lot - order.filled_lot)


async def _processing_loop() -> None:
    """Kuyruktan okur, tum v1+v2 analitik hattindan gecirir, alarm/orderbook yayinlar."""
    while True:
        message = await ingestion_queue.get()
        channel = message.get("channel")
        payload = message.get("payload", {})
        symbol = payload.get("symbol")
        if symbol is None:
            continue

        if channel == "order_book":
            book = parse_order_book(payload)
            latest_books[symbol] = payload
            for alert in detectors[symbol].on_book_update(book):
                await _publish_alert(alert)
            await bus.publish(f"{ORDERBOOK_SUBJECT_PREFIX}.{symbol}", payload)
            await _try_fill_open_orders(symbol, book)

            obi_ratio = compute_obi(book.total_bid_volume, book.total_ask_volume)
            if obi_adaptive[symbol].is_anomalous(obi_ratio):
                await _publish_alert(Alert(
                    type=AlertType.SPOOFING_UYARISI, severity=AlertSeverity.WARNING, symbol=symbol,
                    message=f"{symbol} - OBI, sembolun kendi tarihsel rejimine gore istatistiksel "
                            f"olarak anormal (adaptif z-score esigi asildi).",
                    data={"obi": obi_ratio},
                ))

        elif channel == "order_event":
            event = parse_order_event(payload)
            for alert in detectors[symbol].on_order_event(event):
                await _publish_alert(alert)

            if event.event_type == "CANCELED":
                levels = layering_detectors[symbol].on_order_canceled(event.price, event.lot, time.time())
                if levels:
                    await _publish_alert(Alert(
                        type=AlertType.LAYERING, severity=AlertSeverity.CRITICAL, symbol=symbol,
                        message=f"{symbol} - {len(levels)} farkli kademede eszamanli buyuk iptal "
                                f"tespit edildi (LAYERING): {sorted(levels)}",
                        data={"level_count": float(len(levels))},
                    ))
            elif event.event_type == "EXECUTED":
                is_iceberg = iceberg_detectors[symbol].on_execution(event.price, event.lot)
                key = (symbol, event.price)
                if is_iceberg and not _iceberg_flagged.get(key):
                    _iceberg_flagged[key] = True
                    await _publish_alert(Alert(
                        type=AlertType.ICEBERG, severity=AlertSeverity.INFO, symbol=symbol,
                        message=f"{symbol} - {event.price:g} kademesinde tekrarlayan, dusuk varyansli "
                                f"gerceklesmeler goruldu (olasi ICEBERG emir).",
                        data={"price": event.price},
                    ))

        elif channel == "akd":
            akd = parse_akd(payload)
            latest_akd[symbol] = payload
            await bus.publish(f"{AKD_SUBJECT_PREFIX}.{symbol}", payload)
            inst_alert = trackers[symbol].ingest(akd)
            if inst_alert:
                await _publish_alert(inst_alert)

            for entry in akd.entries:
                if entry.net_lot > 0:
                    symbols_hit = correlation_engine.on_net_buyer(entry.institution, symbol, time.time())
                    if symbols_hit:
                        await _publish_alert(Alert(
                            type=AlertType.CROSS_SYMBOL_KORELASYON, severity=AlertSeverity.INFO, symbol=symbol,
                            message=f"{entry.institution} kisa surede {len(symbols_hit)} farkli sembolde "
                                    f"net alici: {sorted(symbols_hit)}",
                            data={"symbol_count": float(len(symbols_hit))},
                        ))


@asynccontextmanager
async def lifespan(app: FastAPI):
    global _ingestion_task, _processing_task
    _ingestion_task = asyncio.create_task(_ingestion_loop())
    _processing_task = asyncio.create_task(_processing_loop())
    logger.info(
        "BIST-AlgoTracker API v2 baslatildi (demo_mode=%s, message_bus=%s)",
        settings.demo_mode, settings.message_bus,
    )
    yield
    for task in (_ingestion_task, _processing_task):
        if task:
            task.cancel()
    await bus.close()


app = FastAPI(title="BIST-AlgoTracker API v2", lifespan=lifespan)


@app.get("/health")
async def health():
    return {
        "status": "ok",
        "demo_mode": settings.demo_mode,
        "symbols": settings.tracked_symbols,
        "message_bus": settings.message_bus,
        "dropped_messages": ingestion_queue.dropped_count,
        "queue_size": ingestion_queue.qsize(),
        "db_breaker_state": str(db_breaker.current_state),
    }


@app.get("/alerts")
async def get_alerts(limit: int = 50):
    return [json.loads(a.model_dump_json()) for a in recent_alerts[-limit:]]


@app.get("/orderbook/{symbol}")
async def get_orderbook(symbol: str):
    return latest_books.get(symbol, {})


@app.get("/akd/{symbol}")
async def get_akd(symbol: str):
    return latest_akd.get(symbol, {})


@app.get("/symbols")
async def get_symbols():
    return settings.tracked_symbols


class OrderRequest(BaseModel):
    symbol: str
    side: Side
    price: float
    lot: float


@app.post("/orders")
async def place_order(req: OrderRequest):
    """
    v2: DOM ladder click-to-trade. PaperBrokerAdapter kullanir - GERCEK
    PARA/EMIR DEGILDIR. Fiyat piyasayi kesince otomatik dolar (bkz.
    _try_fill_open_orders).
    """
    order = await broker.place_order(req.symbol, req.side, req.price, req.lot)
    return json.loads(order.model_dump_json())


@app.get("/orders")
async def list_orders():
    return [json.loads(o.model_dump_json()) for o in await broker.get_open_orders()]


@app.post("/orders/{order_id}/cancel")
async def cancel_order_endpoint(order_id: str):
    canceled = await broker.cancel_order(order_id)
    return {"canceled": canceled}


@app.websocket("/ws/alerts")
async def ws_alerts(websocket: WebSocket):
    await websocket.accept()
    try:
        async for message in bus.subscribe(ALERT_SUBJECT):
            await websocket.send_json(message)
    except WebSocketDisconnect:
        logger.info("Dashboard baglantisi kesildi (/ws/alerts).")


@app.websocket("/ws/orderbook/{symbol}")
async def ws_orderbook(websocket: WebSocket, symbol: str):
    """v2: React DOM ladder icin dogrudan push - REST polling'e gerek kalmaz."""
    await websocket.accept()
    try:
        async for message in bus.subscribe(f"{ORDERBOOK_SUBJECT_PREFIX}.{symbol}"):
            await websocket.send_json(message)
    except WebSocketDisconnect:
        logger.info("Dashboard baglantisi kesildi (/ws/orderbook/%s).", symbol)


@app.websocket("/ws/akd/{symbol}")
async def ws_akd(websocket: WebSocket, symbol: str):
    """v2: Watchlist/AKD paneli icin dogrudan push - REST polling'e gerek kalmaz."""
    await websocket.accept()
    try:
        async for message in bus.subscribe(f"{AKD_SUBJECT_PREFIX}.{symbol}"):
            await websocket.send_json(message)
    except WebSocketDisconnect:
        logger.info("Dashboard baglantisi kesildi (/ws/akd/%s).", symbol)
