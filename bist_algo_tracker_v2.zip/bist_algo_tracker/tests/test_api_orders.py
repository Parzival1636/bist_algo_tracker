"""
tests/test_api_orders.py
v2: /orders uclarinin FastAPI TestClient uzerinden GERCEK entegrasyon testi
(place -> list -> cancel -> dogrulama). PaperBrokerAdapter kullanir, gercek
para/emir yoktur.
"""
from fastapi.testclient import TestClient

from api.main_fastapi import app


def test_health_reports_v2_fields():
    with TestClient(app) as client:
        r = client.get("/health")
        assert r.status_code == 200
        body = r.json()
        assert body["status"] == "ok"
        assert "message_bus" in body
        assert "db_breaker_state" in body


def test_place_list_and_cancel_order():
    with TestClient(app) as client:
        r = client.post("/orders", json={"symbol": "THYAO", "side": "BID", "price": 100.0, "lot": 500})
        assert r.status_code == 200
        order = r.json()
        assert order["status"] == "NEW"
        order_id = order["order_id"]

        r = client.get("/orders")
        assert any(o["order_id"] == order_id for o in r.json())

        r = client.post(f"/orders/{order_id}/cancel")
        assert r.status_code == 200
        assert r.json()["canceled"] is True

        r = client.get("/orders")
        assert not any(o["order_id"] == order_id for o in r.json())


def test_cancel_unknown_order_returns_false():
    with TestClient(app) as client:
        r = client.post("/orders/does-not-exist/cancel")
        assert r.status_code == 200
        assert r.json()["canceled"] is False
