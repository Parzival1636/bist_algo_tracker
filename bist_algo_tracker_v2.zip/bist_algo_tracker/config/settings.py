"""
config/settings.py
BIST-AlgoTracker - Merkezi Ayarlar

Tum API anahtarlari, sembol tanimlari ve risk limitleri burada, ortam
degiskenlerinden (.env) okunur. Hicbir gizli bilgi (API anahtari, sifre,
webhook URL'i) kod icinde sabit (hardcoded) tutulmaz - Modul 9 AppSec
gereksinimi.

DEMO_MODE=true (varsayilan): Gercek borsa/araci kurum baglantisi olmadan,
SimulatedMarketDataSource + SQLite + bellek ici pub/sub ile tum sistem
uctan uca calisir.
"""
from __future__ import annotations

from typing import List, Optional

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
    )

    # --- Genel Mod ---
    demo_mode: bool = Field(default=True)
    environment: str = Field(default="development")

    # --- Takip Edilen Semboller ---
    tracked_symbols: List[str] = Field(default_factory=lambda: ["THYAO", "GARAN", "ASELS"])

    # --- Modul 1: Veri Saglayici (Data Ingestion Engine) ---
    market_data_ws_url: Optional[str] = Field(default=None)
    market_data_api_key: Optional[str] = Field(default=None)
    market_data_api_secret: Optional[str] = Field(default=None)

    # --- Redis (Modul 1/6) ---
    redis_url: str = Field(default="redis://localhost:6379/0")

    # --- PostgreSQL (Modul 6/7) ---
    database_url: str = Field(default="sqlite:///./demo.db")

    # --- Modul 4: Risk Limitleri ---
    fixed_stop_loss_pct: float = Field(default=0.02, ge=0, le=1)
    trailing_stop_pct: float = Field(default=0.02, ge=0, le=1)
    max_portfolio_pct_per_symbol: float = Field(default=0.20, ge=0, le=1)

    # --- Modul 2: Anomali Esikleri ---
    otr_threshold: float = Field(default=0.90, ge=0)
    obi_threshold: float = Field(default=0.80, ge=-1, le=1)
    large_order_lot_threshold: float = Field(default=50_000, ge=0)
    dwell_flicker_seconds: float = Field(default=0.5, ge=0)

    # --- Modul 8: Bildirimler ---
    telegram_bot_token: Optional[str] = Field(default=None)
    telegram_chat_id: Optional[str] = Field(default=None)
    discord_webhook_url: Optional[str] = Field(default=None)

    # --- Modul 5: AI/RAG ---
    anthropic_api_key: Optional[str] = Field(default=None)
    use_llm_sentiment: bool = Field(default=False)

    # --- Modul 3: Karanlik Oda (Kapanis Seansi) ---
    dark_room_start_hour: int = Field(default=18)
    dark_room_start_minute: int = Field(default=5)
    dark_room_end_minute: int = Field(default=10)

    # --- v2: Mesajlasma / Dayaniklilik / Performans ---
    message_bus: str = Field(default="memory")  # "memory" | "nats"
    nats_url: str = Field(default="nats://localhost:4222")
    circuit_breaker_fail_max: int = Field(default=3)
    circuit_breaker_reset_timeout: float = Field(default=10.0)
    ingestion_queue_maxsize: int = Field(default=5000)
    timeseries_db_url: str = Field(default="sqlite:///./timeseries_demo.db")


settings = Settings()
