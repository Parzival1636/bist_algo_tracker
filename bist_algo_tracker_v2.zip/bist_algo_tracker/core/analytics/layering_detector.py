"""
core/analytics/layering_detector.py
Modul 2 v2: Katmanlama (Layering) Tespiti - spoofing'in cok-seviyeli
genellemesi.

Tek bir kademede degil, birbirine yakin BIRDEN FAZLA kademede, KISA bir
zaman penceresi icinde eszamanli buyuk emir iptalleri gorulurse LAYERING
alarmi uretilir - bu, tahtanin genelinde yapay bir gorunum yaratma
girisimine isaret eder.
"""
from __future__ import annotations

from collections import deque
from typing import Deque, Optional, Set, Tuple


class LayeringDetector:
    def __init__(
        self,
        correlation_window_seconds: float = 0.75,
        min_correlated_levels: int = 3,
        large_order_lot: float = 20_000,
    ) -> None:
        self.correlation_window_seconds = correlation_window_seconds
        self.min_correlated_levels = min_correlated_levels
        self.large_order_lot = large_order_lot
        # (timestamp, price_level) - buyuk iptallerin kisa donem gecmisi
        self._recent_cancels: Deque[Tuple[float, float]] = deque()

    def on_order_canceled(self, price: float, lot: float, ts: float) -> Optional[Set[float]]:
        """
        Buyuk bir iptal kaydeder. Pencere icinde >= min_correlated_levels
        FARKLI fiyat seviyesinde iptal varsa, o seviyelerin kumesini doner
        (alarm), yoksa None.
        """
        if lot < self.large_order_lot:
            return None
        self._recent_cancels.append((ts, price))
        while self._recent_cancels and ts - self._recent_cancels[0][0] > self.correlation_window_seconds:
            self._recent_cancels.popleft()

        distinct_levels = {p for (_, p) in self._recent_cancels}
        if len(distinct_levels) >= self.min_correlated_levels:
            return distinct_levels
        return None
