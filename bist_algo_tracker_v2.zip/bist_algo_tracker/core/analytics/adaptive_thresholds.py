"""
core/analytics/adaptive_thresholds.py
Modul 2 v2: Sabit esikler yerine, her sembolun kendi tarihsel rejimine
gore normalize edilmis z-score bazli anomali skoru.

    Z(t) = (x_t - mu_w) / sigma_w

mu_w ve sigma_w, son `window` degerin kayan ortalama/standart sapmasidir.
Dusuk likiditeli bir sembolun "dogal" yuksek OTR'si ile gercek bir
anomaliyi, sembole gore kalibre ederek ayirt eder. v1'deki sabit esikler
(.env) "acemi modu" / fallback olarak korunur.
"""
from __future__ import annotations

import statistics
from collections import deque
from typing import Deque, Optional


class AdaptiveThresholdTracker:
    def __init__(self, window: int = 500, min_samples: int = 30, z_threshold: float = 3.0) -> None:
        if min_samples < 2:
            raise ValueError("min_samples >= 2 olmali (standart sapma icin)")
        self.window = window
        self.min_samples = min_samples
        self.z_threshold = z_threshold
        self._values: Deque[float] = deque(maxlen=window)

    def update(self, value: float) -> Optional[float]:
        """Yeni degeri kaydeder ve GUNCEL z-score'u doner (yeterli veri yoksa None)."""
        self._values.append(value)
        if len(self._values) < self.min_samples:
            return None
        mean = statistics.fmean(self._values)
        try:
            stdev = statistics.stdev(self._values)
        except statistics.StatisticsError:
            return None
        if stdev == 0:
            return 0.0
        return (value - mean) / stdev

    def is_anomalous(self, value: float) -> bool:
        z = self.update(value)
        if z is None:
            return False
        return abs(z) > self.z_threshold

    @property
    def has_enough_data(self) -> bool:
        return len(self._values) >= self.min_samples
