"""
core/analytics/correlation_engine.py
Modul 3 v2: Capraz Sembol & Capraz Kurum Korelasyon Motoru.

v1'deki InstitutionalTracker tek sembol bazliydi. Bu motor, ayni kurumun
BIRDEN FAZLA sembolde ESZAMANLI net alici konumuna gecmesini izler - bu,
portfoy-seviyesinde bir rotasyon/pozisyonlanma sinyali olabilir.
"""
from __future__ import annotations

from collections import deque
from typing import Deque, Dict, Optional, Set, Tuple


class CrossSymbolCorrelationEngine:
    def __init__(self, window_seconds: float = 300.0, min_symbol_count: int = 3) -> None:
        self.window_seconds = window_seconds
        self.min_symbol_count = min_symbol_count
        self._events: Dict[str, Deque[Tuple[float, str]]] = {}

    def on_net_buyer(self, institution: str, symbol: str, ts: float) -> Optional[Set[str]]:
        """
        Bir kurumun bir sembolde net alici oldugu her an cagrilir. Son
        `window_seconds` icinde >= min_symbol_count FARKLI sembolde net
        alici oldugu tespit edilirse o sembollerin kumesini doner.
        """
        log = self._events.setdefault(institution, deque())
        log.append((ts, symbol))
        while log and ts - log[0][0] > self.window_seconds:
            log.popleft()

        distinct_symbols = {s for (_, s) in log}
        if len(distinct_symbols) >= self.min_symbol_count:
            return distinct_symbols
        return None
