"""
core/execution/algo_execution.py
Modul 4 v2: TWAP / VWAP dilim (slice) planlama motoru.

ONEMLI: Bu modul GERCEK EMIR GONDERMEZ - sadece "toplam miktar Q'yu, T
suresinde nasil dilimlere bolmeliyim" sorusunu (miktar + zamanlama plani)
hesaplar. Gonderim, v1'deki OrderManager/BrokerAdapter uzerinden yapilir.

  TWAP: q_i = Q / n,  esit araliklarla (Delta t = T / n)
  VWAP: q_i = Q * (V(t_i) / sum(V))  - gorece hacim profiline orantili
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import List


@dataclass
class ExecutionSlice:
    sequence: int
    lot: float
    offset_seconds: float  # planin baslangicindan itibaren gonderim zamani


def plan_twap(total_lot: float, horizon_seconds: float, slice_count: int) -> List[ExecutionSlice]:
    if slice_count <= 0:
        raise ValueError("slice_count > 0 olmali")
    if total_lot <= 0:
        raise ValueError("total_lot > 0 olmali")
    slice_lot = total_lot / slice_count
    interval = horizon_seconds / slice_count
    return [ExecutionSlice(sequence=i, lot=slice_lot, offset_seconds=i * interval) for i in range(slice_count)]


def plan_vwap(total_lot: float, horizon_seconds: float, volume_profile: List[float]) -> List[ExecutionSlice]:
    if not volume_profile:
        raise ValueError("volume_profile bos olamaz")
    if any(v < 0 for v in volume_profile):
        raise ValueError("volume_profile negatif deger iceremez")
    total_weight = sum(volume_profile)
    if total_weight <= 0:
        raise ValueError("volume_profile toplami sifirdan buyuk olmali")
    if total_lot <= 0:
        raise ValueError("total_lot > 0 olmali")

    n = len(volume_profile)
    interval = horizon_seconds / n
    return [
        ExecutionSlice(sequence=i, lot=total_lot * (weight / total_weight), offset_seconds=i * interval)
        for i, weight in enumerate(volume_profile)
    ]
