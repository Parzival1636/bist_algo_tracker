"""
dashboard/app.py
Modul 6 (v1): Streamlit dashboard - hafif fallback/demo goruntuleyici.

v2'de birincil arayuz dashboard-react/ altindaki React uygulamasidir
(bkz. SYSTEM_PROMPT_BIST_AlgoTracker_v2.md, Bolum 4). Bu Streamlit paneli,
React kurulmadan hizli bir demo gormek isteyenler icin korunmustur.

Calistirmak icin (once API ayakta olmali):
    uvicorn api.main_fastapi:app --reload
    streamlit run dashboard/app.py
"""
from __future__ import annotations

import os
import time
from typing import Dict, List, Optional

import requests
import streamlit as st

API_BASE_URL = os.environ.get("API_BASE_URL", "http://localhost:8000")

COLORS = {
    "bg": "#0B0F14", "panel": "#131A22", "border": "#22303C", "text": "#E7ECF2",
    "muted": "#8CA0B3", "accent": "#D9A441", "buy": "#3FB68B", "sell": "#E5484D",
    "alarm": "#D64BA0", "warning": "#F2B84B",
}

st.set_page_config(page_title="BIST-AlgoTracker", layout="wide", page_icon="📈")

st.markdown(f"""
<link href="https://fonts.googleapis.com/css2?family=IBM+Plex+Mono:wght@400;600&family=IBM+Plex+Sans:wght@400;500;600&display=swap" rel="stylesheet">
<style>
  html, body, [class*="css"] {{ font-family: 'IBM Plex Sans', sans-serif; }}
  .stApp {{ background-color: {COLORS['bg']}; }}
  .btr-panel {{ background-color: {COLORS['panel']}; border: 1px solid {COLORS['border']}; border-radius: 8px; padding: 14px 16px; margin-bottom: 14px; }}
  .btr-mono {{ font-family: 'IBM Plex Mono', monospace; font-size: 13px; }}
  .btr-badge {{ display: inline-block; padding: 3px 10px; border-radius: 4px; font-size: 12px; font-weight: 600; font-family: 'IBM Plex Mono', monospace; }}
  .btr-title {{ color: {COLORS['muted']}; font-size: 12px; letter-spacing: 0.06em; text-transform: uppercase; margin-bottom: 8px; }}
</style>
""", unsafe_allow_html=True)


def fetch(path: str) -> Optional[dict]:
    try:
        resp = requests.get(f"{API_BASE_URL}{path}", timeout=3)
        resp.raise_for_status()
        return resp.json()
    except requests.RequestException:
        return None


def severity_color(severity: str) -> str:
    return {"CRITICAL": COLORS["alarm"], "WARNING": COLORS["warning"], "INFO": COLORS["accent"]}.get(severity, COLORS["muted"])


def render_orderbook_ladder(book: Dict) -> None:
    import plotly.graph_objects as go
    bids = book.get("bids", [])[:10]
    asks = list(reversed(book.get("asks", [])[:10]))
    fig = go.Figure()
    if asks:
        fig.add_trace(go.Bar(y=[f"{a['price']:.2f}" for a in asks], x=[a["lot"] for a in asks], orientation="h", marker_color=COLORS["sell"], name="Satış"))
    if bids:
        fig.add_trace(go.Bar(y=[f"{b['price']:.2f}" for b in bids], x=[-b["lot"] for b in bids], orientation="h", marker_color=COLORS["buy"], name="Alış"))
    fig.update_layout(barmode="overlay", height=420, plot_bgcolor=COLORS["panel"], paper_bgcolor=COLORS["panel"],
                       font=dict(color=COLORS["text"], family="IBM Plex Mono"), margin=dict(l=10, r=10, t=10, b=10),
                       showlegend=False, xaxis=dict(title="Lot  (Alış solda ← | → sağda Satış)", gridcolor=COLORS["border"]),
                       yaxis=dict(gridcolor=COLORS["border"]))
    st.plotly_chart(fig, use_container_width=True)


def render_akd_donut(akd: Dict) -> None:
    import plotly.graph_objects as go
    entries = akd.get("entries", [])
    if not entries:
        st.info("AKD verisi bekleniyor...")
        return
    labels = [e["institution"] for e in entries]
    values = [max(e.get("buy_lot", 0), 0.0001) for e in entries]
    palette = [COLORS["accent"], COLORS["buy"], COLORS["warning"], COLORS["sell"], COLORS["alarm"]]
    fig = go.Figure(data=[go.Pie(labels=labels, values=values, hole=0.55, marker=dict(colors=palette[: len(labels)]))])
    fig.update_layout(height=320, paper_bgcolor=COLORS["panel"], font=dict(color=COLORS["text"], family="IBM Plex Sans"),
                       margin=dict(l=10, r=10, t=10, b=10), legend=dict(font=dict(size=10)))
    st.plotly_chart(fig, use_container_width=True)


def main() -> None:
    st.markdown("### 📈 BIST-AlgoTracker — Canlı Panel (v1 / Streamlit fallback)")
    st.caption("Trader-odaklı v2 arayüzü için: `dashboard-react/` — bkz. README.")

    health = fetch("/health")
    if health is None:
        st.error(f"API'ye ulaşılamadı ({API_BASE_URL}). Önce: `uvicorn api.main_fastapi:app --reload`")
        return

    mode_label = "DEMO (sentetik veri)" if health.get("demo_mode") else "CANLI"
    st.markdown(f'<span class="btr-badge" style="background:{COLORS["accent"]}22;color:{COLORS["accent"]};">{mode_label}</span>', unsafe_allow_html=True)

    symbols = health.get("symbols", [])
    if not symbols:
        st.warning("Takip edilen sembol bulunamadı.")
        return

    col_top = st.columns([1, 3])
    with col_top[0]:
        symbol = st.selectbox("Sembol", symbols)
    with col_top[1]:
        auto_refresh = st.checkbox("Otomatik yenile (2sn)", value=True)

    col_left, col_right = st.columns([3, 2])
    with col_left:
        st.markdown('<div class="btr-panel">', unsafe_allow_html=True)
        st.markdown('<div class="btr-title">Emir Defteri Derinliği (Düzey 2)</div>', unsafe_allow_html=True)
        book = fetch(f"/orderbook/{symbol}")
        render_orderbook_ladder(book) if book else st.info("Derinlik verisi bekleniyor...")
        st.markdown("</div>", unsafe_allow_html=True)

    with col_right:
        st.markdown('<div class="btr-panel">', unsafe_allow_html=True)
        st.markdown('<div class="btr-title">Aracı Kurum Dağılımı (AKD)</div>', unsafe_allow_html=True)
        akd = fetch(f"/akd/{symbol}")
        render_akd_donut(akd) if akd else st.info("AKD verisi bekleniyor...")
        st.markdown("</div>", unsafe_allow_html=True)

    st.markdown('<div class="btr-panel">', unsafe_allow_html=True)
    st.markdown('<div class="btr-title">Anomali Bildirim Akışı</div>', unsafe_allow_html=True)
    alerts: List[dict] = fetch("/alerts?limit=25") or []
    if not alerts:
        st.caption("Henüz alarm yok.")
    else:
        for alert in reversed(alerts):
            color = severity_color(alert.get("severity", "INFO"))
            st.markdown(f'<div class="btr-mono" style="border-left:3px solid {color}; padding:4px 10px; margin-bottom:4px;">'
                        f'<span style="color:{color}; font-weight:600;">[{alert.get("type")}]</span> {alert.get("message")}</div>', unsafe_allow_html=True)
    st.markdown("</div>", unsafe_allow_html=True)

    if auto_refresh:
        time.sleep(2)
        st.rerun()


if __name__ == "__main__":
    main()
