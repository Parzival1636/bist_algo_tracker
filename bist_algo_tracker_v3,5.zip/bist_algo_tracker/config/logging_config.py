"""config/logging_config.py - Merkezi loglama yapilandirmasi."""
from __future__ import annotations

import logging
import sys

from config.log_redaction import SecretRedactingFilter


def configure_logging(level: int = logging.INFO) -> None:
    root = logging.getLogger()
    if root.handlers:
        return
    root.setLevel(level)
    handler = logging.StreamHandler(sys.stdout)
    formatter = logging.Formatter(
        fmt="%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )
    handler.setFormatter(formatter)
    # v3.5 AppSec: TUM log kayitlari, yayinlanmadan once kayitli gizli
    # degerler icin taranir (savunma-derinligi - bkz. config/log_redaction.py).
    handler.addFilter(SecretRedactingFilter())
    root.addHandler(handler)


def get_logger(name: str) -> logging.Logger:
    return logging.getLogger(name)
