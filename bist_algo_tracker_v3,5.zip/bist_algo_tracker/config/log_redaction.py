"""
config/log_redaction.py
Modul 9 v3.5: Strict Log Masking - Savunma-Derinligi Katmani.

BIRINCI savunma hatti pydantic.SecretStr'dir (bkz. api/dependencies/auth.py) -
kimlik bilgisi nesneleri zaten kod seviyesinde maskelidir. Bu modul IKINCI
(ekstra guvenceli) bir hattir: bir istek sirasinda "gizli" olarak
ISARETLENMIS ham degerler (register_secret_for_redaction ile), o istegin
YASAM DONGUSU boyunca uretilen HERHANGI bir log kaydinda GEC bulunsa bile
otomatik olarak ***REDACTED*** ile degistirilir - biri yanlislikla
`logger.info(f"key={raw_value}")` yazsa bile.

contextvars kullanir: her ASGI istegi kendi (izole) context'inde calisir,
bu yuzden bir istekte kaydedilen gizli deger BASKA bir isteğin loglarini
ETKILEMEZ (asagida test edilmistir).
"""
from __future__ import annotations

import contextvars
import logging
from typing import FrozenSet

_registered_secrets: contextvars.ContextVar[FrozenSet[str]] = contextvars.ContextVar(
    "registered_secrets", default=frozenset()
)

REDACTED_PLACEHOLDER = "***REDACTED***"
_MIN_SECRET_LENGTH_FOR_REDACTION = 4  # cok kisa/bos degerleri (yanlislikla) redakte etmeyi onler


def register_secret_for_redaction(value: str) -> None:
    """Bu istek context'inde loglanirsa redakte edilecek ham bir degeri kaydeder."""
    if not value or len(value) < _MIN_SECRET_LENGTH_FOR_REDACTION:
        return
    current = _registered_secrets.get()
    _registered_secrets.set(current | {value})


def clear_registered_secrets() -> None:
    """Testler arasi izolasyon icin - uygulama kodunda normalde gerekmez
    (her ASGI istegi zaten kendi izole context'inde baslar)."""
    _registered_secrets.set(frozenset())


class SecretRedactingFilter(logging.Filter):
    """Kok logger'a eklenir (bkz. configure_logging). TUM log kayitlarini
    (formatlanmis haliyle) tarar ve kayitli gizli degerleri redakte eder."""

    def filter(self, record: logging.LogRecord) -> bool:
        secrets = _registered_secrets.get()
        if not secrets:
            return True
        try:
            full_message = record.getMessage()
        except Exception:  # noqa: BLE001 - loglama asla uygulamayi cokertmemeli
            return True

        redacted = full_message
        for secret in secrets:
            if secret in redacted:
                redacted = redacted.replace(secret, REDACTED_PLACEHOLDER)

        if redacted != full_message:
            record.msg = redacted
            record.args = ()
        return True
