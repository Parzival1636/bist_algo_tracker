"""
config/settings.py
BIST-AlgoTracker - Merkezi Ayarlar
"""
from __future__ import annotations

from typing import List, Optional

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
    )

    demo_mode: bool = Field(default=True)
    environment: str = Field(default="development")

    tracked_symbols: List[str] = Field(default_factory=lambda: ["THYAO", "GARAN", "ASELS"])

    market_data_ws_url: Optional[str] = Field(default=None)
    market_data_api_key: Optional[str] = Field(default=None)
    market_data_api_secret: Optional[str] = Field(default=None)

    redis_url: str = Field(default="redis://localhost:6379/0")
    database_url: str = Field(default="sqlite:///./demo.db")

    fixed_stop_loss_pct: float = Field(default=0.02, ge=0, le=1)
    trailing_stop_pct: float = Field(default=0.02, ge=0, le=1)
    max_portfolio_pct_per_symbol: float = Field(default=0.20, ge=0, le=1)

    otr_threshold: float = Field(default=0.90, ge=0)
    obi_threshold: float = Field(default=0.80, ge=-1, le=1)
    large_order_lot_threshold: float = Field(default=50_000, ge=0)
    dwell_flicker_seconds: float = Field(default=0.5, ge=0)

    telegram_bot_token: Optional[str] = Field(default=None)
    telegram_chat_id: Optional[str] = Field(default=None)
    discord_webhook_url: Optional[str] = Field(default=None)

    anthropic_api_key: Optional[str] = Field(default=None)
    use_llm_sentiment: bool = Field(default=False)

    dark_room_start_hour: int = Field(default=18)
    dark_room_start_minute: int = Field(default=5)
    dark_room_end_minute: int = Field(default=10)

    message_bus: str = Field(default="memory")
    nats_url: str = Field(default="nats://localhost:4222")
    circuit_breaker_fail_max: int = Field(default=3)
    circuit_breaker_reset_timeout: float = Field(default=10.0)
    ingestion_queue_maxsize: int = Field(default=5000)
    timeseries_db_url: str = Field(default="sqlite:///./timeseries_demo.db")

    starting_balance_try: float = Field(default=1_000_000.0, ge=0)

    # --- v3.5: Otonom Tetikleyici - GUVENLIK KAPILARI ---
    # KIRMIZI CIZGI: autonomous_trading_enabled VARSAYILAN OLARAK KAPALIDIR.
    # Gercek otonom emir gonderimi icin bu deger + RiskEngine + DailyLossGuard
    # + OrderRateLimiter'in TUMUNUN onayi gerekir - bkz. core/execution/autonomous_engine.py
    autonomous_trading_enabled: bool = Field(default=False)
    autonomous_max_daily_loss_try: float = Field(default=20_000.0, ge=0)
    autonomous_max_orders_per_minute: int = Field(default=5, ge=1)
    autonomous_default_lot: float = Field(default=100.0, gt=0)
    autonomous_obi_z_threshold: float = Field(default=2.0, gt=0)


settings = Settings()
