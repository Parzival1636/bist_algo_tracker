"""
api/dependencies/auth.py
Modul 9 v3.5: AppSec Kalkani - Guvenli Yetkilendirme (API Gateway)

Frontend, araci kurum/veri saglayici kimlik bilgilerini SADECE
tarayicinin localStorage'inda tutar (bkz. dashboard-react
state/useGlobalStore.ts) ve gerektiginde bu backend'e HTTP Header'lari
uzerinden iletir. Bu modul o header'lari FastAPI Depends() ile
karsilayip dogrular.

KRITIK GUVENLIK KURALI - Strict Log Masking (iki katmanli):
  1) BrokerCredentials'in TUM hassas alanlari pydantic.SecretStr'dir.
     Bu tip, repr()/str()/f-string ile KULLANILDIGINDA HER ZAMAN
     maskelenmis gosterir ("**********") - gercek degere erismek icin
     KOD ICINDE ACIKCA .get_secret_value() cagirmak GEREKIR. Bu, "biri
     yanlislikla loglar" riskini DISIPLINE degil TIP SISTEMINE dayanarak
     ortadan kaldirir.
  2) Ham degerler ayrica config/log_redaction.py'a KAYDEDILIR - bu
     istek sirasinda baska bir yerde (ornegin bir kutuphanenin hata
     mesajinda) yanlislikla loglanirsa bile otomatik redakte edilir.

Bu degerler VERITABANINA YAZILMAZ, KONSOLA YAZDIRILMAZ ve .log
dosyalarina GECMEZ - sadece istek suresince bellekte (SecretStr icinde)
tutulur ve gercek kullanim aninda (ornegin bir araci kurum API cagrisi
imzalanirken) ACIKCA acilir.
"""
from __future__ import annotations

from typing import Optional

from fastapi import Depends, Header, HTTPException, status
from pydantic import BaseModel, ConfigDict, SecretStr

from config.log_redaction import register_secret_for_redaction
from config.logging_config import get_logger

logger = get_logger(__name__)


class BrokerCredentials(BaseModel):
    """
    HTTP header'larindan gelen kimlik bilgilerini tasir. Tum alanlar
    SecretStr'dir - bkz. modul dokstring'i. `frozen=True`: olusturulduktan
    sonra degistirilemez (yanlislikla ic alanlarin duz metinle
    degistirilmesini onler).
    """

    model_config = ConfigDict(frozen=True)

    broker_api_key: Optional[SecretStr] = None
    broker_secret_key: Optional[SecretStr] = None
    data_provider_api_key: Optional[SecretStr] = None

    @property
    def has_broker_credentials(self) -> bool:
        return self.broker_api_key is not None and self.broker_secret_key is not None

    @property
    def has_data_provider_credentials(self) -> bool:
        return self.data_provider_api_key is not None


def _to_secret_and_register(raw_value: Optional[str]) -> Optional[SecretStr]:
    """Ham header degerini SecretStr'e cevirir ve redaksiyon icin kaydeder."""
    if not raw_value:
        return None
    register_secret_for_redaction(raw_value)
    return SecretStr(raw_value)


async def get_broker_credentials(
    x_broker_key: Optional[str] = Header(default=None, alias="X-Broker-Key"),
    x_broker_secret: Optional[str] = Header(default=None, alias="X-Broker-Secret"),
    x_data_provider_key: Optional[str] = Header(default=None, alias="X-Data-Provider-Key"),
) -> BrokerCredentials:
    """
    OPSIYONEL kimlik bilgisi cikarimi - header yoksa alanlar None kalir.
    Gercek araci kurum cagrisi ZORUNLU olan uclarda require_broker_credentials
    kullanin.
    """
    creds = BrokerCredentials(
        broker_api_key=_to_secret_and_register(x_broker_key),
        broker_secret_key=_to_secret_and_register(x_broker_secret),
        data_provider_api_key=_to_secret_and_register(x_data_provider_key),
    )
    # ONEMLI: Asagidaki log satiri KASITLI olarak SADECE hangi header'larin
    # MEVCUT OLUP OLMADIGINI (bool) loglar - degerlerin KENDISINI DEGIL.
    logger.debug(
        "Kimlik bilgisi header'lari alindi (broker=%s, veri_saglayici=%s)",
        creds.has_broker_credentials,
        creds.has_data_provider_credentials,
    )
    return creds


async def require_broker_credentials(
    creds: BrokerCredentials = Depends(get_broker_credentials),
) -> BrokerCredentials:
    """Araci kurum kimlik bilgisi ZORUNLU olan uclar icin - eksikse 401 doner."""
    if not creds.has_broker_credentials:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="X-Broker-Key ve X-Broker-Secret header'lari gerekli.",
        )
    return creds
