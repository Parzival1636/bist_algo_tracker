"""
messaging/in_memory_bus.py
Demo mod icin MessageBus implementasyonu (v1'in InMemoryPubSub'iyla ayni
mantik, yeni soyutlamaya tasindi).
"""
from __future__ import annotations

import asyncio
from typing import Any, AsyncIterator, Dict, List

from messaging.bus import MessageBus


class InMemoryMessageBus(MessageBus):
    def __init__(self) -> None:
        self._queues: Dict[str, List[asyncio.Queue]] = {}

    async def publish(self, subject: str, message: Dict[str, Any]) -> None:
        for queue in self._queues.get(subject, []):
            await queue.put(message)

    async def subscribe(self, subject: str) -> AsyncIterator[Dict[str, Any]]:
        queue: asyncio.Queue = asyncio.Queue()
        self._queues.setdefault(subject, []).append(queue)
        try:
            while True:
                yield await queue.get()
        finally:
            self._queues[subject].remove(queue)
