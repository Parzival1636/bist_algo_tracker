"""
messaging/nats_bus.py
Modul 1 v2: NATS uzerinden gercek, kalici mesajlasma.

API, nats-py'nin (>=2.7) dogrulanmis arayuzune gore yazildi:
  nc = await nats.connect(servers=...)
  await nc.publish(subject, payload_bytes)
  sub = await nc.subscribe(subject)   # callback VERMEDEN -> async iterator modu
  async for msg in sub.messages: ...  # msg.data bytes payload'dir

orjson ile serilestirme kullanilir (v2 performans katmani, bkz. requirements.txt).
"""
from __future__ import annotations

import orjson

from messaging.bus import MessageBus
from typing import Any, AsyncIterator, Dict, Optional


class NATSMessageBus(MessageBus):
    def __init__(self, servers: str = "nats://localhost:4222") -> None:
        self.servers = servers
        self._nc: Optional[Any] = None

    async def _get_client(self):
        if self._nc is None:
            import nats
            self._nc = await nats.connect(servers=self.servers)
        return self._nc

    async def publish(self, subject: str, message: Dict[str, Any]) -> None:
        nc = await self._get_client()
        await nc.publish(subject, orjson.dumps(message))

    async def subscribe(self, subject: str) -> AsyncIterator[Dict[str, Any]]:
        nc = await self._get_client()
        sub = await nc.subscribe(subject)
        try:
            async for msg in sub.messages:
                yield orjson.loads(msg.data)
        finally:
            await sub.unsubscribe()

    async def close(self) -> None:
        if self._nc is not None:
            await self._nc.close()
            self._nc = None
