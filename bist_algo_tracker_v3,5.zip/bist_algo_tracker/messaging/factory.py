"""messaging/factory.py - config'e gore dogru MessageBus implementasyonini secer."""
from __future__ import annotations

from messaging.bus import MessageBus
from messaging.in_memory_bus import InMemoryMessageBus


def get_message_bus(kind: str, nats_url: str = "nats://localhost:4222") -> MessageBus:
    if kind == "nats":
        from messaging.nats_bus import NATSMessageBus
        return NATSMessageBus(servers=nats_url)
    return InMemoryMessageBus()
