"""
messaging/bus.py
Modul 1 v2: Mesajlasma katmani soyutlamasi.

v1'de Redis Pub/Sub kullaniliyordu (mesaj kalicilik/replay yok, subscriber
cevrimdisiysa mesaj kaybolur). v2, ayni MessageBus arayuzunu koruyarak
NATS (kalici JetStream secenegiyle, sembol-bazli subject'lerle dogal
partition) veya demo icin bellek ici bir implementasyona baglanabilir.

subject adlandirma sozlesmesi: "bist.<kanal>.<sembol>", orn:
  bist.orderbook.THYAO, bist.alerts.THYAO, bist.akd.GARAN
"""
from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any, AsyncIterator, Dict


class MessageBus(ABC):
    @abstractmethod
    async def publish(self, subject: str, message: Dict[str, Any]) -> None: ...

    @abstractmethod
    def subscribe(self, subject: str) -> AsyncIterator[Dict[str, Any]]: ...

    async def close(self) -> None:
        """Varsayilan: yapilacak bir sey yok. Gercek baglantilar override eder."""
        return None
