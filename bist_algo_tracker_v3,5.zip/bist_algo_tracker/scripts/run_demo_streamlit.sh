#!/usr/bin/env bash
# BIST-AlgoTracker v1 - hafif Streamlit fallback panelini calistirir.
# Kullanim: bash scripts/run_demo_streamlit.sh
set -e

cd "$(dirname "$0")/.."
export DEMO_MODE=true

echo "API baslatiliyor (http://localhost:8000) ..."
uvicorn api.main_fastapi:app --reload --port 8000 &
API_PID=$!
trap "kill $API_PID 2>/dev/null || true" EXIT
sleep 2

echo "Streamlit dashboard baslatiliyor (http://localhost:8501) ..."
streamlit run dashboard/app.py
