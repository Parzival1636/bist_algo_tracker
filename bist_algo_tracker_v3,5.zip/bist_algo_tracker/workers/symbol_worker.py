"""
workers/symbol_worker.py
Modul 1 v2: Sembol-bazli izole analiz worker'i.

Her worker kendi process'inde (multiprocessing) bir SpoofingDetector +
InstitutionalTracker calistirir; bir sembolun yogun analiz yuku
digerlerini bloklamaz. Gercek dagitimda (Kubernetes) her worker ayri
bir Pod replikasi olabilir - burada tek makinede multiprocessing.Process
ile AYNI izolasyon ilkesi gercek OS process'leriyle gosterilir/test edilir.
"""
from __future__ import annotations

import multiprocessing as mp
from typing import Dict, List

from core.analytics.institutional import InstitutionalTracker
from core.analytics.spoofing_detector import SpoofingDetector
from core.ingestion.data_parser import parse_akd, parse_order_book, parse_order_event


def _process_symbol_messages(symbol: str, messages: List[Dict], result_queue: "mp.Queue") -> None:
    """
    AYRI bir OS process'i icinde calisir. Bu fonksiyon modul seviyesinde
    tanimlanmalidir (lambda/closure degil) ki 'spawn' baslatma yontemiyle
    de pickle'lanabilsin.
    """
    detector = SpoofingDetector(symbol)
    tracker = InstitutionalTracker(symbol=symbol)
    alert_count = 0
    for msg in messages:
        channel = msg.get("channel")
        payload = msg.get("payload", {})
        if payload.get("symbol") != symbol:
            continue
        if channel == "order_book":
            alert_count += len(detector.on_book_update(parse_order_book(payload)))
        elif channel == "order_event":
            alert_count += len(detector.on_order_event(parse_order_event(payload)))
        elif channel == "akd":
            if tracker.ingest(parse_akd(payload)) is not None:
                alert_count += 1
    result_queue.put((symbol, alert_count))


def run_isolated_workers(symbol_messages: Dict[str, List[Dict]]) -> Dict[str, int]:
    """
    Her sembol icin AYRI bir OS process'i baslatir, sonuclari toplar.
    Donen: {sembol: uretilen_alarm_sayisi}
    """
    ctx = mp.get_context("spawn")
    result_queue: mp.Queue = ctx.Queue()
    processes = []
    for symbol, messages in symbol_messages.items():
        p = ctx.Process(target=_process_symbol_messages, args=(symbol, messages, result_queue))
        p.start()
        processes.append(p)

    results: Dict[str, int] = {}
    for _ in processes:
        symbol, count = result_queue.get()
        results[symbol] = count

    for p in processes:
        p.join()

    return results
