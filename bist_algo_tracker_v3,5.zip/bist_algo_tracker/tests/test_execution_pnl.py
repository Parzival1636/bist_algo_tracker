"""tests/test_execution_pnl.py - backend basit spot PnL hesaplarının doğruluğu."""
from core.execution.pnl import compute_cash_balance, compute_symbol_exposure
from models.schemas import Order, Side


def _order(symbol="TEST", side=Side.BID, price=100.0, lot=500, filled=500) -> Order:
    return Order(order_id="o", symbol=symbol, side=side, price=price, lot=lot, filled_lot=filled)


def test_cash_balance_decreases_on_buy_fill():
    assert compute_cash_balance(1_000_000, [_order(side=Side.BID, price=100, filled=500)]) == 950_000


def test_cash_balance_increases_on_sell_fill():
    assert compute_cash_balance(1_000_000, [_order(side=Side.ASK, price=100, filled=500)]) == 1_050_000


def test_cash_balance_ignores_unfilled_orders():
    assert compute_cash_balance(1_000_000, [_order(filled=0)]) == 1_000_000


def test_cash_balance_sums_multiple_orders():
    orders = [_order(side=Side.BID, price=100, filled=500), _order(side=Side.ASK, price=110, filled=100)]
    # -50.000 + 11.000 = -39.000
    assert compute_cash_balance(1_000_000, orders) == 961_000


def test_symbol_exposure_only_counts_matching_symbol():
    orders = [
        _order(symbol="THYAO", price=100, filled=500),
        _order(symbol="GARAN", price=50, filled=1000),
    ]
    assert compute_symbol_exposure("THYAO", orders) == 50_000
    assert compute_symbol_exposure("GARAN", orders) == 50_000
    assert compute_symbol_exposure("ASELS", orders) == 0


def test_symbol_exposure_ignores_unfilled():
    assert compute_symbol_exposure("TEST", [_order(filled=0)]) == 0
