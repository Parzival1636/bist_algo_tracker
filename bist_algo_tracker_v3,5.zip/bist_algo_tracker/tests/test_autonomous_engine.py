"""
tests/test_autonomous_engine.py
v3.5 - EN KRITIK GUVENLIK TESTI SETI: AutonomousDecisionEngine'in HER
guvenlik kapisinin GERCEKTEN emri engellediğini, tek tek izole ederek
kanitlar. "Calisiyor" degil, "GUCLU SINYAL OLSA BILE su kosulda ASLA
emir gondermiyor" iddiasi test edilir.
"""
from __future__ import annotations

import asyncio
from datetime import date, datetime, timezone

import pytest

from core.analytics.feature_extractor import FeatureVector
from core.execution.autonomous_engine import AutonomousDecisionEngine, DailyLossGuard, OrderRateLimiter
from core.execution.order_manager import PaperBrokerAdapter
from core.execution.risk_engine import RiskEngine
from models.schemas import OrderBookLevel, OrderBookSnapshot, Side

STRONG_BUY = FeatureVector(symbol="TEST", obi=0.9, obi_zscore=5.0, volume_momentum=0.5, is_significant=True)
STRONG_SELL = FeatureVector(symbol="TEST", obi=-0.9, obi_zscore=-5.0, volume_momentum=-0.5, is_significant=True)
WEAK_SIGNAL = FeatureVector(symbol="TEST", obi=0.1, obi_zscore=0.3, volume_momentum=0.01, is_significant=False)

BOOK = OrderBookSnapshot(
    symbol="TEST", timestamp=datetime.now(timezone.utc),
    bids=[OrderBookLevel(price=99.0, lot=1000)],
    asks=[OrderBookLevel(price=100.0, lot=1000)],
)
EMPTY_ASK_BOOK = OrderBookSnapshot(
    symbol="TEST", timestamp=datetime.now(timezone.utc),
    bids=[OrderBookLevel(price=99.0, lot=1000)], asks=[],
)


def _make_engine(enabled: bool = True, max_daily_loss=1_000_000, max_orders_per_minute=100, obi_z_threshold=2.0):
    broker = PaperBrokerAdapter()
    risk_engine = RiskEngine(max_portfolio_pct_per_symbol=0.20)
    engine = AutonomousDecisionEngine(
        broker=broker, risk_engine=risk_engine,
        daily_loss_guard=DailyLossGuard(max_daily_loss=max_daily_loss),
        rate_limiter=OrderRateLimiter(max_orders_per_minute=max_orders_per_minute),
        enabled=enabled, default_lot=100.0, obi_z_threshold=obi_z_threshold,
    )
    return engine, broker


def test_disabled_by_default_blocks_order_despite_strong_signal():
    engine, broker = _make_engine(enabled=False)

    decision = asyncio.run(engine.on_feature_vector(STRONG_BUY, BOOK, portfolio_value=1_000_000))

    assert decision.action == "DISABLED"
    assert decision.order is None
    open_orders = asyncio.run(broker.get_open_orders())
    assert open_orders == []  # BAGIMSIZ dogrulama: broker'a GERCEKTEN hicbir emir gitmemis


def test_weak_signal_does_not_place_order():
    engine, broker = _make_engine(enabled=True)

    decision = asyncio.run(engine.on_feature_vector(WEAK_SIGNAL, BOOK, portfolio_value=1_000_000))

    assert decision.action == "NO_SIGNAL"
    assert decision.order is None


def test_strong_buy_signal_places_bid_order_when_all_gates_pass():
    engine, broker = _make_engine(enabled=True)

    decision = asyncio.run(engine.on_feature_vector(STRONG_BUY, BOOK, portfolio_value=1_000_000))

    assert decision.action == "ORDER_PLACED"
    assert decision.order is not None
    assert decision.order.side == Side.BID
    assert decision.order.price == 100.0  # en iyi ASK'ten alinir


def test_strong_sell_signal_places_ask_order():
    engine, broker = _make_engine(enabled=True)

    decision = asyncio.run(engine.on_feature_vector(STRONG_SELL, BOOK, portfolio_value=1_000_000))

    assert decision.action == "ORDER_PLACED"
    assert decision.order.side == Side.ASK
    assert decision.order.price == 99.0  # en iyi BID'e satilir


def test_daily_loss_halt_blocks_order_despite_strong_signal():
    engine, broker = _make_engine(enabled=True, max_daily_loss=10_000)
    engine.daily_loss_guard.record_fill_pnl(-15_000)  # limit asildi

    decision = asyncio.run(engine.on_feature_vector(STRONG_BUY, BOOK, portfolio_value=1_000_000))

    assert decision.action == "DAILY_LOSS_HALTED"
    assert decision.order is None
    open_orders = asyncio.run(broker.get_open_orders())
    assert open_orders == []


def test_rate_limit_blocks_order_despite_strong_signal():
    engine, broker = _make_engine(enabled=True, max_orders_per_minute=1)
    # Kotayi dolduran ilk (basarili) emir
    first = asyncio.run(engine.on_feature_vector(STRONG_BUY, BOOK, portfolio_value=1_000_000, now=0.0))
    assert first.action == "ORDER_PLACED"

    # AYNI dakika penceresinde ikinci deneme - guclu sinyal olsa bile ENGELLENMELI
    second = asyncio.run(engine.on_feature_vector(STRONG_BUY, BOOK, portfolio_value=1_000_000, now=1.0))

    assert second.action == "RATE_LIMITED"
    assert second.order is None
    open_orders = asyncio.run(broker.get_open_orders())
    assert len(open_orders) == 1  # SADECE ilk emir gitmis olmali


def test_risk_engine_rejection_blocks_order_when_position_too_large():
    engine, broker = _make_engine(enabled=True)
    # portfoy degeri kucuk -> 100 lot * 100 fiyat = 10.000, portfoyun %20'si = 200 -> reddedilmeli
    decision = asyncio.run(engine.on_feature_vector(STRONG_BUY, BOOK, portfolio_value=1_000))

    assert decision.action == "RISK_REJECTED"
    assert decision.order is None
    open_orders = asyncio.run(broker.get_open_orders())
    assert open_orders == []


def test_missing_price_level_blocks_order():
    engine, broker = _make_engine(enabled=True)
    # STRONG_BUY -> en iyi ASK gerekir, ama kitapta ASK yok
    decision = asyncio.run(engine.on_feature_vector(STRONG_BUY, EMPTY_ASK_BOOK, portfolio_value=1_000_000))

    assert decision.action == "NO_PRICE"
    assert decision.order is None


def test_all_safety_gates_are_evaluated_in_documented_priority_order():
    """
    Birden fazla kapi AYNI ANDA ihlal edilirse, kill-switch (enabled)
    HER ZAMAN en once kontrol edilmelidir - digerlerinin durumundan
    BAGIMSIZ olarak.
    """
    engine, broker = _make_engine(enabled=False, max_daily_loss=1)  # hem kapali HEM gunluk limit asilmis olsun
    engine.daily_loss_guard.record_fill_pnl(-999_999)

    decision = asyncio.run(engine.on_feature_vector(STRONG_BUY, BOOK, portfolio_value=1_000_000))

    assert decision.action == "DISABLED"  # en yuksek onceliktekapı budur
