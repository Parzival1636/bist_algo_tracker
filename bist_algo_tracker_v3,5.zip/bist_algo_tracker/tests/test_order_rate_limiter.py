"""tests/test_order_rate_limiter.py - Emir hız sınırlayıcının doğruluğu."""
import pytest

from core.execution.autonomous_engine import OrderRateLimiter


def test_allows_up_to_limit():
    limiter = OrderRateLimiter(max_orders_per_minute=3)
    assert limiter.allow(now=0.0) is True
    assert limiter.allow(now=1.0) is True
    assert limiter.allow(now=2.0) is True


def test_blocks_beyond_limit_within_window():
    limiter = OrderRateLimiter(max_orders_per_minute=2)
    assert limiter.allow(now=0.0) is True
    assert limiter.allow(now=1.0) is True
    assert limiter.allow(now=2.0) is False  # ayni 60sn penceresinde 3. istek


def test_allows_again_after_window_rolls():
    limiter = OrderRateLimiter(max_orders_per_minute=1)
    assert limiter.allow(now=0.0) is True
    assert limiter.allow(now=30.0) is False  # hala pencere icinde
    assert limiter.allow(now=61.0) is True  # pencere disina cikti


def test_rejects_invalid_max_orders():
    with pytest.raises(ValueError):
        OrderRateLimiter(max_orders_per_minute=0)
