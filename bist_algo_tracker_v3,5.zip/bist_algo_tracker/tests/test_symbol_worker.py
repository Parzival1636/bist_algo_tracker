from workers.symbol_worker import run_isolated_workers


def _book_message(symbol: str, bid_lot: float, ask_lot: float) -> dict:
    return {
        "channel": "order_book",
        "payload": {
            "symbol": symbol,
            "timestamp": "2026-01-01T10:00:00+00:00",
            "bids": [{"price": 99.0, "lot": bid_lot}],
            "asks": [{"price": 100.0, "lot": ask_lot}],
        },
    }


def test_run_isolated_workers_processes_symbols_in_separate_processes():
    """
    Gercek OS process'lerinde (multiprocessing) paralel calistirir.
    AAA: surdurulen yuksek OBI + sabit fiyat -> SPOOFING_UYARISI beklenir.
    BBB: dengeli kitap -> alarm beklenmez.
    """
    symbol_messages = {
        "AAA": [_book_message("AAA", bid_lot=950, ask_lot=50) for _ in range(12)],
        "BBB": [_book_message("BBB", bid_lot=100, ask_lot=100) for _ in range(12)],
    }
    results = run_isolated_workers(symbol_messages)
    assert set(results.keys()) == {"AAA", "BBB"}
    assert results["AAA"] >= 1
    assert results["BBB"] == 0


def test_run_isolated_workers_handles_single_symbol():
    results = run_isolated_workers({"THYAO": [_book_message("THYAO", 100, 100)]})
    assert results == {"THYAO": 0}
