from datetime import datetime, timezone

from core.analytics.institutional import InstitutionalTracker, concentration_index, is_dark_room_session
from models.schemas import AKDEntry, AKDSnapshot


def test_concentration_index_single_dominant_buyer():
    assert concentration_index({"BofA": 100_000, "İş Yatırım": 1_000}) > 0.9

def test_concentration_index_evenly_distributed():
    assert abs(concentration_index({"A": 100, "B": 100, "C": 100, "D": 100}) - 0.25) < 1e-9

def test_concentration_index_no_buyers():
    assert concentration_index({"A": -100, "B": -50}) == 0.0

def test_institutional_tracker_flags_concentration():
    tracker = InstitutionalTracker(symbol="TEST", concentration_threshold=0.5)
    snapshot = AKDSnapshot(symbol="TEST", timestamp=datetime.now(timezone.utc), entries=[
        AKDEntry(institution="BofA", buy_lot=100_000, sell_lot=0),
        AKDEntry(institution="İş Yatırım", buy_lot=1_000, sell_lot=0),
    ])
    alert = tracker.ingest(snapshot)
    assert alert is not None
    assert "BofA" in alert.message

def test_institutional_tracker_no_alert_when_distributed():
    tracker = InstitutionalTracker(symbol="TEST", concentration_threshold=0.5)
    snapshot = AKDSnapshot(symbol="TEST", timestamp=datetime.now(timezone.utc), entries=[
        AKDEntry(institution="A", buy_lot=1000, sell_lot=0), AKDEntry(institution="B", buy_lot=1000, sell_lot=0),
        AKDEntry(institution="C", buy_lot=1000, sell_lot=0), AKDEntry(institution="D", buy_lot=1000, sell_lot=0),
    ])
    assert tracker.ingest(snapshot) is None

def test_is_dark_room_session_boundaries():
    assert is_dark_room_session(datetime(2026, 1, 1, 18, 7, tzinfo=timezone.utc)) is True
    assert is_dark_room_session(datetime(2026, 1, 1, 18, 4, tzinfo=timezone.utc)) is False
    assert is_dark_room_session(datetime(2026, 1, 1, 18, 11, tzinfo=timezone.utc)) is False
