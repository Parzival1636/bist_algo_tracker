import asyncio
from datetime import datetime, timezone

from core.execution.order_manager import PaperBrokerAdapter, should_requeue
from models.schemas import Order, OrderBookLevel, OrderBookSnapshot, OrderStatus, Side


def test_should_requeue_true_when_bigger_competitor_ahead():
    order = Order(order_id="1", symbol="TEST", side=Side.BID, price=100.0, lot=1000)
    book = OrderBookSnapshot(symbol="TEST", timestamp=datetime.now(timezone.utc), bids=[OrderBookLevel(price=100.0, lot=5000)], asks=[])
    assert should_requeue(order, book) is True

def test_should_requeue_false_when_no_bigger_competitor():
    order = Order(order_id="1", symbol="TEST", side=Side.BID, price=100.0, lot=1000)
    book = OrderBookSnapshot(symbol="TEST", timestamp=datetime.now(timezone.utc), bids=[OrderBookLevel(price=100.0, lot=500)], asks=[])
    assert should_requeue(order, book) is False

def test_should_requeue_checks_correct_side_for_ask():
    order = Order(order_id="1", symbol="TEST", side=Side.ASK, price=100.0, lot=1000)
    book = OrderBookSnapshot(symbol="TEST", timestamp=datetime.now(timezone.utc), bids=[], asks=[OrderBookLevel(price=99.5, lot=5000)])
    assert should_requeue(order, book) is True

def test_paper_broker_place_and_cancel():
    async def run():
        broker = PaperBrokerAdapter()
        order = await broker.place_order("TEST", Side.BID, 100.0, 500)
        assert order.status == OrderStatus.NEW
        canceled = await broker.cancel_order(order.order_id)
        assert canceled is True
        open_orders = await broker.get_open_orders()
        assert order.order_id not in [o.order_id for o in open_orders]
    asyncio.run(run())

def test_paper_broker_replace_order():
    async def run():
        broker = PaperBrokerAdapter()
        order = await broker.place_order("TEST", Side.BID, 100.0, 500)
        new_order = await broker.replace_order(order.order_id, 101.0)
        assert new_order.price == 101.0
        assert new_order.status == OrderStatus.REPLACED
    asyncio.run(run())

def test_paper_broker_simulate_fill():
    async def run():
        broker = PaperBrokerAdapter()
        order = await broker.place_order("TEST", Side.BID, 100.0, 500)
        filled = broker.simulate_fill(order.order_id, 500)
        assert filled.status == OrderStatus.FILLED
    asyncio.run(run())

def test_paper_broker_get_all_orders_includes_every_status():
    async def run():
        broker = PaperBrokerAdapter()
        a = await broker.place_order("TEST", Side.BID, 100.0, 500)
        b = await broker.place_order("TEST", Side.ASK, 101.0, 300)
        await broker.cancel_order(a.order_id)
        broker.simulate_fill(b.order_id, 300)

        all_orders = await broker.get_all_orders()
        assert len(all_orders) == 2
        statuses = {o.order_id: o.status for o in all_orders}
        assert statuses[a.order_id] == OrderStatus.CANCELED
        assert statuses[b.order_id] == OrderStatus.FILLED

        open_orders = await broker.get_open_orders()
        assert open_orders == []
    asyncio.run(run())
