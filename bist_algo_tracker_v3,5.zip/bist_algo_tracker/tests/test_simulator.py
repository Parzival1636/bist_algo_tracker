"""
tests/test_simulator.py
v3.5: core/backtest/simulator.py'nin GERCEK look-ahead-bias-onleme
garantisini kanitlayan testler (sadece "calisir" degil, "gelecegi
gormedigini" ACIKCA ispatlayan bir test dahil).
"""
from __future__ import annotations

from datetime import datetime, timedelta, timezone
from typing import Any, Dict, List

import pytest

from core.backtest.simulator import LookAheadViolationError, SimulationClock, Simulator


def _msg(symbol: str, ts: datetime, lot: float) -> Dict[str, Any]:
    return {"channel": "order_book", "payload": {"symbol": symbol, "timestamp": ts.isoformat(), "lot": lot}}


class _SpyHandler:
    """Her cagrida, O ANA KADAR gordugu TUM lot degerlerini ve o anki
    SimulationClock.now degerini kaydeder - look-ahead ispati icin."""

    def __init__(self) -> None:
        self.seen_lots: List[float] = []
        self.clock_at_call: List[datetime] = []
        self.snapshot_at_each_step: List[List[float]] = []

    def on_simulated_event(self, clock: SimulationClock, message: Dict[str, Any]) -> None:
        self.seen_lots.append(message["payload"]["lot"])
        self.clock_at_call.append(clock.now)
        # bu adimda handler'in "bildigi" TUM veri kumesinin bir KOPYASI
        self.snapshot_at_each_step.append(list(self.seen_lots))


BASE = datetime(2026, 1, 1, 10, 0, 0, tzinfo=timezone.utc)


def test_events_fed_in_strict_chronological_order():
    handler = _SpyHandler()
    sim = Simulator(handler)
    events = [_msg("TEST", BASE + timedelta(seconds=i), lot=float(i)) for i in range(10)]

    sim.run(events)

    assert handler.seen_lots == [float(i) for i in range(10)]


def test_clock_now_matches_currently_processed_event_exactly():
    handler = _SpyHandler()
    sim = Simulator(handler)
    events = [_msg("TEST", BASE + timedelta(seconds=i), lot=float(i)) for i in range(5)]

    sim.run(events)

    expected_times = [BASE + timedelta(seconds=i) for i in range(5)]
    assert handler.clock_at_call == expected_times


def test_handler_never_sees_future_data_before_its_time():
    """
    KRITIK TEST - Look-ahead bias'in yapisal olarak imkansiz oldugunu
    ispatlar: handler, i. olay islenirken TAM OLARAK ilk (i+1) lotu
    gormeli - ne bir eksik ne bir fazla. Eger Simulator gelecekteki bir
    olayi erken gosterseydi, bu test suradaki assert'te BASARISIZ olurdu.
    """
    handler = _SpyHandler()
    sim = Simulator(handler)
    events = [_msg("TEST", BASE + timedelta(seconds=i), lot=float(i)) for i in range(20)]

    sim.run(events)

    for i, snapshot in enumerate(handler.snapshot_at_each_step):
        expected = [float(j) for j in range(i + 1)]  # SADECE 0..i, i+1 ve sonrasi ASLA gorulmemis olmali
        assert snapshot == expected, (
            f"LOOK-AHEAD BIAS TESPIT EDILDI: {i}. adimda handler {snapshot} gordu, "
            f"beklenen {expected} idi (gelecek veri sizintisi olabilir)."
        )


def test_raises_on_out_of_order_events():
    handler = _SpyHandler()
    sim = Simulator(handler)
    events = [
        _msg("TEST", BASE + timedelta(seconds=5), lot=1.0),
        _msg("TEST", BASE + timedelta(seconds=2), lot=2.0),  # GERIYE sicrama
    ]

    with pytest.raises(LookAheadViolationError):
        sim.run(events)

    # ilk (gecerli) olay islenmis olmali, ikincisi (ihlal) ISLENMEMIS olmali
    assert handler.seen_lots == [1.0]


def test_missing_timestamp_raises_value_error():
    handler = _SpyHandler()
    sim = Simulator(handler)
    bad_event = {"channel": "order_book", "payload": {"symbol": "TEST"}}  # timestamp yok

    with pytest.raises(ValueError):
        sim.run([bad_event])


def test_simulation_stats_are_accurate():
    handler = _SpyHandler()
    sim = Simulator(handler)
    events = [_msg("TEST", BASE + timedelta(seconds=i), lot=float(i)) for i in range(4)]

    stats = sim.run(events)

    assert stats.events_processed == 4
    assert stats.start_time == BASE
    assert stats.end_time == BASE + timedelta(seconds=3)
    assert stats.duration_seconds == 3.0


def test_empty_event_stream_produces_zero_stats():
    handler = _SpyHandler()
    sim = Simulator(handler)

    stats = sim.run([])

    assert stats.events_processed == 0
    assert stats.start_time is None
    assert stats.duration_seconds is None
