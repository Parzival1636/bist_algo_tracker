"""
tests/test_nats_messaging.py
messaging/nats_bus.py'nin GERCEK bir nats-server'a karsi entegrasyon testi.

nats-server ikili dosyasi bulunamazsa bu test SKIP edilir - base test
suite'ini (`pytest`) calistirmak icin nats-server GEREKMEZ, sadece bu
tek entegrasyon testi es gecilir. Kurulum: NATS_SERVER_BIN ortam
degiskenini ikili dosyanin yoluna ayarlayin ya da PATH'e ekleyin.
  https://github.com/nats-io/nats-server/releases
"""
from __future__ import annotations

import asyncio
import os
import shutil
import socket
import subprocess
import time

import pytest

NATS_BIN = os.environ.get("NATS_SERVER_BIN") or shutil.which("nats-server")


def _free_port() -> int:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("localhost", 0))
        return s.getsockname()[1]


@pytest.mark.skipif(NATS_BIN is None, reason="nats-server ikili dosyasi bulunamadi")
def test_nats_bus_real_pubsub_roundtrip():
    from messaging.nats_bus import NATSMessageBus

    port = _free_port()
    proc = subprocess.Popen([NATS_BIN, "-p", str(port)], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    try:
        time.sleep(1.5)

        async def run():
            bus = NATSMessageBus(servers=f"nats://localhost:{port}")

            async def subscriber():
                received = []
                async for msg in bus.subscribe("bist.test.roundtrip"):
                    received.append(msg)
                    if len(received) >= 2:
                        break
                return received

            task = asyncio.create_task(subscriber())
            await asyncio.sleep(0.5)
            await bus.publish("bist.test.roundtrip", {"seq": 0})
            await bus.publish("bist.test.roundtrip", {"seq": 1})
            received = await asyncio.wait_for(task, timeout=5)
            await bus.close()
            return received

        received = asyncio.run(run())
        assert len(received) == 2
        assert received[0]["seq"] == 0
        assert received[1]["seq"] == 1
    finally:
        proc.terminate()
        try:
            proc.wait(timeout=5)
        except subprocess.TimeoutExpired:
            proc.kill()
