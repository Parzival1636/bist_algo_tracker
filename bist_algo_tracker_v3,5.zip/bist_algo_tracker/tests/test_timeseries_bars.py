"""tests/test_timeseries_bars.py - OHLCV bar depolama/sorgu doğruluğu."""
from datetime import datetime, timedelta, timezone

from db.timeseries_client import OHLCVBar, SQLiteTimeseriesStore

BASE = datetime(2026, 1, 1, tzinfo=timezone.utc)


def test_write_and_query_bars_roundtrip(tmp_path):
    store = SQLiteTimeseriesStore(db_path=str(tmp_path / "bars.db"))
    bars = [
        OHLCVBar(symbol="THYAO", timeframe="1m", open=100, high=105, low=98, close=102, volume=500,
                 timestamp=BASE + timedelta(minutes=i))
        for i in range(3)
    ]
    store.write_bars(bars)

    result = store.query_bars("THYAO", "1m", limit=10)
    assert len(result) == 3
    # kronolojik sirada (eskiden yeniye) donmeli - Simulator'a dogrudan beslenebilsin diye
    assert result[0].timestamp < result[1].timestamp < result[2].timestamp


def test_query_bars_respects_limit_and_returns_most_recent(tmp_path):
    store = SQLiteTimeseriesStore(db_path=str(tmp_path / "bars2.db"))
    bars = [
        OHLCVBar(symbol="GARAN", timeframe="1m", open=1, high=1, low=1, close=1, volume=1,
                 timestamp=BASE + timedelta(minutes=i))
        for i in range(10)
    ]
    store.write_bars(bars)

    result = store.query_bars("GARAN", "1m", limit=3)
    assert len(result) == 3
    # en YENI 3 tanesi olmali (7,8,9. dakikalar), kronolojik sirada
    assert result[0].timestamp == BASE + timedelta(minutes=7)
    assert result[-1].timestamp == BASE + timedelta(minutes=9)


def test_bars_isolated_by_symbol_and_timeframe(tmp_path):
    store = SQLiteTimeseriesStore(db_path=str(tmp_path / "bars3.db"))
    store.write_bars([
        OHLCVBar(symbol="THYAO", timeframe="1m", open=1, high=1, low=1, close=1, volume=1, timestamp=BASE),
        OHLCVBar(symbol="THYAO", timeframe="5m", open=2, high=2, low=2, close=2, volume=2, timestamp=BASE),
        OHLCVBar(symbol="GARAN", timeframe="1m", open=3, high=3, low=3, close=3, volume=3, timestamp=BASE),
    ])
    result = store.query_bars("THYAO", "1m", limit=10)
    assert len(result) == 1
    assert result[0].open == 1
