import pytest

from core.execution.algo_execution import plan_twap, plan_vwap


def test_twap_slices_sum_to_total():
    slices = plan_twap(total_lot=10_000, horizon_seconds=100, slice_count=10)
    assert len(slices) == 10
    assert sum(s.lot for s in slices) == pytest.approx(10_000)
    assert all(s.lot == pytest.approx(1000) for s in slices)

def test_twap_offsets_evenly_spaced():
    slices = plan_twap(total_lot=1000, horizon_seconds=100, slice_count=5)
    offsets = [s.offset_seconds for s in slices]
    assert offsets == [0, 20, 40, 60, 80]

def test_twap_rejects_invalid_input():
    with pytest.raises(ValueError):
        plan_twap(total_lot=1000, horizon_seconds=100, slice_count=0)
    with pytest.raises(ValueError):
        plan_twap(total_lot=0, horizon_seconds=100, slice_count=5)

def test_vwap_slices_sum_to_total():
    profile = [1, 2, 3, 4]  # artan hacim agirligi
    slices = plan_vwap(total_lot=1000, horizon_seconds=40, volume_profile=profile)
    assert sum(s.lot for s in slices) == pytest.approx(1000)

def test_vwap_proportional_to_profile():
    profile = [1, 3]  # ikinci dilim uc kat agirlikli
    slices = plan_vwap(total_lot=400, horizon_seconds=20, volume_profile=profile)
    assert slices[0].lot == pytest.approx(100)
    assert slices[1].lot == pytest.approx(300)

def test_vwap_rejects_invalid_profile():
    with pytest.raises(ValueError):
        plan_vwap(total_lot=1000, horizon_seconds=10, volume_profile=[])
    with pytest.raises(ValueError):
        plan_vwap(total_lot=1000, horizon_seconds=10, volume_profile=[-1, 2])
    with pytest.raises(ValueError):
        plan_vwap(total_lot=1000, horizon_seconds=10, volume_profile=[0, 0])
