from core.execution.risk_engine import RiskEngine
from models.schemas import Position


def _position_with_engine(entry: float = 100.0, trailing_pct: float = 0.02):
    engine = RiskEngine(fixed_stop_loss_pct=0.02, trailing_stop_pct=trailing_pct)
    position = Position(symbol="TEST", lot=100, avg_cost=entry, stop_price=engine.initial_stop_price(entry))
    return position, engine

def test_initial_stop_price():
    engine = RiskEngine(fixed_stop_loss_pct=0.02)
    assert engine.initial_stop_price(100.0) == 98.0

def test_trailing_stop_only_moves_up():
    position, engine = _position_with_engine(entry=100.0, trailing_pct=0.02)
    engine.update_trailing_stop(position, current_price=110.0)
    first_trail = position.trailing_stop_price
    assert first_trail == 110.0 * 0.98
    engine.update_trailing_stop(position, current_price=105.0)
    assert position.trailing_stop_price == first_trail

def test_trailing_stop_rises_with_new_high():
    position, engine = _position_with_engine(entry=100.0, trailing_pct=0.02)
    engine.update_trailing_stop(position, current_price=110.0)
    engine.update_trailing_stop(position, current_price=120.0)
    assert position.trailing_stop_price == 120.0 * 0.98

def test_should_stop_out_fixed_stop():
    position, engine = _position_with_engine(entry=100.0)
    assert engine.should_stop_out(position, current_price=97.0) is True
    assert engine.should_stop_out(position, current_price=99.0) is False

def test_should_stop_out_uses_higher_of_fixed_and_trailing():
    position, engine = _position_with_engine(entry=100.0, trailing_pct=0.02)
    engine.update_trailing_stop(position, current_price=200.0)
    assert engine.effective_stop(position) == 200.0 * 0.98
    assert engine.should_stop_out(position, current_price=195.0) is True

def test_max_20_percent_portfolio_limit():
    engine = RiskEngine(max_portfolio_pct_per_symbol=0.20)
    assert engine.can_open_position(proposed_value=15_000, portfolio_value=100_000) is True
    assert engine.can_open_position(proposed_value=25_000, portfolio_value=100_000) is False
    assert engine.can_open_position(proposed_value=5_000, portfolio_value=100_000, existing_symbol_value=16_000) is False

def test_can_open_position_rejects_invalid_portfolio():
    engine = RiskEngine()
    assert engine.can_open_position(proposed_value=1_000, portfolio_value=0) is False
