from core.analytics.adaptive_thresholds import AdaptiveThresholdTracker


def test_returns_none_before_min_samples():
    tracker = AdaptiveThresholdTracker(min_samples=10)
    for _ in range(9):
        assert tracker.update(1.0) is None

def test_does_not_flag_normal_continuation_in_noisy_regime():
    tracker = AdaptiveThresholdTracker(window=100, min_samples=30, z_threshold=3.0)
    noisy_values = [0.48, 0.51, 0.49, 0.52, 0.47, 0.50, 0.49, 0.51, 0.48, 0.50] * 4
    for v in noisy_values:
        tracker.update(v)
    # Rejimin tipik araliginda kalan bir deger anomali sayilmamali
    assert tracker.is_anomalous(0.50) is False

def test_low_variance_regime_flags_large_jump():
    tracker = AdaptiveThresholdTracker(window=200, min_samples=30, z_threshold=3.0)
    values = [0.40, 0.42, 0.41, 0.39, 0.43, 0.40, 0.41, 0.42, 0.39, 0.40] * 4
    for v in values:
        tracker.update(v)
    assert tracker.has_enough_data is True
    assert tracker.is_anomalous(0.95) is True  # rejimin cok disinda

def test_zero_stdev_regime_returns_zero_zscore_not_crash():
    tracker = AdaptiveThresholdTracker(min_samples=5)
    for _ in range(10):
        z = tracker.update(1.0)
    assert z == 0.0

def test_rejects_invalid_min_samples():
    import pytest
    with pytest.raises(ValueError):
        AdaptiveThresholdTracker(min_samples=1)
