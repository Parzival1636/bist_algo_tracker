"""tests/test_daily_loss_guard.py - Günlük zarar siniri kapisinin doğruluğu."""
from datetime import date

from core.execution.autonomous_engine import DailyLossGuard

DAY1 = date(2026, 1, 1)
DAY2 = date(2026, 1, 2)


def test_not_halted_with_no_activity():
    guard = DailyLossGuard(max_daily_loss=10_000)
    assert guard.is_halted(DAY1) is False


def test_not_halted_with_positive_pnl():
    guard = DailyLossGuard(max_daily_loss=10_000)
    guard.record_fill_pnl(5_000, DAY1)
    assert guard.is_halted(DAY1) is False


def test_not_halted_below_threshold():
    guard = DailyLossGuard(max_daily_loss=10_000)
    guard.record_fill_pnl(-9_999, DAY1)
    assert guard.is_halted(DAY1) is False


def test_halted_exactly_at_threshold():
    guard = DailyLossGuard(max_daily_loss=10_000)
    guard.record_fill_pnl(-10_000, DAY1)
    assert guard.is_halted(DAY1) is True


def test_halted_beyond_threshold():
    guard = DailyLossGuard(max_daily_loss=10_000)
    guard.record_fill_pnl(-4_000, DAY1)
    guard.record_fill_pnl(-4_000, DAY1)
    guard.record_fill_pnl(-4_000, DAY1)  # kumulatif: -12.000
    assert guard.is_halted(DAY1) is True


def test_resets_on_new_day():
    guard = DailyLossGuard(max_daily_loss=10_000)
    guard.record_fill_pnl(-15_000, DAY1)
    assert guard.is_halted(DAY1) is True
    assert guard.is_halted(DAY2) is False  # YENI gun - sifirlanmis olmali


def test_realized_pnl_today_tracks_cumulative_value():
    guard = DailyLossGuard(max_daily_loss=10_000)
    guard.record_fill_pnl(1_000, DAY1)
    guard.record_fill_pnl(-500, DAY1)
    assert guard.realized_pnl_today(DAY1) == 500
    assert guard.realized_pnl_today(DAY2) == 0  # farkli gun icin sifir doner
