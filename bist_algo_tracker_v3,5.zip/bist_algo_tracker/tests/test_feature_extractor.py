"""tests/test_feature_extractor.py - Özellik çıkarımının doğruluğu."""
import pytest

from core.analytics.feature_extractor import FeatureExtractor


def test_extract_returns_raw_obi_immediately():
    fx = FeatureExtractor("TEST", momentum_window=4)
    features = fx.extract(bid_volume=300, ask_volume=100, traded_volume=50)
    assert features.obi == 0.5
    assert features.symbol == "TEST"


def test_obi_zscore_is_none_during_warmup():
    fx = FeatureExtractor("TEST", momentum_window=4)
    features = fx.extract(bid_volume=100, ask_volume=100, traded_volume=10)
    assert features.obi_zscore is None
    assert features.is_significant is False


def test_volume_momentum_is_none_until_window_fills():
    fx = FeatureExtractor("TEST", momentum_window=4)
    f1 = fx.extract(bid_volume=100, ask_volume=100, traded_volume=10)
    f2 = fx.extract(bid_volume=100, ask_volume=100, traded_volume=10)
    f3 = fx.extract(bid_volume=100, ask_volume=100, traded_volume=10)
    assert f1.volume_momentum is None
    assert f2.volume_momentum is None
    assert f3.volume_momentum is None  # pencere=4, henuz 3 deger var


def test_volume_momentum_computed_correctly_once_window_fills():
    fx = FeatureExtractor("TEST", momentum_window=4)
    for v in [10, 10, 20, 20]:
        features = fx.extract(bid_volume=100, ask_volume=100, traded_volume=v)
    # older=[10,10] avg=10, newer=[20,20] avg=20 -> (20-10)/10 = 1.0
    assert features.volume_momentum == pytest.approx(1.0)


def test_volume_momentum_negative_when_volume_declines():
    fx = FeatureExtractor("TEST", momentum_window=4)
    for v in [40, 40, 20, 20]:
        features = fx.extract(bid_volume=100, ask_volume=100, traded_volume=v)
    # older avg=40, newer avg=20 -> (20-40)/40 = -0.5
    assert features.volume_momentum == pytest.approx(-0.5)


def test_is_significant_flags_extreme_obi_after_warmup():
    fx = FeatureExtractor("TEST", obi_z_threshold=2.0, momentum_window=4)
    # dusuk-varyansli "normal" rejim ile isindir (AdaptiveThresholdTracker min_samples=30 varsayilan)
    for _ in range(35):
        fx.extract(bid_volume=105, ask_volume=95, traded_volume=100)  # OBI ~0.05, sabit
    # simdi belirgin bir anomali besle
    features = fx.extract(bid_volume=950, ask_volume=50, traded_volume=100)  # OBI=0.9, rejimin cok disinda
    assert features.is_significant is True


def test_rejects_momentum_window_below_two():
    with pytest.raises(ValueError):
        FeatureExtractor("TEST", momentum_window=1)


def test_feature_vector_is_frozen():
    fx = FeatureExtractor("TEST")
    features = fx.extract(bid_volume=100, ask_volume=100, traded_volume=10)
    with pytest.raises(Exception):  # dataclasses.FrozenInstanceError, AttributeError uzerinden
        features.obi = 999.0  # type: ignore[misc]
