from core.analytics.layering_detector import LayeringDetector


def test_flags_correlated_cancels_across_levels():
    detector = LayeringDetector(correlation_window_seconds=0.5, min_correlated_levels=3, large_order_lot=20_000)
    assert detector.on_order_canceled(price=100.0, lot=25_000, ts=10.00) is None
    assert detector.on_order_canceled(price=100.5, lot=25_000, ts=10.05) is None
    result = detector.on_order_canceled(price=101.0, lot=25_000, ts=10.10)
    assert result is not None
    assert result == {100.0, 100.5, 101.0}

def test_ignores_small_orders():
    detector = LayeringDetector(large_order_lot=20_000)
    assert detector.on_order_canceled(price=100.0, lot=500, ts=1.0) is None
    assert detector.on_order_canceled(price=100.5, lot=500, ts=1.01) is None
    assert detector.on_order_canceled(price=101.0, lot=500, ts=1.02) is None

def test_same_level_repeated_does_not_count_as_multiple_levels():
    detector = LayeringDetector(correlation_window_seconds=0.5, min_correlated_levels=3, large_order_lot=20_000)
    for i in range(5):
        result = detector.on_order_canceled(price=100.0, lot=25_000, ts=1.0 + i * 0.05)
    assert result is None  # hep AYNI kademe -> tek distinct level

def test_window_expiry_resets_correlation():
    detector = LayeringDetector(correlation_window_seconds=0.2, min_correlated_levels=3, large_order_lot=20_000)
    assert detector.on_order_canceled(price=100.0, lot=25_000, ts=0.0) is None
    assert detector.on_order_canceled(price=100.5, lot=25_000, ts=0.05) is None
    # pencere disi - eski ikisi dusmeli
    result = detector.on_order_canceled(price=101.0, lot=25_000, ts=5.0)
    assert result is None
