import asyncio

from backtest.engine import BacktestEngine
from backtest.historical_player import HistoricalDataPlayer


def test_synthetic_data_generation():
    player = asyncio.run(HistoricalDataPlayer.generate_synthetic(symbols=["TEST"], tick_count=60, seed=7))
    assert len(player) == 60

def test_backtest_runs_end_to_end_without_errors():
    player = asyncio.run(HistoricalDataPlayer.generate_synthetic(symbols=["TEST"], tick_count=120, seed=7))
    engine = BacktestEngine(symbols=["TEST"])
    summary = engine.run(player.replay())
    assert summary.tick_count > 0
    assert summary.symbol == "TEST"
    assert isinstance(summary.alerts_by_type, dict)
    assert summary.alert_count == sum(summary.alerts_by_type.values())

def test_backtest_handles_multiple_symbols():
    player = asyncio.run(HistoricalDataPlayer.generate_synthetic(symbols=["AAA", "BBB"], tick_count=100, seed=3))
    engine = BacktestEngine(symbols=["AAA", "BBB"])
    summary = engine.run(player.replay())
    assert summary.tick_count > 0
