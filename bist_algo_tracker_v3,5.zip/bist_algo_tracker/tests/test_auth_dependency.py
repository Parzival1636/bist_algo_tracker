"""
tests/test_auth_dependency.py
v3.5 AppSec: api/dependencies/auth.py'nin GERCEK guvenlik garantilerini
dogrular - hem SecretStr maskelemesi hem de log redaksiyon katmani.
"""
from __future__ import annotations

import asyncio
import logging

from fastapi import Depends, FastAPI
from fastapi.testclient import TestClient

from api.dependencies.auth import BrokerCredentials, get_broker_credentials, require_broker_credentials
from config.log_redaction import SecretRedactingFilter, clear_registered_secrets, register_secret_for_redaction
from config.logging_config import get_logger

FAKE_SECRET = "cok-gizli-anahtar-XYZ-98765"


def _build_test_app() -> FastAPI:
    app = FastAPI()

    @app.get("/optional-creds")
    async def optional_creds(creds: BrokerCredentials = Depends(get_broker_credentials)):
        return {"has_broker": creds.has_broker_credentials, "has_data_provider": creds.has_data_provider_credentials}

    @app.get("/required-creds")
    async def required_creds(creds: BrokerCredentials = Depends(require_broker_credentials)):
        return {"has_broker": creds.has_broker_credentials}

    return app


# --- 1) SecretStr maskelemesi (birinci savunma hatti) ---

def test_broker_credentials_repr_never_leaks_secret():
    creds = BrokerCredentials(broker_api_key="gizli-key-123", broker_secret_key="gizli-secret-456")  # type: ignore[arg-type]
    rendered = repr(creds)
    assert "gizli-key-123" not in rendered
    assert "gizli-secret-456" not in rendered
    assert "**********" in rendered


def test_broker_credentials_str_via_fstring_never_leaks_secret():
    creds = BrokerCredentials(broker_api_key="baska-bir-gizli-anahtar")  # type: ignore[arg-type]
    assert "baska-bir-gizli-anahtar" not in f"{creds}"
    assert "baska-bir-gizli-anahtar" not in str(creds.broker_api_key)


def test_get_secret_value_still_accessible_when_explicitly_requested():
    creds = BrokerCredentials(broker_api_key="acikca-istenen-deger")  # type: ignore[arg-type]
    assert creds.broker_api_key.get_secret_value() == "acikca-istenen-deger"


# --- 2) FastAPI Depends() entegrasyonu ---

def test_optional_creds_endpoint_without_headers():
    client = TestClient(_build_test_app())
    r = client.get("/optional-creds")
    assert r.status_code == 200
    assert r.json() == {"has_broker": False, "has_data_provider": False}


def test_optional_creds_endpoint_with_headers():
    client = TestClient(_build_test_app())
    r = client.get("/optional-creds", headers={"X-Broker-Key": "k1", "X-Broker-Secret": "s1"})
    assert r.status_code == 200
    assert r.json() == {"has_broker": True, "has_data_provider": False}


def test_required_creds_endpoint_401_when_missing():
    client = TestClient(_build_test_app())
    r = client.get("/required-creds")
    assert r.status_code == 401


def test_required_creds_endpoint_ok_when_present():
    client = TestClient(_build_test_app())
    r = client.get("/required-creds", headers={"X-Broker-Key": "k1", "X-Broker-Secret": "s1"})
    assert r.status_code == 200
    assert r.json() == {"has_broker": True}


def test_response_body_never_echoes_raw_secret_value():
    """Uc, header'lardaki HAM degerleri yanit govdesine ASLA kopyalamamali."""
    client = TestClient(_build_test_app())
    r = client.get("/optional-creds", headers={"X-Broker-Secret": FAKE_SECRET})
    assert FAKE_SECRET not in r.text


# --- 3) Log redaksiyon katmani (ikinci/savunma-derinligi hatti) ---

def test_redaction_filter_scrubs_registered_secret_from_log_output(caplog):
    clear_registered_secrets()
    logger = get_logger("test.redaction")
    logger.addFilter(SecretRedactingFilter())

    register_secret_for_redaction(FAKE_SECRET)
    with caplog.at_level(logging.INFO, logger="test.redaction"):
        # KASITLI olarak "yanlislikla" ham degeri f-string ile loglayan bir senaryo simule edilir.
        logger.info(f"Debug amacli deger loglaniyor: {FAKE_SECRET}")

    assert FAKE_SECRET not in caplog.text
    assert "***REDACTED***" in caplog.text


def test_redaction_filter_does_not_touch_unrelated_messages():
    clear_registered_secrets()
    register_secret_for_redaction(FAKE_SECRET)
    record = logging.LogRecord("test", logging.INFO, __file__, 1, "sıradan bir log mesajı", None, None)
    filt = SecretRedactingFilter()
    filt.filter(record)
    assert record.getMessage() == "sıradan bir log mesajı"


def test_redaction_filter_ignores_very_short_values():
    """Kisa/genel degerlerin (ornegin bos string) yanlislikla her yerde
    redakte edilmesini onlemek icin minimum uzunluk esigi vardır."""
    clear_registered_secrets()
    register_secret_for_redaction("ab")  # esigin altinda
    record = logging.LogRecord("test", logging.INFO, __file__, 1, "deger: ab", None, None)
    filt = SecretRedactingFilter()
    filt.filter(record)
    assert record.getMessage() == "deger: ab"  # redakte EDILMEMELI


def test_redaction_context_is_isolated_between_concurrent_tasks():
    """Iki 'istek' (asyncio Task) birbirinin kayitli gizli degerini GORMEMELI -
    ASGI istek izolasyonunun contextvars ile dogru calistigini kanitlar."""
    clear_registered_secrets()

    async def scenario():
        results = {}

        async def task_a():
            register_secret_for_redaction("TASK-A-SECRET")
            await asyncio.sleep(0.05)  # task_b'nin kendi kaydini yapmasina firsat ver
            record = logging.LogRecord("t", logging.INFO, __file__, 1, "TASK-A-SECRET gorunuyor mu", None, None)
            SecretRedactingFilter().filter(record)
            results["a_sees_own_secret_redacted"] = "***REDACTED***" in record.getMessage()

            record2 = logging.LogRecord("t", logging.INFO, __file__, 1, "TASK-B-SECRET gorunuyor mu", None, None)
            SecretRedactingFilter().filter(record2)
            results["a_sees_b_secret_redacted"] = "***REDACTED***" in record2.getMessage()

        async def task_b():
            register_secret_for_redaction("TASK-B-SECRET")
            await asyncio.sleep(0.05)

        await asyncio.gather(asyncio.create_task(task_a()), asyncio.create_task(task_b()))
        return results

    results = asyncio.run(scenario())
    # task_a KENDI kaydettigi sirri redakte edebilmeli...
    assert results["a_sees_own_secret_redacted"] is True
    # ...ama task_b'nin (baska bir 'istegin') sirrini GORMEMELI/redakte edememeli
    # (cunku kendi context'inde kayitli degil) - izolasyonun kaniti budur.
    assert results["a_sees_b_secret_redacted"] is False
