import os
from datetime import datetime, timezone

from db.timeseries_client import SQLiteTimeseriesStore, TickRecord


def test_write_and_query_roundtrip(tmp_path):
    db_path = str(tmp_path / "ts_test.db")
    store = SQLiteTimeseriesStore(db_path=db_path)
    now = datetime.now(timezone.utc)
    store.write(TickRecord(symbol="THYAO", metric_name="otr", value=0.42, timestamp=now))
    results = store.query_recent("THYAO", "otr", limit=10)
    assert len(results) == 1
    assert results[0].symbol == "THYAO"
    assert results[0].value == 0.42

def test_write_many_and_ordering(tmp_path):
    db_path = str(tmp_path / "ts_test2.db")
    store = SQLiteTimeseriesStore(db_path=db_path)
    base = datetime(2026, 1, 1, tzinfo=timezone.utc)
    records = [
        TickRecord(symbol="GARAN", metric_name="obi", value=float(i), timestamp=base.replace(hour=i))
        for i in range(1, 6)
    ]
    store.write_many(records)
    results = store.query_recent("GARAN", "obi", limit=3)
    assert len(results) == 3
    # en yeniden en eskiye siralanmali
    assert results[0].value == 5.0
    assert results[1].value == 4.0

def test_query_filters_by_symbol_and_metric(tmp_path):
    db_path = str(tmp_path / "ts_test3.db")
    store = SQLiteTimeseriesStore(db_path=db_path)
    now = datetime.now(timezone.utc)
    store.write(TickRecord(symbol="THYAO", metric_name="otr", value=1.0, timestamp=now))
    store.write(TickRecord(symbol="GARAN", metric_name="otr", value=2.0, timestamp=now))
    store.write(TickRecord(symbol="THYAO", metric_name="obi", value=3.0, timestamp=now))
    results = store.query_recent("THYAO", "otr", limit=10)
    assert len(results) == 1
    assert results[0].value == 1.0
