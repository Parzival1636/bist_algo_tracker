import asyncio

import pytest

from core.resilience.backpressure import BoundedDropOldestQueue


def test_drops_oldest_when_full():
    async def run():
        q: BoundedDropOldestQueue[int] = BoundedDropOldestQueue(maxsize=3)
        for i in range(5):
            await q.put(i)
        assert q.dropped_count == 2
        assert q.qsize() == 3
        # Kalanlar en YENI 3 eleman olmali: 2, 3, 4
        remaining = [await q.get() for _ in range(3)]
        assert remaining == [2, 3, 4]
    asyncio.run(run())

def test_no_drops_when_under_capacity():
    async def run():
        q: BoundedDropOldestQueue[int] = BoundedDropOldestQueue(maxsize=10)
        for i in range(5):
            await q.put(i)
        assert q.dropped_count == 0
        assert q.qsize() == 5
    asyncio.run(run())

def test_rejects_invalid_maxsize():
    with pytest.raises(ValueError):
        BoundedDropOldestQueue(maxsize=0)
