"""tests/test_analytics_handler.py - Simulator + gercek analitik motorlarinin entegrasyonu."""
import asyncio

from core.backtest.analytics_handler import AnalyticsEngineHandler
from core.backtest.simulator import Simulator
from core.ingestion.websocket_client import SimulatedMarketDataSource


def test_analytics_handler_processes_synthetic_stream_via_simulator():
    async def generate():
        source = SimulatedMarketDataSource(symbols=["TEST"], seed=11, realtime=False)
        messages = []
        async for msg in source.stream():
            messages.append(msg)
            if len(messages) >= 150:
                break
        return messages

    messages = asyncio.run(generate())
    # Simulator KESINLIKLE kronolojik sira ister - sentetik veri zaten sirali
    # uretilir, burada Simulator'un GERCEK analitik motorlarla birlikte
    # cokmeden calistigini dogruluyoruz.
    handler = AnalyticsEngineHandler(symbols=["TEST"])
    sim = Simulator(handler)

    stats = sim.run(messages)

    assert stats.events_processed > 0
    assert sim.clock.now is not None
    # v1+v2 dedektorlerinin en az bazilari sentetik veride tetiklenmis olmali
    assert isinstance(handler.alerts, list)
