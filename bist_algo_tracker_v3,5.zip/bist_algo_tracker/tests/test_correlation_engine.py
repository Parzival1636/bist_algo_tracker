from core.analytics.correlation_engine import CrossSymbolCorrelationEngine


def test_flags_institution_active_across_multiple_symbols():
    engine = CrossSymbolCorrelationEngine(window_seconds=300, min_symbol_count=3)
    assert engine.on_net_buyer("BofA", "THYAO", ts=100.0) is None
    assert engine.on_net_buyer("BofA", "GARAN", ts=105.0) is None
    result = engine.on_net_buyer("BofA", "ASELS", ts=110.0)
    assert result == {"THYAO", "GARAN", "ASELS"}

def test_does_not_flag_single_symbol_repeated():
    engine = CrossSymbolCorrelationEngine(min_symbol_count=3)
    for ts in [1.0, 2.0, 3.0, 4.0]:
        result = engine.on_net_buyer("BofA", "THYAO", ts=ts)
    assert result is None

def test_different_institutions_tracked_independently():
    engine = CrossSymbolCorrelationEngine(min_symbol_count=2)
    assert engine.on_net_buyer("BofA", "THYAO", ts=1.0) is None
    result = engine.on_net_buyer("İş Yatırım", "GARAN", ts=1.5)
    assert result is None  # farkli kurum, kendi sayaci ayri

def test_window_expiry():
    engine = CrossSymbolCorrelationEngine(window_seconds=10, min_symbol_count=2)
    assert engine.on_net_buyer("BofA", "THYAO", ts=0.0) is None
    result = engine.on_net_buyer("BofA", "GARAN", ts=100.0)  # cok sonra, pencere disi
    assert result is None
