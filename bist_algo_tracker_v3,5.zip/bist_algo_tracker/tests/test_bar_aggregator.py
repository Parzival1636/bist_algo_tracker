"""tests/test_bar_aggregator.py - tick -> OHLCV bar üretiminin doğruluğu."""
from datetime import datetime, timedelta, timezone

import pytest

from core.analytics.bar_aggregator import BarAggregator

BASE = datetime(2026, 1, 1, 10, 0, 0, tzinfo=timezone.utc)


def test_first_trade_opens_bar_without_completing():
    agg = BarAggregator("TEST", timeframe="1s")
    result = agg.on_trade(price=100.0, lot=10, ts=BASE)
    assert result is None


def test_same_window_trades_do_not_complete_bar():
    agg = BarAggregator("TEST", timeframe="1s")
    agg.on_trade(price=100.0, lot=10, ts=BASE)
    result = agg.on_trade(price=101.0, lot=5, ts=BASE + timedelta(milliseconds=500))
    assert result is None  # hala AYNI 1sn'lik pencerede


def test_new_window_completes_previous_bar_with_correct_ohlcv():
    agg = BarAggregator("TEST", timeframe="1s")
    agg.on_trade(price=100.0, lot=10, ts=BASE)
    agg.on_trade(price=105.0, lot=5, ts=BASE + timedelta(milliseconds=200))  # high
    agg.on_trade(price=98.0, lot=3, ts=BASE + timedelta(milliseconds=400))   # low
    agg.on_trade(price=102.0, lot=2, ts=BASE + timedelta(milliseconds=600))  # close

    bar = agg.on_trade(price=200.0, lot=1, ts=BASE + timedelta(seconds=1))  # YENI pencere -> tamamlar

    assert bar is not None
    assert bar.open == 100.0
    assert bar.high == 105.0
    assert bar.low == 98.0
    assert bar.close == 102.0
    assert bar.volume == 20  # 10+5+3+2
    assert bar.timestamp == BASE
    assert bar.symbol == "TEST"
    assert bar.timeframe == "1s"


def test_multiple_window_transitions_each_complete_exactly_one_bar():
    agg = BarAggregator("TEST", timeframe="1s")
    completed = []
    for i in range(5):
        result = agg.on_trade(price=100.0 + i, lot=1, ts=BASE + timedelta(seconds=i))
        if result is not None:
            completed.append(result)
    assert len(completed) == 4  # ilk pencere ACIK kalir, sonraki 4 gecis 4 bar tamamlar


def test_flush_returns_last_open_bar():
    agg = BarAggregator("TEST", timeframe="1s")
    agg.on_trade(price=50.0, lot=7, ts=BASE)
    bar = agg.flush()
    assert bar is not None
    assert bar.volume == 7
    assert agg.flush() is None  # ikinci flush -> artik acik bar yok


def test_backward_timestamp_raises():
    agg = BarAggregator("TEST", timeframe="1s")
    agg.on_trade(price=100.0, lot=1, ts=BASE + timedelta(seconds=5))
    with pytest.raises(ValueError):
        agg.on_trade(price=100.0, lot=1, ts=BASE)  # GERIYE gidiyor


def test_rejects_unknown_timeframe():
    with pytest.raises(ValueError):
        BarAggregator("TEST", timeframe="3q")
