import pybreaker
import pytest

from core.resilience.circuit_breaker import make_breaker


def test_breaker_trips_after_fail_max():
    breaker = make_breaker("test-breaker", fail_max=3, reset_timeout=10.0)

    def flaky():
        raise RuntimeError("bagimlilik cevap vermiyor")

    # Ilk fail_max-1 cagri normal RuntimeError firlatir.
    for _ in range(2):
        with pytest.raises(RuntimeError):
            breaker.call(flaky)

    # fail_max'a ULASAN cagri devreyi acar VE pybreaker'in varsayilan
    # davranisiyla (throw_new_error_on_trip=True) orijinal hata yerine
    # DOGRUDAN CircuitBreakerError firlatir - gercek kutuphaneye karsi
    # test edilerek dogrulandi.
    with pytest.raises(pybreaker.CircuitBreakerError):
        breaker.call(flaky)

    # Devre artik acik - sonraki her cagri da CircuitBreakerError firlatir.
    with pytest.raises(pybreaker.CircuitBreakerError):
        breaker.call(flaky)

    assert breaker.current_state == "open"

def test_breaker_stays_closed_under_fail_max():
    breaker = make_breaker("test-breaker-2", fail_max=5, reset_timeout=10.0)

    def flaky():
        raise RuntimeError("gecici hata")

    for _ in range(3):  # fail_max=5, henuz tetiklenmemeli
        with pytest.raises(RuntimeError):
            breaker.call(flaky)

    assert breaker.current_state == "closed"

def test_breaker_allows_successful_calls():
    breaker = make_breaker("test-breaker-3", fail_max=3, reset_timeout=10.0)
    result = breaker.call(lambda: 42)
    assert result == 42
    assert breaker.current_state == "closed"
