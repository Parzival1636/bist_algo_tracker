from core.analytics.iceberg_detector import IcebergDetector


def test_flags_repeated_near_identical_executions():
    detector = IcebergDetector(min_repeats=4, max_relative_stdev=0.15)
    flagged = False
    for lot in [1000, 1010, 995, 1005, 998]:
        flagged = detector.on_execution(price=50.0, lot=lot)
    assert flagged is True

def test_does_not_flag_highly_variable_executions():
    detector = IcebergDetector(min_repeats=4, max_relative_stdev=0.15)
    flagged = False
    for lot in [500, 3000, 200, 8000, 100]:
        flagged = detector.on_execution(price=50.0, lot=lot)
    assert flagged is False

def test_needs_min_repeats_before_flagging():
    detector = IcebergDetector(min_repeats=4)
    assert detector.on_execution(price=50.0, lot=1000) is False
    assert detector.on_execution(price=50.0, lot=1000) is False

def test_different_price_levels_tracked_independently():
    detector = IcebergDetector(min_repeats=3, max_relative_stdev=0.15)
    for lot in [1000, 1000, 1000]:
        detector.on_execution(price=50.0, lot=lot)
    # farkli fiyat seviyesi henuz yeterli veri biriktirmedi
    assert detector.on_execution(price=60.0, lot=1000) is False
