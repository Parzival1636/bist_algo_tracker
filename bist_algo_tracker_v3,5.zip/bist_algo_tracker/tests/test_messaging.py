import asyncio

from messaging.factory import get_message_bus
from messaging.in_memory_bus import InMemoryMessageBus


def test_factory_returns_in_memory_by_default():
    bus = get_message_bus("memory")
    assert isinstance(bus, InMemoryMessageBus)

def test_in_memory_bus_pub_sub_roundtrip():
    async def run():
        bus = InMemoryMessageBus()
        received = []

        async def subscriber():
            async for msg in bus.subscribe("bist.alerts.THYAO"):
                received.append(msg)
                if len(received) >= 2:
                    break

        task = asyncio.create_task(subscriber())
        await asyncio.sleep(0.05)
        await bus.publish("bist.alerts.THYAO", {"seq": 0})
        await bus.publish("bist.alerts.THYAO", {"seq": 1})
        await asyncio.wait_for(task, timeout=2)
        return received

    received = asyncio.run(run())
    assert len(received) == 2
    assert received[0]["seq"] == 0

def test_in_memory_bus_isolates_subjects():
    async def run():
        bus = InMemoryMessageBus()
        received = []

        async def subscriber():
            async for msg in bus.subscribe("bist.alerts.GARAN"):
                received.append(msg)
                break

        task = asyncio.create_task(subscriber())
        await asyncio.sleep(0.05)
        await bus.publish("bist.alerts.THYAO", {"seq": "yanlis-sembol"})  # farkli subject - alinmamali
        await asyncio.sleep(0.1)
        await bus.publish("bist.alerts.GARAN", {"seq": "dogru-sembol"})
        await asyncio.wait_for(task, timeout=2)
        return received

    received = asyncio.run(run())
    assert len(received) == 1
    assert received[0]["seq"] == "dogru-sembol"
