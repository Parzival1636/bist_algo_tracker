"""
tests/test_api_orders.py
v2: /orders uclarinin FastAPI TestClient uzerinden GERCEK entegrasyon testi
(place -> list -> cancel -> dogrulama). PaperBrokerAdapter kullanir, gercek
para/emir yoktur.
"""
from fastapi.testclient import TestClient

from api.main_fastapi import app


def test_health_reports_v2_fields():
    with TestClient(app) as client:
        r = client.get("/health")
        assert r.status_code == 200
        body = r.json()
        assert body["status"] == "ok"
        assert "message_bus" in body
        assert "db_breaker_state" in body
        assert isinstance(body["starting_balance_try"], (int, float))
        assert body["starting_balance_try"] > 0


def test_orders_all_includes_filled_and_canceled_orders():
    """v3: /orders/all, /orders'in aksine TUM durumdaki emirleri gostermeli."""
    with TestClient(app) as client:
        placed = client.post("/orders", json={"symbol": "GARAN", "side": "ASK", "price": 42.0, "lot": 250}).json()
        order_id = placed["order_id"]

        client.post(f"/orders/{order_id}/cancel")

        # Iptal edilen emir /orders (acik emirler) icinde GORUNMEMELI
        open_orders = client.get("/orders").json()
        assert not any(o["order_id"] == order_id for o in open_orders)

        # ama /orders/all icinde durumu CANCELED olarak GORUNMELI
        all_orders = client.get("/orders/all").json()
        matching = [o for o in all_orders if o["order_id"] == order_id]
        assert len(matching) == 1
        assert matching[0]["status"] == "CANCELED"


def test_place_list_and_cancel_order():
    with TestClient(app) as client:
        r = client.post("/orders", json={"symbol": "THYAO", "side": "BID", "price": 100.0, "lot": 500})
        assert r.status_code == 200
        order = r.json()
        assert order["status"] == "NEW"
        order_id = order["order_id"]

        r = client.get("/orders")
        assert any(o["order_id"] == order_id for o in r.json())

        r = client.post(f"/orders/{order_id}/cancel")
        assert r.status_code == 200
        assert r.json()["canceled"] is True

        r = client.get("/orders")
        assert not any(o["order_id"] == order_id for o in r.json())


def test_cancel_unknown_order_returns_false():
    with TestClient(app) as client:
        r = client.post("/orders/does-not-exist/cancel")
        assert r.status_code == 200
        assert r.json()["canceled"] is False
