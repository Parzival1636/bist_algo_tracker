"""
backtest/historical_player.py
Modul 7: HistoricalDataPlayer
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Dict, Iterable, List, Union

from core.ingestion.websocket_client import SimulatedMarketDataSource


class HistoricalDataPlayer:
    def __init__(self, messages: List[Dict]) -> None:
        self._messages = messages

    @classmethod
    def load_from_json(cls, path: Union[str, Path]) -> "HistoricalDataPlayer":
        data = json.loads(Path(path).read_text(encoding="utf-8"))
        return cls(messages=data)

    @classmethod
    async def generate_synthetic(cls, symbols: List[str], tick_count: int, seed: int = 42) -> "HistoricalDataPlayer":
        source = SimulatedMarketDataSource(symbols=symbols, seed=seed, realtime=False)
        messages: List[Dict] = []
        async for message in source.stream():
            messages.append(message)
            if len(messages) >= tick_count:
                break
        return cls(messages=messages)

    def replay(self) -> Iterable[Dict]:
        yield from self._messages

    def __len__(self) -> int:
        return len(self._messages)
