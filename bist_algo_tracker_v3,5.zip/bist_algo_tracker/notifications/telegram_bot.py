"""notifications/telegram_bot.py - Modul 8: Telegram Bot API bildirimi."""
from __future__ import annotations

import httpx

from config.logging_config import get_logger

logger = get_logger(__name__)
TELEGRAM_API_BASE = "https://api.telegram.org"


async def send_telegram_alert(bot_token: str, chat_id: str, text: str) -> bool:
    url = f"{TELEGRAM_API_BASE}/bot{bot_token}/sendMessage"
    try:
        async with httpx.AsyncClient(timeout=10.0) as client:
            response = await client.post(url, json={"chat_id": chat_id, "text": text})
            response.raise_for_status()
            return True
    except httpx.HTTPError as exc:
        logger.warning("Telegram bildirimi gonderilemedi: %s", exc)
        return False


def format_alert_message(alert) -> str:
    return f"[{alert.severity.value}] {alert.message}"
