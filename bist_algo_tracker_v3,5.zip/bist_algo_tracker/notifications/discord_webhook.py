"""notifications/discord_webhook.py - Modul 8: Discord Webhook bildirimi."""
from __future__ import annotations

import httpx

from config.logging_config import get_logger

logger = get_logger(__name__)


async def send_discord_alert(webhook_url: str, text: str) -> bool:
    try:
        async with httpx.AsyncClient(timeout=10.0) as client:
            response = await client.post(webhook_url, json={"content": text})
            response.raise_for_status()
            return True
    except httpx.HTTPError as exc:
        logger.warning("Discord bildirimi gonderilemedi: %s", exc)
        return False
