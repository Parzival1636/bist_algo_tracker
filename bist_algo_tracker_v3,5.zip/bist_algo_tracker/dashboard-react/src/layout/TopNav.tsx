import { useEffect, useState } from 'react'
import { NavLink } from 'react-router-dom'
import { useAppStore } from '../state/useAppStore'
import { useGlobalStore } from '../state/useGlobalStore'
import type { HealthResponse } from '../types'

interface TopNavProps {
  health: HealthResponse | null
}

const TABS = [
  { to: '/dashboard', label: 'Ana Panel' },
  { to: '/automation', label: 'Otomasyon' },
  { to: '/profile', label: 'Profil' },
  { to: '/settings', label: 'Ayarlar' },
]

function useClock() {
  const [now, setNow] = useState(() => new Date())
  useEffect(() => {
    const id = setInterval(() => setNow(new Date()), 1000)
    return () => clearInterval(id)
  }, [])
  return now
}

/**
 * v3: Kurumsal üst navigasyon (bkz. referans görsel — Aether RE).
 * React Router `NavLink` ile aktif sekmede turuncu alt-çizgi otomatik
 * uygulanır (isActive render-prop'u).
 */
export function TopNav({ health }: TopNavProps) {
  const now = useClock()
  const soundEnabled = useAppStore((s) => s.soundEnabled)
  const toggleSound = useAppStore((s) => s.toggleSound)
  const displayName = useGlobalStore((s) => s.displayName)

  const modeLabel = health ? (health.demo_mode ? 'DEMO CANLI AKIŞ' : 'CANLI AKIŞ') : 'BAĞLANIYOR'
  const timeLabel = now.toLocaleTimeString('tr-TR', { hour12: false })

  return (
    <header className="flex shrink-0 items-center justify-between gap-4 border-b border-[var(--color-border)] bg-[var(--color-panel)] px-5 py-3">
      <div className="flex items-center gap-8">
        <div className="flex items-center gap-2.5">
          <span className="glow-accent flex h-7 w-7 rotate-45 items-center justify-center rounded-[6px] border-2 border-[var(--color-accent)]">
            <span className="-rotate-45 font-mono text-[10px] font-bold text-[var(--color-accent)]">B</span>
          </span>
          <div className="leading-tight">
            <div className="font-mono text-sm font-bold tracking-tight text-[var(--color-text)]">BIST-ALGOTRACKER</div>
            <div className="font-mono text-[9px] tracking-[0.18em] text-[var(--color-muted)] uppercase">
              Trading Executive Dashboard
            </div>
          </div>
        </div>

        <nav className="flex items-center gap-1">
          {TABS.map((tab) => (
            <NavLink
              key={tab.to}
              to={tab.to}
              className={({ isActive }) =>
                `border-b-2 px-3 py-2 font-mono text-[13px] font-medium transition-colors ${
                  isActive
                    ? 'border-[var(--color-accent)] text-[var(--color-accent)]'
                    : 'border-transparent text-[var(--color-muted)] hover:text-[var(--color-text)]'
                }`
              }
            >
              {tab.label}
            </NavLink>
          ))}
        </nav>
      </div>

      <div className="flex items-center gap-4">
        <button
          onClick={toggleSound}
          title="Alarm sesini aç/kapat"
          className="font-mono text-[11px] text-[var(--color-muted)] hover:text-[var(--color-text)]"
        >
          {soundEnabled ? '🔊' : '🔇'}
        </button>
        <span className="hidden font-mono text-[11px] text-[var(--color-muted)] sm:inline">{displayName}</span>
        <div className="flex items-center gap-2 rounded-full border border-[var(--color-border)] bg-[var(--color-panel-alt)] px-3 py-1.5">
          <span className="pulse-dot inline-block h-2 w-2 rounded-full bg-[var(--color-buy)] text-[var(--color-buy)]" />
          <span className="font-mono text-[11px] font-semibold text-[var(--color-buy)]">{modeLabel}</span>
          <span className="text-[var(--color-border)]">|</span>
          <span className="tabular-nums font-mono text-[11px] text-[var(--color-muted)]">{timeLabel}</span>
        </div>
      </div>
    </header>
  )
}
