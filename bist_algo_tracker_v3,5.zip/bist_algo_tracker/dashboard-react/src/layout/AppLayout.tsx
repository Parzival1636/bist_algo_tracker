import { useCallback, useEffect } from 'react'
import { Outlet } from 'react-router-dom'
import { cancelOrder, fetchHealth, fetchOrders, placeOrder, wsUrl } from '../api/client'
import { AkdSubscriber, OrderbookSubscriber } from '../components/OrderbookSubscriber'
import { PortfolioSync } from '../components/PortfolioSync'
import { useTraderHotkeys } from '../hooks/useTraderHotkeys'
import { useWebSocketStream } from '../hooks/useWebSocketStream'
import { bestAsk, bestBid } from '../lib/priceLadder'
import { useAppStore } from '../state/useAppStore'
import { useGlobalStore } from '../state/useGlobalStore'
import { usePortfolioStore } from '../state/usePortfolioStore'
import type { Alert } from '../types'
import { KpiHeader } from './KpiHeader'
import { TopNav } from './TopNav'

/**
 * v3: Kalıcı uygulama kabuğu. React Router'ın layout-route deseniyle
 * (bkz. router.tsx) TÜM sekmelerde SABİT kalır: üst nav, KPI şeridi,
 * global WebSocket abonelikleri (alarm + her sembol için orderbook/AKD),
 * portföy senkronizasyonu ve trader kısayolları BURADA yaşar - sekmeler
 * arası geçişte YENİDEN BAĞLANMA/veri kaybı olmaz.
 */
export function AppLayout() {
  const health = useAppStore((s) => s.health)
  const setHealth = useAppStore((s) => s.setHealth)
  const selectedSymbol = useAppStore((s) => s.selectedSymbol)
  const orderbooks = useAppStore((s) => s.orderbooks)
  const addAlert = useAppStore((s) => s.addAlert)
  const orders = useAppStore((s) => s.orders)
  const setOrders = useAppStore((s) => s.setOrders)
  const alertsConnection = useAppStore((s) => s.alertsConnection)
  const setAlertsConnection = useAppStore((s) => s.setAlertsConnection)
  const setStartingBalance = usePortfolioStore((s) => s.setStartingBalance)
  const theme = useGlobalStore((s) => s.theme)

  const symbols = health?.symbols ?? []
  const book = selectedSymbol ? orderbooks[selectedSymbol] : null

  // --- v3: Ayarlar'dan seçilen tema, tüm uygulamaya `.light` sınıfı ile
  // uygulanır (bkz. index.css - CSS değişken devralımı sayesinde tekil
  // bir yerden tüm bileşenleri kapsar). ---
  useEffect(() => {
    document.documentElement.classList.toggle('light', theme === 'light')
  }, [theme])

  // --- İlk yükleme + periyodik sağlık kontrolü (başlangıç bakiyesi de buradan gelir) ---
  useEffect(() => {
    const sync = () =>
      fetchHealth()
        .then((h) => {
          setHealth(h)
          setStartingBalance(h.starting_balance_try)
        })
        .catch(() => {})
    sync()
    const id = setInterval(sync, 5000)
    return () => clearInterval(id)
  }, [setHealth, setStartingBalance])

  // --- Açık emirler (emir formu/kısayollar için) ---
  const refreshOrders = useCallback(() => {
    fetchOrders().then(setOrders).catch(() => {})
  }, [setOrders])

  useEffect(() => {
    refreshOrders()
    const id = setInterval(refreshOrders, 3000)
    return () => clearInterval(id)
  }, [refreshOrders])

  // --- Alarmlar: TEK global WebSocket, throttle edilmiş batch olarak gelir ---
  const handleAlertBatch = useCallback((batch: Alert[]) => batch.forEach(addAlert), [addAlert])
  useWebSocketStream<Alert>(wsUrl('/ws/alerts'), handleAlertBatch, setAlertsConnection)

  // --- Trader hotkey'leri: HANGİ SEKMEDE OLURSA OLSUN çalışır ---
  useTraderHotkeys({
    onMarketBuy: () => {
      if (!selectedSymbol || !book) return
      const ask = bestAsk(book)
      if (ask) placeOrder(selectedSymbol, 'BID', ask.price, 100).then(refreshOrders).catch(() => {})
    },
    onMarketSell: () => {
      if (!selectedSymbol || !book) return
      const bid = bestBid(book)
      if (bid) placeOrder(selectedSymbol, 'ASK', bid.price, 100).then(refreshOrders).catch(() => {})
    },
    onCancelAll: () => {
      if (!selectedSymbol) return
      const toCancel = orders.filter((o) => o.symbol === selectedSymbol)
      Promise.all(toCancel.map((o) => cancelOrder(o.order_id))).then(refreshOrders).catch(() => {})
    },
  })

  return (
    <div className="flex h-screen flex-col">
      <TopNav health={health} />
      <KpiHeader alertsConnection={alertsConnection} />

      {symbols.map((s) => (
        <OrderbookSubscriber key={`ob-${s}`} symbol={s} />
      ))}
      {symbols.map((s) => (
        <AkdSubscriber key={`akd-${s}`} symbol={s} />
      ))}
      <PortfolioSync />

      <div className="min-h-0 flex-1 overflow-auto p-2">
        <Outlet />
      </div>
    </div>
  )
}
