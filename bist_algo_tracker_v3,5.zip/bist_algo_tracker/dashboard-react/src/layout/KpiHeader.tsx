import { formatCurrency } from '../lib/format'
import { usePortfolioMetrics } from '../hooks/usePortfolioMetrics'
import { useMessagesPerSecond } from '../hooks/useMessagesPerSecond'
import type { ConnectionStatus } from '../state/useAppStore'

interface KpiHeaderProps {
  alertsConnection: ConnectionStatus
}

interface KpiCardProps {
  label: string
  value: string
  glowClass: string
  valueColorVar: string
  sublabel: React.ReactNode
}

function KpiCard({ label, value, glowClass, valueColorVar, sublabel }: KpiCardProps) {
  return (
    <div
      className={`flex min-w-[190px] flex-1 flex-col gap-1 rounded-lg border border-[var(--color-border)] bg-[var(--color-panel)] px-5 py-4 ${glowClass}`}
    >
      <span className="font-mono text-[10px] font-semibold tracking-[0.12em] text-[var(--color-muted)] uppercase">
        {label}
      </span>
      <span className="tabular-nums font-mono text-3xl font-bold" style={{ color: valueColorVar }}>
        {value}
      </span>
      <span className="font-mono text-[11px] text-[var(--color-muted)]">{sublabel}</span>
    </div>
  )
}

/**
 * v3: "Devasa, dikkat çekici" KPI şeridi - her sekmede SABİT (bkz.
 * layout/AppLayout.tsx, burada <Outlet/> DIŞINDA render edilir).
 * Toplam Kasa + Aktif PnL, gerçek dolmuş emirlerden (lib/pnl.ts) canlı
 * hesaplanır; Ağ Sağlığı, gerçek WebSocket varış hızını gösterir
 * (throttle'dan bağımsız - bkz. hooks/useMessagesPerSecond.ts).
 */
export function KpiHeader({ alertsConnection }: KpiHeaderProps) {
  const { cashBalance, unrealizedPnl, totalEquity, openPositionCount } = usePortfolioMetrics()
  const messagesPerSecond = useMessagesPerSecond()

  const pnlPositive = unrealizedPnl >= 0
  const pnlColorVar = pnlPositive ? 'var(--color-buy)' : 'var(--color-sell)'
  const pnlGlow = pnlPositive ? 'glow-buy' : 'glow-sell'

  const netColorVar = 'var(--color-info)'
  const statusColor =
    alertsConnection === 'connected' ? 'var(--color-buy)' : alertsConnection === 'connecting' ? 'var(--color-warning)' : 'var(--color-sell)'

  return (
    <div className="flex flex-wrap gap-3 border-b border-[var(--color-border)] bg-[var(--color-panel-alt)] px-4 py-3">
      <KpiCard
        label="Toplam Kasa"
        value={formatCurrency(cashBalance)}
        glowClass="glow-accent"
        valueColorVar="var(--color-accent)"
        sublabel={`${openPositionCount} açık pozisyon`}
      />
      <KpiCard
        label="Aktif PnL"
        value={`${pnlPositive ? '+' : ''}${formatCurrency(unrealizedPnl)}`}
        glowClass={pnlGlow}
        valueColorVar={pnlColorVar}
        sublabel={pnlPositive ? '▲ Kârda' : '▼ Zararda'}
      />
      <KpiCard
        label="Toplam Özkaynak"
        value={formatCurrency(totalEquity)}
        glowClass=""
        valueColorVar={netColorVar}
        sublabel="Kasa + Anlık PnL"
      />
      <KpiCard
        label="Ağ Sağlığı"
        value={`${messagesPerSecond} Msg/Sn`}
        glowClass=""
        valueColorVar="var(--color-text)"
        sublabel={
          <span className="flex items-center gap-1.5">
            <span
              className="pulse-dot inline-block h-1.5 w-1.5 rounded-full"
              style={{ background: statusColor, color: statusColor }}
            />
            {alertsConnection === 'connected' ? 'WebSocket Bağlı' : alertsConnection === 'connecting' ? 'Bağlanıyor…' : 'Bağlantı Kesildi'}
          </span>
        }
      />
    </div>
  )
}
