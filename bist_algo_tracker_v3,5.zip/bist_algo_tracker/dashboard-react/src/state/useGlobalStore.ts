/**
 * state/useGlobalStore.ts
 * v3 — Profil ve Ayarlar Yönetimi (Zustand + LocalStorage Kalkanı).
 *
 * GÜVENLİK NOTU (senior mimar notu): Bu store, `persist` middleware ile
 * API anahtarlarını YALNIZCA bu tarayıcının localStorage'ında saklar.
 * Bu anahtarlar KOD İÇİNDE HARDCODE EDİLMEZ ve bu uygulama tarafından
 * hiçbir ağ isteğine EKLENMEZ/GÖNDERİLMEZ (şu an hiçbir gerçek aracı
 * kurum entegrasyonu yok - bkz. backend README). localStorage, aynı
 * origin'de çalışan HERHANGİ BİR JavaScript tarafından okunabilir
 * (XSS riski); bu yüzden:
 *   - Gerçek/production kullanımda hassas anahtarların sunucu
 *     tarafında (.env, backend) tutulması güçlü şekilde önerilir -
 *     bu proje zaten o mimariyi destekliyor (bkz. config/settings.py).
 *   - Bu store, kişisel/tek-kullanıcılı demo senaryosu için uygundur.
 */
import { create } from 'zustand'
import { persist } from 'zustand/middleware'

export type ThemeMode = 'dark' | 'light'

export interface ApiCredentials {
  dataProviderApiKey: string
  brokerApiKey: string
  brokerSecretKey: string
}

const EMPTY_CREDENTIALS: ApiCredentials = {
  dataProviderApiKey: '',
  brokerApiKey: '',
  brokerSecretKey: '',
}

interface GlobalState {
  credentials: ApiCredentials
  theme: ThemeMode
  displayName: string
  setCredentials: (partial: Partial<ApiCredentials>) => void
  clearCredentials: () => void
  setTheme: (theme: ThemeMode) => void
  setDisplayName: (name: string) => void
}

export const useGlobalStore = create<GlobalState>()(
  persist(
    (set) => ({
      credentials: EMPTY_CREDENTIALS,
      theme: 'dark',
      displayName: 'Trader',

      setCredentials: (partial) =>
        set((state) => ({ credentials: { ...state.credentials, ...partial } })),

      clearCredentials: () => set({ credentials: EMPTY_CREDENTIALS }),

      setTheme: (theme) => set({ theme }),

      setDisplayName: (name) => set({ displayName: name }),
    }),
    { name: 'bist-algo-tracker-global-store' },
  ),
)
