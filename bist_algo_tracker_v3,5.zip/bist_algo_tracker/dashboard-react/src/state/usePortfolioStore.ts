/**
 * state/usePortfolioStore.ts
 * v3: KPI header'daki "Toplam Kasa" / "Aktif PnL" için ham veriyi tutar.
 * Türetilmiş (hesaplanmış) değerler BURADA DEĞİL, `usePortfolioMetrics`
 * hook'unda (lib/pnl.ts + useAppStore'daki canlı orta fiyatlarla
 * birleştirilerek) hesaplanır - tek sorumluluk ilkesi.
 */
import { create } from 'zustand'
import type { Order } from '../types'

interface PortfolioState {
  startingBalance: number
  allOrders: Order[]
  setStartingBalance: (value: number) => void
  setAllOrders: (orders: Order[]) => void
}

export const usePortfolioStore = create<PortfolioState>((set) => ({
  startingBalance: 0,
  allOrders: [],
  setStartingBalance: (value) => set({ startingBalance: value }),
  setAllOrders: (orders) => set({ allOrders: orders }),
}))
