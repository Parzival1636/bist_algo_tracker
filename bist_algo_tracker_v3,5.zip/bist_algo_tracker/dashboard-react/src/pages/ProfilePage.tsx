import { useState } from 'react'
import { formatCurrency } from '../lib/format'
import { usePortfolioMetrics } from '../hooks/usePortfolioMetrics'
import { useAppStore } from '../state/useAppStore'
import { useGlobalStore } from '../state/useGlobalStore'

function StatRow({ label, value, valueColorVar }: { label: string; value: string; valueColorVar?: string }) {
  return (
    <div className="flex items-center justify-between border-b border-[var(--color-border)] py-2 last:border-b-0">
      <span className="font-mono text-[12px] text-[var(--color-muted)]">{label}</span>
      <span className="tabular-nums font-mono text-[13px] font-semibold" style={{ color: valueColorVar ?? 'var(--color-text)' }}>
        {value}
      </span>
    </div>
  )
}

/** v3: Trader kimliği ve hesap özeti — düzenlenebilir görünen ad Zustand+persist ile kalıcıdır. */
export function ProfilePage() {
  const displayName = useGlobalStore((s) => s.displayName)
  const setDisplayName = useGlobalStore((s) => s.setDisplayName)
  const credentials = useGlobalStore((s) => s.credentials)
  const health = useAppStore((s) => s.health)
  const { cashBalance, unrealizedPnl, totalEquity, openPositionCount } = usePortfolioMetrics()

  const [nameDraft, setNameDraft] = useState(displayName)

  const connectedCount = [credentials.dataProviderApiKey, credentials.brokerApiKey, credentials.brokerSecretKey].filter(
    Boolean,
  ).length

  return (
    <div className="mx-auto flex max-w-3xl flex-col gap-6 p-4">
      <div className="flex items-center gap-4 rounded-lg border border-[var(--color-border)] bg-[var(--color-panel)] p-5">
        <div className="glow-accent flex h-16 w-16 shrink-0 items-center justify-center rounded-full border-2 border-[var(--color-accent)] bg-[var(--color-panel-alt)] font-mono text-xl font-bold text-[var(--color-accent)]">
          {displayName.slice(0, 2).toUpperCase()}
        </div>
        <div className="flex-1">
          <div className="flex items-center gap-2">
            <input
              value={nameDraft}
              onChange={(e) => setNameDraft(e.target.value)}
              onBlur={() => setDisplayName(nameDraft.trim() || 'Trader')}
              className="rounded border border-transparent bg-transparent font-mono text-lg font-bold text-[var(--color-text)] hover:border-[var(--color-border)] focus:border-[var(--color-accent)] focus:outline-none"
            />
          </div>
          <span className="rounded-full bg-[var(--color-accent)]/15 px-2 py-0.5 font-mono text-[10px] font-semibold text-[var(--color-accent)]">
            {health?.demo_mode ? 'DEMO HESAP' : 'CANLI HESAP'}
          </span>
        </div>
      </div>

      <div className="rounded-lg border border-[var(--color-border)] bg-[var(--color-panel)] p-5">
        <h2 className="mb-2 font-mono text-[11px] font-semibold tracking-wider text-[var(--color-muted)] uppercase">
          Hesap Özeti
        </h2>
        <StatRow label="Nakit Bakiye" value={formatCurrency(cashBalance)} valueColorVar="var(--color-accent)" />
        <StatRow
          label="Anlık PnL"
          value={`${unrealizedPnl >= 0 ? '+' : ''}${formatCurrency(unrealizedPnl)}`}
          valueColorVar={unrealizedPnl >= 0 ? 'var(--color-buy)' : 'var(--color-sell)'}
        />
        <StatRow label="Toplam Özkaynak" value={formatCurrency(totalEquity)} />
        <StatRow label="Açık Pozisyon Sayısı" value={String(openPositionCount)} />
      </div>

      <div className="rounded-lg border border-[var(--color-border)] bg-[var(--color-panel)] p-5">
        <h2 className="mb-2 font-mono text-[11px] font-semibold tracking-wider text-[var(--color-muted)] uppercase">
          Bağlantı Durumu
        </h2>
        <StatRow label="Tanımlı API Anahtarı" value={`${connectedCount} / 3`} />
        <StatRow label="Mesajlaşma Katmanı" value={health?.message_bus ?? '—'} />
        <StatRow label="İzlenen Sembol Sayısı" value={String(health?.symbols.length ?? 0)} />
        <p className="mt-3 font-mono text-[10px] text-[var(--color-muted)]">
          API anahtarlarınızı Ayarlar sekmesinden yönetebilirsiniz.
        </p>
      </div>
    </div>
  )
}
