import { useMemo } from 'react'
import { useAppStore } from '../state/useAppStore'
import type { Alert, AlertType } from '../types'

interface BotDefinition {
  alertType: AlertType
  name: string
  description: string
  module: 'v1' | 'v2'
}

const BOTS: BotDefinition[] = [
  {
    alertType: 'SAHTE_LİKİDİTE',
    name: 'Sahte Likidite Sentinel',
    description: 'Yüksek Emir/İşlem Oranı (OTR) + ihmal edilebilir gerçekleşmeyi izler.',
    module: 'v1',
  },
  {
    alertType: 'SPOOFING_UYARISI',
    name: 'Yemleme (OBI) Sentinel',
    description: 'Sürdürülen emir defteri dengesizliğini fiyat hareketiyle karşılaştırır.',
    module: 'v1',
  },
  {
    alertType: 'SPOOFING_ALARM',
    name: 'Hızlı İptal Alarmı',
    description: 'Büyük emirlerin <0.5sn içinde tekrar tekrar iptal edilmesini yakalar.',
    module: 'v1',
  },
  {
    alertType: 'KURUMSAL_YOGUNLASMA',
    name: 'Kurumsal Yoğunlaşma İzleyici',
    description: 'AKD verisinde tek kuruma odaklanan alım baskısını (HHI) tespit eder.',
    module: 'v1',
  },
  {
    alertType: 'LAYERING_ALARM',
    name: 'Katmanlama (Layering) Sentinel',
    description: 'Komşu kademelerde eşzamanlı büyük emir iptallerini korele eder.',
    module: 'v2',
  },
  {
    alertType: 'ICEBERG_TESPIT',
    name: 'Iceberg Tespit Botu',
    description: 'Aynı kademede tekrarlayan, düşük varyanslı gerçekleşmeleri yakalar.',
    module: 'v2',
  },
  {
    alertType: 'CAPRAZ_SEMBOL_KORELASYON',
    name: 'Çapraz-Sembol Korelasyon Botu',
    description: 'Bir kurumun kısa sürede birden fazla sembolde net alıcı olmasını izler.',
    module: 'v2',
  },
]

function countByType(alerts: Alert[], type: AlertType): number {
  return alerts.filter((a) => a.type === type).length
}

function lastTriggeredLabel(alerts: Alert[], type: AlertType): string {
  const matches = alerts.filter((a) => a.type === type)
  if (matches.length === 0) return 'Bu oturumda henüz tetiklenmedi'
  const last = matches[matches.length - 1]
  return `Son: ${new Date(last.timestamp).toLocaleTimeString('tr-TR', { hour12: false })}`
}

function ToggleSwitch({ active, onClick }: { active: boolean; onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      role="switch"
      aria-checked={active}
      className={`relative h-5 w-9 shrink-0 rounded-full transition-colors ${active ? 'bg-[var(--color-buy)]' : 'bg-[var(--color-border)]'}`}
    >
      <span
        className={`absolute top-0.5 h-4 w-4 rounded-full bg-white transition-transform ${active ? 'translate-x-4' : 'translate-x-0.5'}`}
      />
    </button>
  )
}

/**
 * v3: "Otomasyon (Botlar)" sekmesi. Burada listelenen her kart, GERÇEK
 * ve backend'de çalışan bir algoritmik tespit motorunu temsil eder
 * (core/analytics/*.py) — sayılar bu oturumda GERÇEKTEN üretilmiş
 * alarmlardan hesaplanır, dekoratif değildir.
 *
 * DÜRÜSTLÜK NOTU: Anahtar (toggle) yalnızca bu botun uyarılarını Alarm
 * Akışı'nda GÖSTERİP GİZLEMEYİ kontrol eder (arayüz filtresi) — sunucu
 * tarafındaki tespit motorunu durdurmaz. Gerçek sunucu-taraflı
 * aç/kapa için backend'e bir `/bots/{name}/toggle` ucu eklemek gerekir.
 */
export function AutomationPage() {
  const alerts = useAppStore((s) => s.alerts)
  const health = useAppStore((s) => s.health)
  const mutedAlertTypes = useAppStore((s) => s.mutedAlertTypes)
  const toggleMutedAlertType = useAppStore((s) => s.toggleMutedAlertType)

  const totalAlerts = alerts.length
  const activeBotCount = useMemo(() => BOTS.filter((b) => !mutedAlertTypes.has(b.alertType)).length, [mutedAlertTypes])

  return (
    <div className="mx-auto flex max-w-6xl flex-col gap-6 p-4">
      <div>
        <h1 className="font-mono text-lg font-bold text-[var(--color-text)]">Otomasyon — Algoritmik Tespit Botları</h1>
        <p className="mt-1 font-mono text-[12px] text-[var(--color-muted)]">
          {activeBotCount}/{BOTS.length} bot arayüzde aktif · Bu oturumda toplam {totalAlerts} uyarı üretildi
        </p>
      </div>

      <div className="grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-3">
        {BOTS.map((bot) => {
          const count = countByType(alerts, bot.alertType)
          const isMuted = mutedAlertTypes.has(bot.alertType)
          const accentClass = bot.module === 'v2' ? 'border-l-[var(--color-moderate)]' : 'border-l-[var(--color-accent)]'
          return (
            <div
              key={bot.alertType}
              className={`flex flex-col gap-3 rounded-lg border border-[var(--color-border)] border-l-4 bg-[var(--color-panel)] p-4 ${accentClass}`}
            >
              <div className="flex items-start justify-between gap-2">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-sm font-semibold text-[var(--color-text)]">{bot.name}</span>
                    <span className="rounded bg-[var(--color-panel-alt)] px-1.5 py-0.5 font-mono text-[9px] text-[var(--color-muted)]">
                      {bot.module}
                    </span>
                  </div>
                  <p className="mt-1 font-mono text-[11px] leading-snug text-[var(--color-muted)]">{bot.description}</p>
                </div>
                <ToggleSwitch active={!isMuted} onClick={() => toggleMutedAlertType(bot.alertType)} />
              </div>
              <div className="flex items-center justify-between border-t border-[var(--color-border)] pt-2 font-mono text-[11px]">
                <span className={isMuted ? 'text-[var(--color-muted)]' : 'text-[var(--color-buy)]'}>
                  {isMuted ? '● Sessize alındı' : '● Aktif'}
                </span>
                <span className="tabular-nums text-[var(--color-text)]">{count} uyarı</span>
              </div>
              <div className="font-mono text-[10px] text-[var(--color-muted)]">{lastTriggeredLabel(alerts, bot.alertType)}</div>
            </div>
          )
        })}
      </div>

      <div>
        <h2 className="font-mono text-sm font-semibold text-[var(--color-text)]">Sürekli Aktif Altyapı</h2>
        <p className="mt-1 font-mono text-[11px] text-[var(--color-muted)]">
          Alarm üretmez, arka planda sürekli çalışan koruma katmanları — kapatılamaz.
        </p>
        <div className="mt-3 grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-3">
          <div className="rounded-lg border border-[var(--color-border)] border-l-4 border-l-[var(--color-buy)] bg-[var(--color-panel)] p-4">
            <span className="font-mono text-sm font-semibold text-[var(--color-text)]">Risk Guard</span>
            <p className="mt-1 font-mono text-[11px] leading-snug text-[var(--color-muted)]">
              Sabit stop-loss (%2) + izleyen stop + %20 pozisyon limiti. Hiçbir yerde bypass edilemez.
            </p>
            <div className="mt-2 border-t border-[var(--color-border)] pt-2 font-mono text-[11px] text-[var(--color-buy)]">
              ● Her zaman aktif
            </div>
          </div>
          <div className="rounded-lg border border-[var(--color-border)] border-l-4 border-l-[var(--color-info)] bg-[var(--color-panel)] p-4">
            <span className="font-mono text-sm font-semibold text-[var(--color-text)]">Devre Kesici (Circuit Breaker)</span>
            <p className="mt-1 font-mono text-[11px] leading-snug text-[var(--color-muted)]">
              Veritabanı yazımı art arda başarısız olursa devreyi açıp alarm akışını korur.
            </p>
            <div className="mt-2 border-t border-[var(--color-border)] pt-2 font-mono text-[11px] text-[var(--color-text)]">
              Durum:{' '}
              <span className={health?.db_breaker_state === 'closed' ? 'text-[var(--color-buy)]' : 'text-[var(--color-sell)]'}>
                {health?.db_breaker_state ?? 'bilinmiyor'}
              </span>
            </div>
          </div>
          <div className="rounded-lg border border-[var(--color-border)] border-l-4 border-l-[var(--color-warning)] bg-[var(--color-panel)] p-4">
            <span className="font-mono text-sm font-semibold text-[var(--color-text)]">Backpressure Kuyruğu</span>
            <p className="mt-1 font-mono text-[11px] leading-snug text-[var(--color-muted)]">
              Veri işleme hızından daha hızlı akarsa en eski mesajı atıp sistemi ayakta tutar.
            </p>
            <div className="mt-2 border-t border-[var(--color-border)] pt-2 font-mono text-[11px] text-[var(--color-text)]">
              Atılan mesaj: <span className="tabular-nums">{health?.dropped_messages ?? 0}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
