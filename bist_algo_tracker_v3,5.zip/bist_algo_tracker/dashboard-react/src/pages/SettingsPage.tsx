import { useState } from 'react'
import { type ApiCredentials, type ThemeMode, useGlobalStore } from '../state/useGlobalStore'

function MaskedField({
  label,
  value,
  onChange,
  placeholder,
}: {
  label: string
  value: string
  onChange: (v: string) => void
  placeholder: string
}) {
  const [visible, setVisible] = useState(false)
  return (
    <label className="flex flex-col gap-1.5">
      <span className="font-mono text-[11px] font-medium text-[var(--color-muted)]">{label}</span>
      <div className="flex items-center gap-2">
        <input
          type={visible ? 'text' : 'password'}
          value={value}
          onChange={(e) => onChange(e.target.value)}
          placeholder={placeholder}
          autoComplete="off"
          className="flex-1 rounded border border-[var(--color-border)] bg-[var(--color-panel-alt)] px-3 py-2 font-mono text-[13px] text-[var(--color-text)] placeholder:text-[var(--color-muted)]/50 focus:border-[var(--color-accent)] focus:outline-none"
        />
        <button
          type="button"
          onClick={() => setVisible((v) => !v)}
          className="rounded border border-[var(--color-border)] px-2 py-2 font-mono text-[11px] text-[var(--color-muted)] hover:text-[var(--color-text)]"
        >
          {visible ? 'Gizle' : 'Göster'}
        </button>
      </div>
    </label>
  )
}

const THEME_OPTIONS: { value: ThemeMode; label: string }[] = [
  { value: 'dark', label: '🌙 Koyu' },
  { value: 'light', label: '☀️ Açık' },
]

/**
 * v3 — Ayarlar sekmesi: API anahtarları + tema seçimi.
 *
 * GÜVENLİK MİMARİSİ: Değerler `useGlobalStore` (Zustand `persist`)
 * üzerinden YALNIZCA localStorage'a yazılır; kod içinde hardcode
 * EDİLMEZ ve bu uygulama tarafından hiçbir ağ isteğine eklenmez.
 * Alanlar varsayılan olarak maskelenir (şifre girişi gibi).
 */
export function SettingsPage() {
  const credentials = useGlobalStore((s) => s.credentials)
  const setCredentials = useGlobalStore((s) => s.setCredentials)
  const clearCredentials = useGlobalStore((s) => s.clearCredentials)
  const theme = useGlobalStore((s) => s.theme)
  const setTheme = useGlobalStore((s) => s.setTheme)

  const [draft, setDraft] = useState<ApiCredentials>(credentials)
  const [savedFlash, setSavedFlash] = useState(false)

  function handleField(key: keyof ApiCredentials, value: string) {
    setDraft((d) => ({ ...d, [key]: value }))
  }

  function handleSave() {
    setCredentials(draft)
    setSavedFlash(true)
    setTimeout(() => setSavedFlash(false), 2000)
  }

  function handleClear() {
    clearCredentials()
    setDraft({ dataProviderApiKey: '', brokerApiKey: '', brokerSecretKey: '' })
  }

  return (
    <div className="mx-auto flex max-w-2xl flex-col gap-6 p-4">
      <h1 className="font-mono text-lg font-bold text-[var(--color-text)]">Ayarlar</h1>

      <div className="rounded-lg border border-[var(--color-warning)]/40 bg-[var(--color-warning)]/10 p-3 font-mono text-[11px] leading-relaxed text-[var(--color-warning)]">
        Bu anahtarlar yalnızca <strong>bu tarayıcının localStorage'ında</strong> saklanır ve bu uygulama
        tarafından hiçbir sunucuya gönderilmez. Gerçek/production kullanımda hassas anahtarların sunucu
        tarafında (backend `.env`) tutulması önerilir — paylaşılan bir bilgisayarda bu sekmeyi kapatmadan
        önce "Anahtarları Temizle" ile silmeniz önerilir.
      </div>

      <div className="flex flex-col gap-4 rounded-lg border border-[var(--color-border)] bg-[var(--color-panel)] p-5">
        <h2 className="font-mono text-[11px] font-semibold tracking-wider text-[var(--color-muted)] uppercase">
          API Kimlik Bilgileri
        </h2>
        <MaskedField
          label="Veri Sağlayıcı API Key"
          value={draft.dataProviderApiKey}
          onChange={(v) => handleField('dataProviderApiKey', v)}
          placeholder="ör. Matriks / İdealData API anahtarı"
        />
        <MaskedField
          label="Aracı Kurum API Key"
          value={draft.brokerApiKey}
          onChange={(v) => handleField('brokerApiKey', v)}
          placeholder="Aracı kurumunuzun API anahtarı"
        />
        <MaskedField
          label="Aracı Kurum Secret Key"
          value={draft.brokerSecretKey}
          onChange={(v) => handleField('brokerSecretKey', v)}
          placeholder="Aracı kurumunuzun gizli anahtarı"
        />
        <div className="flex items-center gap-3 pt-1">
          <button
            onClick={handleSave}
            className="rounded bg-[var(--color-accent)] px-4 py-2 font-mono text-[12px] font-semibold text-black hover:brightness-110"
          >
            {savedFlash ? '✓ Kaydedildi' : 'Kaydet'}
          </button>
          <button
            onClick={handleClear}
            className="rounded border border-[var(--color-sell)]/40 px-4 py-2 font-mono text-[12px] text-[var(--color-sell)] hover:bg-[var(--color-sell)]/10"
          >
            Anahtarları Temizle
          </button>
        </div>
      </div>

      <div className="flex flex-col gap-3 rounded-lg border border-[var(--color-border)] bg-[var(--color-panel)] p-5">
        <h2 className="font-mono text-[11px] font-semibold tracking-wider text-[var(--color-muted)] uppercase">
          Görünüm
        </h2>
        <div className="flex gap-2">
          {THEME_OPTIONS.map((opt) => (
            <button
              key={opt.value}
              onClick={() => setTheme(opt.value)}
              className={`flex-1 rounded border px-4 py-2 font-mono text-[13px] transition-colors ${
                theme === opt.value
                  ? 'border-[var(--color-accent)] bg-[var(--color-accent)]/15 text-[var(--color-accent)]'
                  : 'border-[var(--color-border)] text-[var(--color-muted)] hover:text-[var(--color-text)]'
              }`}
            >
              {opt.label}
            </button>
          ))}
        </div>
      </div>
    </div>
  )
}
