import { useCallback, useMemo, useState } from 'react'
import type { Layout } from 'react-grid-layout/legacy'
import { fetchOrders } from '../api/client'
import { AkdPanel } from '../components/AkdPanel'
import { AlertFeed } from '../components/AlertFeed'
import { ChartPanel } from '../components/ChartPanel'
import { DomLadder } from '../components/DomLadder'
import { OrderTicket } from '../components/OrderTicket'
import { OrdersPanel } from '../components/OrdersPanel'
import { Watchlist } from '../components/Watchlist'
import { WorkspaceGrid, type WorkspacePanel } from '../components/WorkspaceGrid'
import { midPrice } from '../lib/priceLadder'
import { useAppStore } from '../state/useAppStore'
import type { Side } from '../types'

const DEFAULT_LAYOUT: Layout = [
  { i: 'watchlist', x: 0, y: 0, w: 2, h: 18, minW: 2 },
  { i: 'ladder', x: 2, y: 0, w: 3, h: 18, minW: 2 },
  { i: 'ticket', x: 5, y: 0, w: 2, h: 9, minW: 2 },
  { i: 'akd', x: 5, y: 9, w: 2, h: 9, minW: 2 },
  { i: 'chart', x: 7, y: 0, w: 5, h: 9, minW: 3 },
  { i: 'orders', x: 7, y: 9, w: 5, h: 9, minW: 3 },
  { i: 'alerts', x: 0, y: 18, w: 12, h: 10, minW: 3 },
]

/**
 * v3: "Ana Panel" sekmesi. WebSocket abonelikleri artık layout/AppLayout.tsx
 * içinde GLOBAL olarak yaşıyor (sekmeler arası geçişte veri akışı
 * KESİLMEZ) - bu sayfa sadece store'daki veriyi okuyup trader ızgarasını
 * render eder.
 */
export function DashboardPage() {
  const health = useAppStore((s) => s.health)
  const selectedSymbol = useAppStore((s) => s.selectedSymbol)
  const selectSymbol = useAppStore((s) => s.selectSymbol)
  const orderbooks = useAppStore((s) => s.orderbooks)
  const akdMap = useAppStore((s) => s.akd)
  const alerts = useAppStore((s) => s.alerts)
  const orders = useAppStore((s) => s.orders)
  const setOrders = useAppStore((s) => s.setOrders)
  const soundEnabled = useAppStore((s) => s.soundEnabled)

  const [ticketPrice, setTicketPrice] = useState<number | null>(null)
  const [ticketSide, setTicketSide] = useState<Side | null>(null)
  const [layout, setLayout] = useState<Layout>(DEFAULT_LAYOUT)

  const refreshOrders = useCallback(() => {
    fetchOrders().then(setOrders).catch(() => {})
  }, [setOrders])

  const symbols = health?.symbols ?? []
  const book = selectedSymbol ? orderbooks[selectedSymbol] : null
  const akd = selectedSymbol ? (akdMap[selectedSymbol] ?? null) : null

  const symbolAlerts = useMemo(
    () => (selectedSymbol ? alerts.filter((a) => a.symbol === selectedSymbol).slice(-30) : []),
    [alerts, selectedSymbol],
  )

  const alertCounts = useMemo(() => {
    const counts: Record<string, number> = {}
    for (const a of alerts) counts[a.symbol] = (counts[a.symbol] ?? 0) + 1
    return counts
  }, [alerts])

  const latestMid = book ? midPrice(book) : null

  const handleSelectPrice = useCallback((price: number, side: Side) => {
    setTicketPrice(price)
    setTicketSide(side)
  }, [])

  const panels: WorkspacePanel[] = [
    {
      id: 'watchlist',
      title: 'İzleme Listesi',
      content: (
        <Watchlist
          symbols={symbols}
          selectedSymbol={selectedSymbol}
          orderbooks={orderbooks}
          alertCounts={alertCounts}
          onSelect={selectSymbol}
        />
      ),
    },
    {
      id: 'ladder',
      title: `Emir Defteri Derinliği${selectedSymbol ? ' — ' + selectedSymbol : ''}`,
      content: <DomLadder book={book} recentAlerts={symbolAlerts} onSelectPrice={handleSelectPrice} />,
    },
    {
      id: 'ticket',
      title: 'Emir Formu',
      content: (
        <OrderTicket symbol={selectedSymbol} prefillPrice={ticketPrice} prefillSide={ticketSide} onOrderPlaced={refreshOrders} />
      ),
    },
    { id: 'akd', title: 'Aracı Kurum Dağılımı', content: <AkdPanel akd={akd} /> },
    {
      id: 'chart',
      title: `Fiyat Grafiği${selectedSymbol ? ' — ' + selectedSymbol : ''}`,
      content: <ChartPanel symbol={selectedSymbol} latestMidPrice={latestMid} />,
    },
    { id: 'orders', title: 'Açık Emirler', content: <OrdersPanel orders={orders} onChanged={refreshOrders} /> },
    { id: 'alerts', title: 'Anomali Bildirim Akışı', content: <AlertFeed alerts={alerts} soundEnabled={soundEnabled} /> },
  ]

  return <WorkspaceGrid panels={panels} layout={layout} onLayoutChange={setLayout} />
}
