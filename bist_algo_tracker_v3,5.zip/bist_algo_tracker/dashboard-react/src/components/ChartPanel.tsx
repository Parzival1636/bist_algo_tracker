import { useEffect, useRef } from 'react'
import { createChart, LineSeries, type IChartApi, type ISeriesApi, type UTCTimestamp } from 'lightweight-charts'

interface ChartPanelProps {
  symbol: string | null
  latestMidPrice: number | null
}

/**
 * v2: TradingView Lightweight Charts entegrasyonu (v2 spec Bolum 4.8).
 * NOT (durustluk): Backend henuz OHLC bar veri saglamiyor - bu panel
 * gelen tick'lerin ORTA FIYATINI (mid price) canli bir CIZGI (Line
 * Series) olarak cizer. Tam mum (candlestick) grafigi icin backend'de
 * bar agregasyonu (veya client-side zaman-dilimli OHLC biriktirme)
 * eklenmesi gerekir - dogal bir sonraki adim olarak birakildi.
 */
export function ChartPanel({ symbol, latestMidPrice }: ChartPanelProps) {
  const containerRef = useRef<HTMLDivElement>(null)
  const seriesRef = useRef<ISeriesApi<'Line'> | null>(null)

  useEffect(() => {
    if (!containerRef.current) return
    const chart: IChartApi = createChart(containerRef.current, {
      layout: {
        background: { color: 'transparent' },
        textColor: '#8ca0b3',
        fontFamily: 'IBM Plex Mono, monospace',
        fontSize: 11,
      },
      grid: {
        vertLines: { color: '#22303c' },
        horzLines: { color: '#22303c' },
      },
      timeScale: { timeVisible: true, secondsVisible: true },
      rightPriceScale: { borderColor: '#22303c' },
      autoSize: true,
    })
    const series = chart.addSeries(LineSeries, { color: '#d9a441', lineWidth: 2 })
    seriesRef.current = series

    return () => {
      chart.remove()
      seriesRef.current = null
    }
  }, [])

  useEffect(() => {
    seriesRef.current?.setData([])
  }, [symbol])

  useEffect(() => {
    if (latestMidPrice === null || !seriesRef.current) return
    const time = Math.floor(Date.now() / 1000) as UTCTimestamp
    seriesRef.current.update({ time, value: latestMidPrice })
  }, [latestMidPrice])

  if (!symbol) {
    return <div className="p-2 text-xs text-[var(--color-muted)]">Sembol seçin…</div>
  }

  return <div ref={containerRef} className="h-full w-full" />
}
