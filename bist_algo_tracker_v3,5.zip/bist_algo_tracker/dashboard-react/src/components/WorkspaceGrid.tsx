import type { ReactNode } from 'react'
import GridLayout, { WidthProvider, type Layout } from 'react-grid-layout/legacy'
import 'react-grid-layout/css/styles.css'
import { PanelShell } from './PanelShell'

const ResponsiveGridLayout = WidthProvider(GridLayout)

export interface WorkspacePanel {
  id: string
  title: string
  content: ReactNode
}

interface WorkspaceGridProps {
  panels: WorkspacePanel[]
  layout: Layout
  onLayoutChange?: (layout: Layout) => void
}

/**
 * v2 spec Bolum 4.2: sürüklenebilir / yeniden boyutlandırılabilir panel
 * mimarisi (Bloomberg Terminal esintili). Panel düzeni `layout` prop'u
 * ile disaridan yonetilir - kullanici bazli kaydetme (localStorage/
 * backend) App.tsx seviyesinde eklenebilir (bkz. README - bu ortamda
 * backend'e persist edilen bir "workspace" endpoint'i henuz YOK).
 */
export function WorkspaceGrid({ panels, layout, onLayoutChange }: WorkspaceGridProps) {
  return (
    <ResponsiveGridLayout
      className="flex-1"
      layout={layout}
      cols={12}
      rowHeight={28}
      margin={[8, 8]}
      containerPadding={[8, 8]}
      draggableHandle=".panel-drag-handle"
      onLayoutChange={onLayoutChange}
    >
      {panels.map((panel) => (
        <div key={panel.id}>
          <PanelShell title={panel.title}>{panel.content}</PanelShell>
        </div>
      ))}
    </ResponsiveGridLayout>
  )
}
