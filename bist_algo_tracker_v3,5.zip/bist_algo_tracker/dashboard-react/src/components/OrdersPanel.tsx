import { cancelOrder } from '../api/client'
import { formatPrice } from '../lib/format'
import type { Order } from '../types'

interface OrdersPanelProps {
  orders: Order[]
  onChanged: () => void
}

export function OrdersPanel({ orders, onChanged }: OrdersPanelProps) {
  async function handleCancel(orderId: string) {
    await cancelOrder(orderId)
    onChanged()
  }

  if (orders.length === 0) {
    return <div className="p-2 text-xs text-[var(--color-muted)]">Açık emir yok.</div>
  }

  return (
    <table className="w-full font-mono text-[11px]">
      <thead>
        <tr className="text-left text-[var(--color-muted)]">
          <th className="pb-1 font-normal">Sembol</th>
          <th className="pb-1 font-normal">Yön</th>
          <th className="pb-1 font-normal text-right">Fiyat</th>
          <th className="pb-1 font-normal text-right">Lot</th>
          <th className="pb-1 font-normal text-right">Dolan</th>
          <th className="pb-1" />
        </tr>
      </thead>
      <tbody>
        {orders.map((order) => (
          <tr key={order.order_id} className="border-t border-[var(--color-border)]">
            <td className="py-1">{order.symbol}</td>
            <td className={order.side === 'BID' ? 'text-[var(--color-buy)]' : 'text-[var(--color-sell)]'}>
              {order.side === 'BID' ? 'ALIŞ' : 'SATIŞ'}
            </td>
            <td className="text-right">{formatPrice(order.price)}</td>
            <td className="text-right">{order.lot}</td>
            <td className="text-right text-[var(--color-muted)]">{order.filled_lot}</td>
            <td className="text-right">
              <button
                onClick={() => handleCancel(order.order_id)}
                className="rounded px-1.5 py-0.5 text-[var(--color-alarm)] hover:bg-[var(--color-alarm)]/10"
              >
                İptal
              </button>
            </td>
          </tr>
        ))}
      </tbody>
    </table>
  )
}
