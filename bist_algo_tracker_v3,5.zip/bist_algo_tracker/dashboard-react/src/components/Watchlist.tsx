import { formatPrice } from '../lib/format'
import { midPrice } from '../lib/priceLadder'
import type { OrderBookSnapshot } from '../types'

interface WatchlistProps {
  symbols: string[]
  selectedSymbol: string | null
  orderbooks: Record<string, OrderBookSnapshot>
  alertCounts: Record<string, number>
  onSelect: (symbol: string) => void
}

export function Watchlist({ symbols, selectedSymbol, orderbooks, alertCounts, onSelect }: WatchlistProps) {
  return (
    <ul className="flex flex-col gap-1">
      {symbols.map((symbol) => {
        const book = orderbooks[symbol]
        const mid = book ? midPrice(book) : null
        const isSelected = symbol === selectedSymbol
        const count = alertCounts[symbol] ?? 0
        return (
          <li key={symbol}>
            <button
              onClick={() => onSelect(symbol)}
              className={`flex w-full items-center justify-between rounded px-2 py-1.5 font-mono text-xs transition-colors ${
                isSelected ? 'bg-[var(--color-accent)]/15 text-[var(--color-accent)]' : 'text-[var(--color-text)] hover:bg-white/5'
              }`}
            >
              <span className="font-semibold">{symbol}</span>
              <span className="flex items-center gap-2">
                <span className="text-[var(--color-muted)]">{mid !== null ? formatPrice(mid) : '—'}</span>
                {count > 0 && (
                  <span className="rounded-full bg-[var(--color-alarm)]/20 px-1.5 text-[10px] text-[var(--color-alarm)]">
                    {count}
                  </span>
                )}
              </span>
            </button>
          </li>
        )
      })}
    </ul>
  )
}
