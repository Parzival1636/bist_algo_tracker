import { useState } from 'react'
import { placeOrder } from '../api/client'
import { formatPrice } from '../lib/format'
import type { Side } from '../types'

interface OrderTicketProps {
  symbol: string | null
  prefillPrice: number | null
  prefillSide: Side | null
  onOrderPlaced: () => void
}

/**
 * v2: DOM ladder'a tiklandiginda (click-to-trade) acilan emir formu.
 * PaperBrokerAdapter'a POST /orders ile gonderir - GERCEK PARA/EMIR
 * DEGILDIR (bkz. backend core/execution/order_manager.py).
 */
export function OrderTicket({ symbol, prefillPrice, prefillSide, onOrderPlaced }: OrderTicketProps) {
  const [lot, setLot] = useState(100)
  const [submitting, setSubmitting] = useState(false)
  const [lastResult, setLastResult] = useState<string | null>(null)

  const side: Side = prefillSide ?? 'BID'
  const price = prefillPrice

  async function submit() {
    if (!symbol || price === null) return
    setSubmitting(true)
    setLastResult(null)
    try {
      const order = await placeOrder(symbol, side, price, lot)
      setLastResult(`Emir gönderildi: ${order.side} ${order.lot} lot @ ${formatPrice(order.price)}`)
      onOrderPlaced()
    } catch {
      setLastResult('Emir gönderilemedi (API bağlantısını kontrol edin).')
    } finally {
      setSubmitting(false)
    }
  }

  return (
    <div className="flex flex-col gap-2 font-mono text-xs">
      <div className="flex items-center justify-between">
        <span className="text-[var(--color-muted)]">Sembol</span>
        <span className="font-semibold">{symbol ?? '—'}</span>
      </div>
      <div className="flex items-center justify-between">
        <span className="text-[var(--color-muted)]">Yön</span>
        <span className={side === 'BID' ? 'font-semibold text-[var(--color-buy)]' : 'font-semibold text-[var(--color-sell)]'}>
          {side === 'BID' ? 'ALIŞ' : 'SATIŞ'}
        </span>
      </div>
      <div className="flex items-center justify-between">
        <span className="text-[var(--color-muted)]">Fiyat</span>
        <span className="font-semibold">{price !== null ? formatPrice(price) : 'Tahtadan seçin →'}</span>
      </div>
      <label className="flex items-center justify-between">
        <span className="text-[var(--color-muted)]">Lot</span>
        <input
          type="number"
          min={1}
          value={lot}
          onChange={(e) => setLot(Number(e.target.value))}
          className="w-24 rounded border border-[var(--color-border)] bg-[var(--color-panel-alt)] px-2 py-1 text-right text-[var(--color-text)]"
        />
      </label>
      <button
        onClick={submit}
        disabled={!symbol || price === null || submitting}
        className={`mt-1 rounded px-3 py-1.5 font-semibold text-black transition-opacity disabled:opacity-40 ${
          side === 'BID' ? 'bg-[var(--color-buy)]' : 'bg-[var(--color-sell)]'
        }`}
      >
        {submitting ? 'Gönderiliyor…' : side === 'BID' ? 'ALIŞ Gönder' : 'SATIŞ Gönder'}
      </button>
      {lastResult && <div className="text-[10px] text-[var(--color-muted)]">{lastResult}</div>}
      <div className="text-[10px] text-[var(--color-muted)]">F1 Piyasa Alış · F2 Piyasa Satış · Esc Tümünü İptal</div>
    </div>
  )
}
