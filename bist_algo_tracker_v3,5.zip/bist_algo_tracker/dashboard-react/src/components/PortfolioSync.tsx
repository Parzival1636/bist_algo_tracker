import { useEffect } from 'react'
import { fetchAllOrders } from '../api/client'
import { usePortfolioStore } from '../state/usePortfolioStore'

const POLL_INTERVAL_MS = 3000

/**
 * Görünmez senkronizasyon bileşeni: /orders/all'ı periyodik çeker ve
 * usePortfolioStore'u besler. WS akışı yok (emir durum değişiklikleri
 * için ayrı bir kanal açmak bu iterasyonun kapsamı dışında bırakıldı -
 * bkz. README); 3sn'lik REST periyodu, KPI'ların "canlı hissettirmesi"
 * için yeterince sık ve dürüst bir orta yol.
 */
export function PortfolioSync() {
  const setAllOrders = usePortfolioStore((s) => s.setAllOrders)

  useEffect(() => {
    let cancelled = false
    const poll = () => {
      fetchAllOrders()
        .then((orders) => {
          if (!cancelled) setAllOrders(orders)
        })
        .catch(() => {})
    }
    poll()
    const id = setInterval(poll, POLL_INTERVAL_MS)
    return () => {
      cancelled = true
      clearInterval(id)
    }
  }, [setAllOrders])

  return null
}
