import { useWebSocketStream } from '../hooks/useWebSocketStream'
import { useAppStore } from '../state/useAppStore'
import { wsUrl } from '../api/client'
import type { AKDSnapshot, OrderBookSnapshot } from '../types'

/**
 * Gorunmez "abone" bileşenleri: her sembol icin kendi WS baglantisini
 * acar (React hook kurallarina uymak icin dongu yerine .map() ile
 * birden fazla bilesen ornegi kullanilir). Boylece Watchlist TUM
 * sembollerin fiyatini REST POLLING OLMADAN, canli gosterebilir.
 *
 * v3: useWebSocketStream artik THROTTLE EDILMIS bir mesaj DIZISI
 * ("batch") verir - order book/AKD "en son deger kazanir" turde bir
 * akis oldugu icin, biriken batch'teki EN SON elemani almak yeterli
 * ve dogrudur (aradaki gecici durumlar UI icin onemli degildir).
 */
export function OrderbookSubscriber({ symbol }: { symbol: string }) {
  const updateOrderbook = useAppStore((s) => s.updateOrderbook)
  useWebSocketStream<OrderBookSnapshot>(wsUrl(`/ws/orderbook/${symbol}`), (batch) => {
    const latest = batch[batch.length - 1]
    if (latest) updateOrderbook(symbol, latest)
  })
  return null
}

export function AkdSubscriber({ symbol }: { symbol: string }) {
  const updateAkd = useAppStore((s) => s.updateAkd)
  useWebSocketStream<AKDSnapshot>(wsUrl(`/ws/akd/${symbol}`), (batch) => {
    const latest = batch[batch.length - 1]
    if (latest) updateAkd(symbol, latest)
  })
  return null
}
