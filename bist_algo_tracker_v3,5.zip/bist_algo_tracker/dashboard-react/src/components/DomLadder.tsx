import { useMemo } from 'react'
import { buildLadderRows, roundPrice } from '../lib/priceLadder'
import { formatLot, formatPrice } from '../lib/format'
import type { Alert, OrderBookSnapshot } from '../types'

interface DomLadderProps {
  book: OrderBookSnapshot | null
  recentAlerts: Alert[]
  onSelectPrice: (price: number, side: 'BID' | 'ASK') => void
}

const SUSPICIOUS_TYPES = new Set(['SAHTE_LİKİDİTE', 'SPOOFING_UYARISI', 'SPOOFING_ALARM', 'LAYERING_ALARM'])

export function DomLadder({ book, recentAlerts, onSelectPrice }: DomLadderProps) {
  const suspiciousPrices = useMemo(() => {
    const set = new Set<number>()
    for (const alert of recentAlerts) {
      if (!SUSPICIOUS_TYPES.has(alert.type)) continue
      const price = alert.data.price
      if (typeof price === 'number') set.add(roundPrice(price))
    }
    return set
  }, [recentAlerts])

  const rows = useMemo(() => {
    if (!book) return []
    return buildLadderRows(book, { maxLevels: 10, suspiciousPrices })
  }, [book, suspiciousPrices])

  if (!book) {
    return <div className="p-4 text-sm text-[var(--color-muted)]">Derinlik verisi bekleniyor…</div>
  }

  const asks = rows.filter((r) => r.side === 'ASK').sort((a, b) => b.price - a.price)
  const bids = rows.filter((r) => r.side === 'BID').sort((a, b) => b.price - a.price)
  const lastPrice = bids[0] && asks[asks.length - 1] ? (bids[0].price + asks[asks.length - 1].price) / 2 : null

  const Row = ({ side, price, lot, intensity, isSuspicious }: (typeof rows)[number]) => {
    const barColor = side === 'ASK' ? 'var(--color-sell)' : 'var(--color-buy)'
    return (
      <button
        onClick={() => onSelectPrice(price, side)}
        className="relative flex w-full items-center justify-between px-2 py-[3px] font-mono text-xs transition-colors hover:brightness-125"
        style={{
          background: isSuspicious
            ? 'repeating-linear-gradient(45deg, rgba(242,184,75,0.18), rgba(242,184,75,0.18) 4px, transparent 4px, transparent 8px)'
            : undefined,
        }}
        title={isSuspicious ? 'Bu kademe son alarmlarda şüpheli olarak işaretlendi' : undefined}
      >
        <span
          className="absolute inset-y-0 right-0 opacity-25"
          style={{ width: `${Math.round(intensity * 100)}%`, background: barColor }}
          aria-hidden
        />
        <span className={`relative z-10 ${isSuspicious ? 'text-[var(--color-warning)]' : 'text-[var(--color-muted)]'}`}>
          {formatLot(lot)}
        </span>
        <span className="relative z-10 font-semibold" style={{ color: barColor }}>
          {formatPrice(price)}
        </span>
      </button>
    )
  }

  return (
    <div className="flex h-full flex-col font-mono">
      <div className="flex-1 overflow-auto">
        {asks.map((row) => (
          <Row key={`ask-${row.price}`} {...row} />
        ))}
      </div>
      {lastPrice !== null && (
        <div className="my-1 border-y border-[var(--color-border)] bg-[var(--color-panel-alt)] px-2 py-1 text-center text-xs font-semibold text-[var(--color-accent)]">
          {formatPrice(lastPrice)}
        </div>
      )}
      <div className="flex-1 overflow-auto">
        {bids.map((row) => (
          <Row key={`bid-${row.price}`} {...row} />
        ))}
      </div>
    </div>
  )
}
