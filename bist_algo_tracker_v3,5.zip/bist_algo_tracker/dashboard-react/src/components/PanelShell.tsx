import type { ReactNode } from 'react'

interface PanelShellProps {
  title: string
  children: ReactNode
  headerExtra?: ReactNode
  /** react-grid-layout suruklerken tutamac olarak bu class'i arar. */
  dragHandleClassName?: string
}

export function PanelShell({ title, children, headerExtra, dragHandleClassName = 'panel-drag-handle' }: PanelShellProps) {
  return (
    <div className="flex h-full flex-col overflow-hidden rounded-lg border border-[var(--color-border)] bg-[var(--color-panel)]">
      <div
        className={`${dragHandleClassName} flex shrink-0 cursor-move items-center justify-between border-b border-[var(--color-border)] px-3 py-2`}
      >
        <span className="font-mono text-[11px] font-semibold tracking-wider text-[var(--color-muted)] uppercase select-none">
          {title}
        </span>
        {headerExtra}
      </div>
      <div className="min-h-0 flex-1 overflow-auto p-2">{children}</div>
    </div>
  )
}
