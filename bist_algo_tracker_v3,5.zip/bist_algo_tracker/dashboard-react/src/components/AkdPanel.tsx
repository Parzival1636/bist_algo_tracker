import { useMemo } from 'react'
import { buildConicGradient, buildDonutSegments } from '../lib/donut'
import { formatLot } from '../lib/format'
import type { AKDSnapshot } from '../types'

interface AkdPanelProps {
  akd: AKDSnapshot | null
}

const PALETTE = ['#d9a441', '#3fb68b', '#f2b84b', '#e5484d', '#d64ba0', '#5b9bd9']

export function AkdPanel({ akd }: AkdPanelProps) {
  const segments = useMemo(() => buildDonutSegments(akd?.entries ?? [], PALETTE), [akd])
  const gradient = useMemo(() => buildConicGradient(segments), [segments])

  if (!akd || segments.length === 0) {
    return <div className="p-2 text-xs text-[var(--color-muted)]">AKD verisi bekleniyor…</div>
  }

  return (
    <div className="flex h-full items-center gap-4">
      <div
        className="h-28 w-28 shrink-0 rounded-full"
        style={{ background: gradient, boxShadow: 'inset 0 0 0 28px var(--color-panel)' }}
        aria-label="Aracı kurum dağılımı donut grafiği"
      />
      <ul className="flex-1 space-y-1 font-mono text-[11px]">
        {segments.map((seg) => (
          <li key={seg.institution} className="flex items-center justify-between gap-2">
            <span className="flex items-center gap-1.5 truncate">
              <span className="inline-block h-2 w-2 shrink-0 rounded-full" style={{ background: seg.color }} />
              <span className="truncate text-[var(--color-text)]">{seg.institution}</span>
            </span>
            <span className="shrink-0 text-[var(--color-muted)]">
              {formatLot(seg.value)} ({seg.percent.toFixed(0)}%)
            </span>
          </li>
        ))}
      </ul>
    </div>
  )
}
