/**
 * hooks/useWebSocketStream.ts
 * Genel amaçlı, OTOMATİK YENİDEN BAĞLANAN WebSocket hook'u.
 *
 * v3 — Hız Kesici (Throttle) Koruma Duvarı:
 * BİST'ten saniyede yüzlerce Düzey 2 mesajı akabilir. Her mesajda React
 * state güncelleyip DOM'u yeniden render etmek tarayıcıyı kilitler
 * (render-loop / bellek şişmesi riski). Bu yüzden gelen mesajlar
 * `ThrottleBuffer`'da ARKA PLANDA birikir; `onBatch` callback'i sabit
 * bir zamanlayıcıyla (varsayılan 250ms → saniyede EN FAZLA 4 kez)
 * çağrılır ve o ana kadar biriken TÜM mesajları tek seferde iletir.
 * Ham mesaj varış hızı (throttle'dan bağımsız, gerçek Msg/Sec için)
 * `recordMessage()` ile ayrıca telemetri katmanına bildirilir.
 *
 * useEffectEvent kullanır (React 19.2+): callback/onStatusChange'in en
 * güncel halini, Effect'i her render'da yeniden çalıştırmadan okumamızı
 * sağlar (bkz. https://react.dev/reference/react/useEffectEvent).
 */
import { useEffect, useEffectEvent, useRef } from 'react'
import { recordMessage } from '../lib/telemetry'
import { ThrottleBuffer } from '../lib/throttleBuffer'
import type { ConnectionStatus } from '../state/useAppStore'

const RECONNECT_DELAY_MS = 2000
const DEFAULT_THROTTLE_MS = 250 // v3 spec: saniyede en fazla 4 render

export interface UseWebSocketStreamOptions {
  /** Flush aralığı (ms). Varsayılan 250ms = saniyede en fazla 4 render. */
  throttleMs?: number
}

export function useWebSocketStream<T>(
  url: string | null,
  onBatch: (messages: T[]) => void,
  onStatusChange?: (status: ConnectionStatus) => void,
  options?: UseWebSocketStreamOptions,
): void {
  const throttleMs = options?.throttleMs ?? DEFAULT_THROTTLE_MS

  const handleBatch = useEffectEvent((messages: T[]) => {
    onBatch(messages)
  })
  const handleStatusChange = useEffectEvent((status: ConnectionStatus) => {
    onStatusChange?.(status)
  })

  const bufferRef = useRef<ThrottleBuffer<T>>(new ThrottleBuffer<T>())

  useEffect(() => {
    if (!url) return

    let ws: WebSocket | null = null
    let retryTimer: ReturnType<typeof setTimeout> | null = null
    let closedByCleanup = false
    const buffer = bufferRef.current

    function connect() {
      handleStatusChange('connecting')
      ws = new WebSocket(url as string)

      ws.onopen = () => {
        handleStatusChange('connected')
      }
      ws.onmessage = (event: MessageEvent<string>) => {
        try {
          const data = JSON.parse(event.data) as T
          recordMessage() // gercek varis hizi - throttle'dan BAGIMSIZ
          buffer.push(data) // React state'i BURADA guncellenmez
        } catch {
          // Bozuk/ayristirilamayan mesaj - sessizce yoksay, akisi kesme.
        }
      }
      ws.onclose = () => {
        handleStatusChange('disconnected')
        if (!closedByCleanup) {
          retryTimer = setTimeout(connect, RECONNECT_DELAY_MS)
        }
      }
      ws.onerror = () => {
        ws?.close()
      }
    }

    connect()

    const flushInterval = setInterval(() => {
      const batch = buffer.drain()
      if (batch.length > 0) {
        handleBatch(batch)
      }
    }, throttleMs)

    return () => {
      closedByCleanup = true
      if (retryTimer) clearTimeout(retryTimer)
      clearInterval(flushInterval)
      ws?.close()
    }
    // handleBatch/handleStatusChange birer Effect Event'tir - React kurallarina
    // gore bagimlilik dizisine EKLENMEMELIDIR (her zaman en guncel halleri okunur).
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [url, throttleMs])
}
