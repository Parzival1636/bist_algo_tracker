/**
 * hooks/usePortfolioMetrics.ts
 * usePortfolioStore'daki ham emir verisini + useAppStore'daki canlı
 * orta fiyatları birleştirip KPI header için nakit bakiyesi ve anlık
 * kâr/zararı türetir (lib/pnl.ts saf fonksiyonları üzerinden).
 */
import { useMemo } from 'react'
import { computeCashBalance, computeUnrealizedPnl, extractFilledLegs } from '../lib/pnl'
import { midPrice } from '../lib/priceLadder'
import { useAppStore } from '../state/useAppStore'
import { usePortfolioStore } from '../state/usePortfolioStore'

export interface PortfolioMetrics {
  cashBalance: number
  unrealizedPnl: number
  totalEquity: number
  openPositionCount: number
}

export function usePortfolioMetrics(): PortfolioMetrics {
  const startingBalance = usePortfolioStore((s) => s.startingBalance)
  const allOrders = usePortfolioStore((s) => s.allOrders)
  const orderbooks = useAppStore((s) => s.orderbooks)

  return useMemo(() => {
    const legs = extractFilledLegs(allOrders)

    const midPrices: Record<string, number> = {}
    for (const symbol of Object.keys(orderbooks)) {
      const mid = midPrice(orderbooks[symbol])
      if (mid !== null) midPrices[symbol] = mid
    }

    const cashBalance = computeCashBalance(startingBalance, legs)
    const unrealizedPnl = computeUnrealizedPnl(legs, midPrices)

    return {
      cashBalance,
      unrealizedPnl,
      totalEquity: cashBalance + unrealizedPnl,
      openPositionCount: legs.length,
    }
  }, [startingBalance, allOrders, orderbooks])
}
