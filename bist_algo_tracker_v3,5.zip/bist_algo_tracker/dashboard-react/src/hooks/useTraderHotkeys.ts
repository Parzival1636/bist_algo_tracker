/**
 * hooks/useTraderHotkeys.ts
 * Trader-odakli klavye kisayollari (v2 spec Bolum 4.4):
 *   F1  = Piyasa Alis (en iyi ASK'ten, secili sembol)
 *   F2  = Piyasa Satis (en iyi BID'ten, secili sembol)
 *   Esc = Secili sembol icin TUM acik emirleri iptal et
 *
 * useHotkeys varsayilan olarak document'e baglanir (donen ref
 * kullanilmadiginda), boylece kisayollar SAYFA GENELINDE calisir -
 * gercek bir trading terminalinin bekledigi davranis.
 */
import { useHotkeys } from 'react-hotkeys-hook'

export interface TraderHotkeyHandlers {
  onMarketBuy: () => void
  onMarketSell: () => void
  onCancelAll: () => void
}

export function useTraderHotkeys({ onMarketBuy, onMarketSell, onCancelAll }: TraderHotkeyHandlers): void {
  useHotkeys('f1', (e) => { e.preventDefault(); onMarketBuy() }, { enableOnFormTags: false })
  useHotkeys('f2', (e) => { e.preventDefault(); onMarketSell() }, { enableOnFormTags: false })
  useHotkeys('esc', (e) => { e.preventDefault(); onCancelAll() }, { enableOnFormTags: false })
}
