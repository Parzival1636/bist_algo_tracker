/**
 * hooks/useMessagesPerSecond.ts
 * v3: "Ağ Sağlığı / Telemetri" KPI'ı için — telemetry.ts'deki ham
 * sayacı saniyede bir örnekleyip bileşen state'ine yazar. Bu, throttle
 * mekanizmasından TAMAMEN AYRIDIR: burada ölçülen, WebSocket'ten
 * GERÇEKTEN kaç mesaj geldiğidir (render frekansı değil).
 */
import { useEffect, useState } from 'react'
import { drainMessageCount } from '../lib/telemetry'

export function useMessagesPerSecond(sampleIntervalMs = 1000): number {
  const [rate, setRate] = useState(0)

  useEffect(() => {
    const id = setInterval(() => {
      const count = drainMessageCount()
      setRate(Math.round((count * 1000) / sampleIntervalMs))
    }, sampleIntervalMs)
    return () => clearInterval(id)
  }, [sampleIntervalMs])

  return rate
}
