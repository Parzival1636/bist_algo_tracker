/**
 * lib/throttleBuffer.ts
 * v3: "Hız Kesici (Throttle) Koruma Duvarı" - saf, bağımsız test edilebilir
 * mantık. WebSocket'ten gelen mesajlar push() ile arka planda birikir;
 * React state'i GÜNCELLEMEZ. drain() çağrıldığında o ana kadar biriken
 * TÜM mesajları boşaltıp döner. useWebSocketStream bunu sabit aralıklı
 * bir zamanlayıcıyla (varsayılan 250ms) çağırarak React render
 * frekansını WebSocket mesaj frekansından TAMAMEN bağımsızlaştırır -
 * saniyede yüzlerce Düzey 2 mesajı gelse bile DOM en fazla 4 kez/sn
 * güncellenir.
 */
export class ThrottleBuffer<T> {
  private buffer: T[] = []

  push(item: T): void {
    this.buffer.push(item)
  }

  get size(): number {
    return this.buffer.length
  }

  /** Birikmiş tüm öğeleri döner ve arabelleği boşaltır. Boşsa [] döner. */
  drain(): T[] {
    if (this.buffer.length === 0) return []
    const items = this.buffer
    this.buffer = []
    return items
  }
}
