/**
 * lib/soundAlert.ts
 * Alarm sesleri - harici ses dosyasi GEREKTIRMEZ, Web Audio API ile
 * anlik uretilir. CRITICAL (SPOOFING_ALARM/LAYERING) icin cift bip -
 * en kritik alarmin gozden kacmamasi icin kasitli olarak farklilastirildi.
 */
import type { AlertSeverity } from '../types'

function beep(ctx: AudioContext, freq: number, startTime: number, duration: number): void {
  const osc = ctx.createOscillator()
  const gain = ctx.createGain()
  osc.connect(gain)
  gain.connect(ctx.destination)
  osc.frequency.value = freq
  osc.type = 'square'
  gain.gain.setValueAtTime(0.15, startTime)
  gain.gain.exponentialRampToValueAtTime(0.001, startTime + duration)
  osc.start(startTime)
  osc.stop(startTime + duration)
}

export function playAlertSound(severity: AlertSeverity): void {
  try {
    const AudioCtxCtor =
      window.AudioContext ??
      (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext
    if (!AudioCtxCtor) return
    const ctx = new AudioCtxCtor()
    const now = ctx.currentTime
    if (severity === 'CRITICAL') {
      beep(ctx, 880, now, 0.15)
      beep(ctx, 880, now + 0.2, 0.15)
    } else if (severity === 'WARNING') {
      beep(ctx, 660, now, 0.2)
    } else {
      beep(ctx, 440, now, 0.15)
    }
  } catch {
    // Web Audio API kullanilamiyor olabilir (ör. test ortami) - sessizce yoksay.
  }
}
