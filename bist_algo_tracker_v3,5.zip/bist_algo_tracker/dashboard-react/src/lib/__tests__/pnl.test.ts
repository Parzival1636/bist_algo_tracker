import { describe, expect, it } from 'vitest'
import { computeCashBalance, computeUnrealizedPnl, extractFilledLegs } from '../pnl'
import type { Order } from '../../types'

const baseOrder: Order = {
  order_id: 'o1',
  symbol: 'THYAO',
  side: 'BID',
  price: 100,
  lot: 500,
  status: 'FILLED',
  created_at: '2026-01-01T00:00:00Z',
  filled_lot: 500,
}

describe('extractFilledLegs', () => {
  it('sadece dolan (filled_lot > 0) emirleri bacak olarak alir', () => {
    const orders: Order[] = [
      baseOrder,
      { ...baseOrder, order_id: 'o2', filled_lot: 0, status: 'NEW' },
    ]
    expect(extractFilledLegs(orders)).toHaveLength(1)
    expect(extractFilledLegs(orders)[0].orderId).toBe('o1')
  })

  it('kismi dolumu da bacak olarak sayar', () => {
    const orders: Order[] = [{ ...baseOrder, filled_lot: 200, status: 'PARTIALLY_FILLED' }]
    expect(extractFilledLegs(orders)[0].lot).toBe(200)
  })
})

describe('computeCashBalance', () => {
  it('ALIS dolumu bakiyeyi azaltir', () => {
    const legs = extractFilledLegs([baseOrder]) // 100 * 500 = 50.000 maliyet
    expect(computeCashBalance(1_000_000, legs)).toBe(950_000)
  })

  it('SATIS dolumu bakiyeyi artirir', () => {
    const legs = extractFilledLegs([{ ...baseOrder, side: 'ASK' }])
    expect(computeCashBalance(1_000_000, legs)).toBe(1_050_000)
  })

  it('bos bacak listesinde bakiye degismez', () => {
    expect(computeCashBalance(500_000, [])).toBe(500_000)
  })

  it('birden fazla bacagi dogru toplar', () => {
    const legs = extractFilledLegs([
      baseOrder,
      { ...baseOrder, order_id: 'o2', side: 'ASK', price: 110, filled_lot: 100, lot: 100 },
    ])
    // -50.000 (alis) + 11.000 (satis) = -39.000
    expect(computeCashBalance(1_000_000, legs)).toBe(961_000)
  })
})

describe('computeUnrealizedPnl', () => {
  it('ALIS bacaginda fiyat yukselirse pozitif PnL uretir', () => {
    const legs = extractFilledLegs([baseOrder]) // giris 100, lot 500
    const pnl = computeUnrealizedPnl(legs, { THYAO: 105 })
    expect(pnl).toBe(2500) // (105-100)*500
  })

  it('SATIS bacaginda fiyat dusuyorsa pozitif PnL uretir', () => {
    const legs = extractFilledLegs([{ ...baseOrder, side: 'ASK' }])
    const pnl = computeUnrealizedPnl(legs, { THYAO: 95 })
    expect(pnl).toBe(2500) // -(95-100)*500
  })

  it('fiyati olmayan sembolu sessizce atlar (cokme yok)', () => {
    const legs = extractFilledLegs([baseOrder])
    expect(computeUnrealizedPnl(legs, {})).toBe(0)
  })

  it('birden fazla sembolu dogru toplar', () => {
    const legs = extractFilledLegs([
      baseOrder,
      { ...baseOrder, order_id: 'o2', symbol: 'GARAN', price: 50, filled_lot: 1000, lot: 1000 },
    ])
    const pnl = computeUnrealizedPnl(legs, { THYAO: 102, GARAN: 48 })
    // THYAO: (102-100)*500=1000 | GARAN (ALIS, fiyat dustu): (48-50)*1000=-2000
    expect(pnl).toBe(-1000)
  })
})
