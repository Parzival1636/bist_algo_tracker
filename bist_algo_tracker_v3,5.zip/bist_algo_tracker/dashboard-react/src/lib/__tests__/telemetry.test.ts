import { afterEach, describe, expect, it } from 'vitest'
import { _resetForTests, drainMessageCount, recordMessage } from '../telemetry'

afterEach(() => {
  _resetForTests()
})

describe('telemetry', () => {
  it('kaydedilen mesajlari sayar', () => {
    recordMessage()
    recordMessage()
    recordMessage()
    expect(drainMessageCount()).toBe(3)
  })

  it('drain sonrasi sayaci sifirlar', () => {
    recordMessage()
    drainMessageCount()
    expect(drainMessageCount()).toBe(0)
  })

  it('hic mesaj yokken 0 doner', () => {
    expect(drainMessageCount()).toBe(0)
  })
})
