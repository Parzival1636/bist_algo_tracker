import { describe, expect, it } from 'vitest'
import { ThrottleBuffer } from '../throttleBuffer'

describe('ThrottleBuffer', () => {
  it('push edilen ogeleri birikir', () => {
    const buf = new ThrottleBuffer<number>()
    buf.push(1)
    buf.push(2)
    buf.push(3)
    expect(buf.size).toBe(3)
  })

  it('drain birikmis tum ogeleri sirayla doner', () => {
    const buf = new ThrottleBuffer<number>()
    buf.push(1)
    buf.push(2)
    expect(buf.drain()).toEqual([1, 2])
  })

  it('drain sonrasi arabellek bosalir', () => {
    const buf = new ThrottleBuffer<number>()
    buf.push(1)
    buf.drain()
    expect(buf.size).toBe(0)
    expect(buf.drain()).toEqual([])
  })

  it('bos arabellekte drain [] doner, cokme yok', () => {
    const buf = new ThrottleBuffer<string>()
    expect(buf.drain()).toEqual([])
  })

  it('yuksek frekansli push sonrasi TEK drain hepsini yakalar (throttle senaryosu)', () => {
    const buf = new ThrottleBuffer<{ seq: number }>()
    for (let i = 0; i < 500; i++) buf.push({ seq: i })
    const drained = buf.drain()
    expect(drained).toHaveLength(500)
    expect(drained[0].seq).toBe(0)
    expect(drained[499].seq).toBe(499)
  })
})
