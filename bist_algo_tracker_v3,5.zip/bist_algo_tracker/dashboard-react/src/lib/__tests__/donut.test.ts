import { describe, expect, it } from 'vitest'
import { buildConicGradient, buildDonutSegments } from '../donut'

const entries = [
  { institution: 'BofA', buy_lot: 300, sell_lot: 0 },
  { institution: 'İş Yatırım', buy_lot: 100, sell_lot: 0 },
]
const palette = ['#111', '#222']

describe('buildDonutSegments', () => {
  it('yuzdeleri 100e tamamlar', () => {
    const segments = buildDonutSegments(entries, palette)
    const total = segments.reduce((sum, s) => sum + s.percent, 0)
    expect(total).toBeCloseTo(100, 6)
  })

  it('degerle orantili yuzde hesaplar', () => {
    const segments = buildDonutSegments(entries, palette)
    expect(segments[0].percent).toBeCloseTo(75, 4)
    expect(segments[1].percent).toBeCloseTo(25, 4)
  })

  it('paletten sirayla renk atar', () => {
    const segments = buildDonutSegments(entries, palette)
    expect(segments[0].color).toBe('#111')
    expect(segments[1].color).toBe('#222')
  })

  it('bos girdide bos dizi doner', () => {
    expect(buildDonutSegments([], palette)).toEqual([])
  })
})

describe('buildConicGradient', () => {
  it('kumulatif yuzde araliklari uretir', () => {
    const segments = buildDonutSegments(entries, palette)
    const gradient = buildConicGradient(segments)
    expect(gradient).toBe('conic-gradient(#111 0% 75%, #222 75% 100%)')
  })

  it('bos segmentte transparent doner', () => {
    expect(buildConicGradient([])).toBe('transparent')
  })
})
