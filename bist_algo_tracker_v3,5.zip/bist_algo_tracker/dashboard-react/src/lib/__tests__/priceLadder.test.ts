import { describe, expect, it } from 'vitest'
import { bestAsk, bestBid, buildLadderRows, intensityFor, midPrice, roundPrice } from '../priceLadder'

const sampleBook = {
  bids: [
    { price: 99.0, lot: 950 },
    { price: 98.5, lot: 100 },
  ],
  asks: [
    { price: 100.0, lot: 50 },
    { price: 100.5, lot: 500 },
  ],
}

describe('buildLadderRows', () => {
  it('bid ve ask satirlarini birlikte doner', () => {
    const rows = buildLadderRows(sampleBook)
    expect(rows).toHaveLength(4)
    expect(rows.filter((r) => r.side === 'BID')).toHaveLength(2)
    expect(rows.filter((r) => r.side === 'ASK')).toHaveLength(2)
  })

  it('en buyuk lota gore yogunlugu 1.0 olarak normalize eder', () => {
    const rows = buildLadderRows(sampleBook)
    const maxRow = rows.find((r) => r.lot === 950)
    expect(maxRow?.intensity).toBe(1)
  })

  it('supheli fiyatlari isaretler', () => {
    const rows = buildLadderRows(sampleBook, { suspiciousPrices: new Set([99.0]) })
    const suspicious = rows.filter((r) => r.isSuspicious)
    expect(suspicious).toHaveLength(1)
    expect(suspicious[0].price).toBe(99.0)
  })

  it('maxLevels ile kademe sayisini sinirlar', () => {
    const bigBook = {
      bids: Array.from({ length: 20 }, (_, i) => ({ price: 100 - i, lot: 100 })),
      asks: Array.from({ length: 20 }, (_, i) => ({ price: 101 + i, lot: 100 })),
    }
    const rows = buildLadderRows(bigBook, { maxLevels: 5 })
    expect(rows).toHaveLength(10)
  })

  it('bos kitapta cokmeden bos dizi doner', () => {
    expect(buildLadderRows({ bids: [], asks: [] })).toEqual([])
  })
})

describe('intensityFor', () => {
  it('maxLot 0 iken 0 doner (sifira bolme yok)', () => {
    expect(intensityFor(100, 0)).toBe(0)
  })
  it('lot maxLot ile ayniysa 1 doner', () => {
    expect(intensityFor(500, 500)).toBe(1)
  })
})

describe('bestBid / bestAsk / midPrice', () => {
  it('en iyi bid en yuksek fiyatlidir', () => {
    expect(bestBid(sampleBook)?.price).toBe(99.0)
  })
  it('en iyi ask en dusuk fiyatlidir', () => {
    expect(bestAsk(sampleBook)?.price).toBe(100.0)
  })
  it('orta fiyati dogru hesaplar', () => {
    expect(midPrice(sampleBook)).toBeCloseTo(99.5)
  })
  it('bos tarafta null doner', () => {
    expect(bestBid({ bids: [] })).toBeNull()
    expect(midPrice({ bids: [], asks: sampleBook.asks })).toBeNull()
  })
})

describe('roundPrice', () => {
  it('iki ondalik basamaga yuvarlar', () => {
    expect(roundPrice(99.006)).toBeCloseTo(99.01, 2)
    expect(roundPrice(99.004)).toBeCloseTo(99.0, 2)
    expect(roundPrice(100)).toBe(100)
  })
})
