/**
 * lib/priceLadder.ts
 * DOM (Depth of Market) ladder icin saf mantik: kademeleri fiyata gore
 * siralar, en buyuk lota gore renk yogunlugu (0..1) hesaplar, supheli
 * (SAHTE_LİKİDİTE) fiyatlari isaretler. Bileşenden AYRI tutulur ki
 * vitest ile bagimsiz test edilebilsin.
 */
import type { OrderBookLevel, OrderBookSnapshot, Side } from '../types'

export interface LadderRow {
  side: Side
  price: number
  lot: number
  intensity: number // 0..1 - bu ladder'daki en buyuk lota gore normalize
  isSuspicious: boolean
}

export function roundPrice(price: number): number {
  return Math.round(price * 100) / 100
}

export function intensityFor(lot: number, maxLot: number): number {
  if (maxLot <= 0) return 0
  return Math.max(0, Math.min(1, lot / maxLot))
}

export function buildLadderRows(
  book: Pick<OrderBookSnapshot, 'bids' | 'asks'>,
  opts: { maxLevels?: number; suspiciousPrices?: Set<number> } = {},
): LadderRow[] {
  const maxLevels = opts.maxLevels ?? 10
  const suspiciousPrices = opts.suspiciousPrices ?? new Set<number>()

  const sortDesc = (levels: OrderBookLevel[]) => [...levels].sort((a, b) => b.price - a.price)

  const asks = sortDesc(book.asks).slice(0, maxLevels)
  const bids = sortDesc(book.bids).slice(0, maxLevels)

  const allLots = [...asks, ...bids].map((l) => l.lot)
  const maxLot = allLots.length > 0 ? Math.max(...allLots) : 0

  const toRow = (side: Side) => (level: OrderBookLevel): LadderRow => ({
    side,
    price: level.price,
    lot: level.lot,
    intensity: intensityFor(level.lot, maxLot),
    isSuspicious: suspiciousPrices.has(roundPrice(level.price)),
  })

  // Asklar en yuksekten en dusuge (ustte), bidler en yuksekten (best bid, ortaya en yakin) en dusuge
  return [...asks.map(toRow('ASK')), ...bids.map(toRow('BID'))]
}

export function bestBid(book: Pick<OrderBookSnapshot, 'bids'>): OrderBookLevel | null {
  if (book.bids.length === 0) return null
  return [...book.bids].sort((a, b) => b.price - a.price)[0]
}

export function bestAsk(book: Pick<OrderBookSnapshot, 'asks'>): OrderBookLevel | null {
  if (book.asks.length === 0) return null
  return [...book.asks].sort((a, b) => a.price - b.price)[0]
}

export function midPrice(book: Pick<OrderBookSnapshot, 'bids' | 'asks'>): number | null {
  const bid = bestBid(book)
  const ask = bestAsk(book)
  if (bid === null || ask === null) return null
  return (bid.price + ask.price) / 2
}
