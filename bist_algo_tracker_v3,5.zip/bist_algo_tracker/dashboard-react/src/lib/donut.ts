/**
 * lib/donut.ts
 * AKD dagilim panelinin saf mantigi: CSS conic-gradient tabanli bir
 * donut icin dilim yuzdelerini hesaplar. SVG arc-path matematigine
 * gerek yok, boylece hem uygulamasi hem testi daha basit.
 */
import type { AKDEntry } from '../types'

export interface DonutSegment {
  institution: string
  value: number
  percent: number // 0..100
  color: string
}

export function buildDonutSegments(entries: AKDEntry[], palette: string[]): DonutSegment[] {
  if (entries.length === 0 || palette.length === 0) return []
  const values = entries.map((e) => Math.max(e.buy_lot, 0.0001))
  const total = values.reduce((a, b) => a + b, 0)
  return entries.map((entry, i) => ({
    institution: entry.institution,
    value: values[i],
    percent: total > 0 ? (values[i] / total) * 100 : 0,
    color: palette[i % palette.length],
  }))
}

export function buildConicGradient(segments: DonutSegment[]): string {
  if (segments.length === 0) return 'transparent'
  let cursor = 0
  const stops = segments.map((seg) => {
    const start = cursor
    const end = cursor + seg.percent
    cursor = end
    return `${seg.color} ${start}% ${end}%`
  })
  return `conic-gradient(${stops.join(', ')})`
}
