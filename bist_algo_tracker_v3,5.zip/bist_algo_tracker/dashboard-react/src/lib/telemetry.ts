/**
 * lib/telemetry.ts
 * v3: "Ağ Sağlığı / Telemetri" KPI'ı icin saf mantik. WebSocket mesaji
 * geldikce recordMessage() cagrilir (bu REACT STATE DEGILDIR - modul
 * seviyesinde adi bir sayac, boylece saniyede yuzlerce mesaj gelse bile
 * TEK BASINA render TETIKLEMEZ). drainMessageCount(), sayaci okuyup
 * sifirlayan bir "tick" fonksiyonudur - useMessagesPerSecond hook'u
 * bunu 1000ms'de bir cagirir.
 */
let messageCount = 0

export function recordMessage(): void {
  messageCount += 1
}

export function drainMessageCount(): number {
  const count = messageCount
  messageCount = 0
  return count
}

/** Testler arasi izolasyon icin - uygulama kodunda kullanilmaz. */
export function _resetForTests(): void {
  messageCount = 0
}
