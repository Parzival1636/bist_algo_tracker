/**
 * lib/pnl.ts
 * v3: KPI header'daki "Toplam Kasa" ve "Aktif PnL" için saf hesaplama
 * mantığı. Backend'de gerçek bir pozisyon/ledger sistemi YOK
 * (PaperBrokerAdapter yalnızca emir durumunu tutar) - bu yüzden en az
 * bir lotu DOLMUŞ her emir BAĞIMSIZ bir "bacak" (leg) olarak ele
 * alınır; aynı sembolde birden fazla dolum netlenmez/ortalanmaz. Bu,
 * bilinçli ve açıkça belgelenen bir sadeleştirmedir - bkz. README.
 */
import type { Order, Side } from '../types'

export interface FilledLeg {
  orderId: string
  symbol: string
  side: Side
  entryPrice: number
  lot: number
}

/** Order listesinden, en az bir lotu dolmuş olan bacakları çıkarır. */
export function extractFilledLegs(orders: Order[]): FilledLeg[] {
  return orders
    .filter((o) => o.filled_lot > 0)
    .map((o) => ({
      orderId: o.order_id,
      symbol: o.symbol,
      side: o.side,
      entryPrice: o.price,
      lot: o.filled_lot,
    }))
}

/**
 * Nakit bakiyesi: başlangıç bakiyesi - (ALIŞ dolumlarının maliyeti) +
 * (SATIŞ dolumlarının geliri). Basit nakit muhasebesi - kaldıraç,
 * komisyon veya vergi YOKTUR.
 */
export function computeCashBalance(startingBalance: number, filledLegs: FilledLeg[]): number {
  let balance = startingBalance
  for (const leg of filledLegs) {
    const notional = leg.entryPrice * leg.lot
    balance += leg.side === 'BID' ? -notional : notional
  }
  return balance
}

/**
 * Anlık (mark-to-market) kâr/zarar: her dolmuş bacak için, güncel orta
 * fiyat ile giriş fiyatı arasındaki fark × lot (yön işaretiyle).
 * symbolMidPrices'ta olmayan semboller hesaba katılmaz (henüz veri
 * gelmemiş olabilir - sessizce atlanır, hata fırlatmaz).
 */
export function computeUnrealizedPnl(filledLegs: FilledLeg[], symbolMidPrices: Record<string, number>): number {
  let pnl = 0
  for (const leg of filledLegs) {
    const mid = symbolMidPrices[leg.symbol]
    if (mid === undefined) continue
    const diff = mid - leg.entryPrice
    pnl += leg.side === 'BID' ? diff * leg.lot : -diff * leg.lot
  }
  return pnl
}
