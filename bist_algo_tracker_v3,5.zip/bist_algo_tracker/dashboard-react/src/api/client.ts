/**
 * api/client.ts - FastAPI backend icin REST istemcisi.
 * Dev sunucusunda /api -> http://localhost:8000 proxy'si vite.config.ts'de
 * tanimlidir (CORS derdi olmadan).
 */
import type { AKDSnapshot, HealthResponse, Order, OrderBookSnapshot, Side } from '../types'

const BASE = '/api'

async function getJson<T>(path: string): Promise<T> {
  const res = await fetch(`${BASE}${path}`)
  if (!res.ok) throw new Error(`GET ${path} -> ${res.status}`)
  return (await res.json()) as T
}

export function fetchHealth(): Promise<HealthResponse> {
  return getJson<HealthResponse>('/health')
}

export function fetchOrderbook(symbol: string): Promise<OrderBookSnapshot> {
  return getJson<OrderBookSnapshot>(`/orderbook/${symbol}`)
}

export function fetchAkd(symbol: string): Promise<AKDSnapshot> {
  return getJson<AKDSnapshot>(`/akd/${symbol}`)
}

export function fetchOrders(): Promise<Order[]> {
  return getJson<Order[]>('/orders')
}

/** v3: /orders'in aksine TÜM emirleri (FILLED/CANCELED dahil) döner - bkz. usePortfolioStore. */
export function fetchAllOrders(): Promise<Order[]> {
  return getJson<Order[]>('/orders/all')
}

export async function placeOrder(symbol: string, side: Side, price: number, lot: number): Promise<Order> {
  const res = await fetch(`${BASE}/orders`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ symbol, side, price, lot }),
  })
  if (!res.ok) throw new Error(`POST /orders -> ${res.status}`)
  return (await res.json()) as Order
}

export async function cancelOrder(orderId: string): Promise<boolean> {
  const res = await fetch(`${BASE}/orders/${orderId}/cancel`, { method: 'POST' })
  if (!res.ok) throw new Error(`POST /orders/${orderId}/cancel -> ${res.status}`)
  const body = (await res.json()) as { canceled: boolean }
  return body.canceled
}

export function wsUrl(path: string): string {
  const proto = window.location.protocol === 'https:' ? 'wss' : 'ws'
  // Dev'de vite proxy WS'i desteklemez varsayilan ayarla; dogrudan backend'e baglaniyoruz.
  const apiHost = import.meta.env.VITE_API_WS_HOST ?? 'localhost:8000'
  return `${proto}://${apiHost}${path}`
}
