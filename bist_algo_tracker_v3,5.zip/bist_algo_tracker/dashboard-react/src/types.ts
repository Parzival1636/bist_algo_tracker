/**
 * types.ts
 * api/main_fastapi.py ve models/schemas.py ile birebir eslesen tipler.
 */

export type Side = 'BID' | 'ASK'

export type OrderStatus = 'NEW' | 'PARTIALLY_FILLED' | 'FILLED' | 'CANCELED' | 'REPLACED'

export type AlertSeverity = 'INFO' | 'WARNING' | 'CRITICAL'

export type AlertType =
  | 'SAHTE_LİKİDİTE'
  | 'SPOOFING_UYARISI'
  | 'SPOOFING_ALARM'
  | 'KURUMSAL_YOGUNLASMA'
  | 'KARANLIK_ODA_OZETI'
  | 'LAYERING_ALARM'
  | 'ICEBERG_TESPIT'
  | 'CAPRAZ_SEMBOL_KORELASYON'

export interface OrderBookLevel {
  price: number
  lot: number
  order_count?: number | null
}

export interface OrderBookSnapshot {
  symbol: string
  timestamp: string
  bids: OrderBookLevel[]
  asks: OrderBookLevel[]
}

export interface AKDEntry {
  institution: string
  buy_lot: number
  sell_lot: number
  avg_cost?: number | null
}

export interface AKDSnapshot {
  symbol: string
  timestamp: string
  entries: AKDEntry[]
  is_end_of_day: boolean
}

export interface Alert {
  type: AlertType
  severity: AlertSeverity
  symbol: string
  message: string
  timestamp: string
  data: Record<string, number>
}

export interface Order {
  order_id: string
  symbol: string
  side: Side
  price: number
  lot: number
  status: OrderStatus
  created_at: string
  filled_lot: number
}

export interface HealthResponse {
  status: string
  demo_mode: boolean
  symbols: string[]
  message_bus: string
  dropped_messages: number
  queue_size: number
  db_breaker_state: string
  starting_balance_try: number
}
