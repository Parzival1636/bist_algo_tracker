"""models/schemas.py - BIST-AlgoTracker Ortak Veri Modelleri (Pydantic)"""
from __future__ import annotations

from datetime import datetime, timezone
from enum import Enum
from typing import Dict, List, Optional

from pydantic import BaseModel, Field


class Side(str, Enum):
    BID = "BID"
    ASK = "ASK"


class OrderStatus(str, Enum):
    NEW = "NEW"
    PARTIALLY_FILLED = "PARTIALLY_FILLED"
    FILLED = "FILLED"
    CANCELED = "CANCELED"
    REPLACED = "REPLACED"


class OrderBookLevel(BaseModel):
    price: float
    lot: float
    order_count: Optional[int] = None


class OrderBookSnapshot(BaseModel):
    symbol: str
    timestamp: datetime
    bids: List[OrderBookLevel] = Field(default_factory=list)
    asks: List[OrderBookLevel] = Field(default_factory=list)

    @property
    def best_bid(self) -> Optional[OrderBookLevel]:
        return self.bids[0] if self.bids else None

    @property
    def best_ask(self) -> Optional[OrderBookLevel]:
        return self.asks[0] if self.asks else None

    @property
    def mid_price(self) -> Optional[float]:
        if self.best_bid and self.best_ask:
            return (self.best_bid.price + self.best_ask.price) / 2
        return None

    @property
    def total_bid_volume(self) -> float:
        return sum(level.lot for level in self.bids)

    @property
    def total_ask_volume(self) -> float:
        return sum(level.lot for level in self.asks)


class AKDEntry(BaseModel):
    institution: str
    buy_lot: float = 0.0
    sell_lot: float = 0.0
    avg_cost: Optional[float] = None

    @property
    def net_lot(self) -> float:
        return self.buy_lot - self.sell_lot


class AKDSnapshot(BaseModel):
    symbol: str
    timestamp: datetime
    entries: List[AKDEntry] = Field(default_factory=list)
    is_end_of_day: bool = True


class Trade(BaseModel):
    symbol: str
    price: float
    lot: float
    timestamp: datetime
    side: Optional[Side] = None


class OrderEvent(BaseModel):
    symbol: str
    order_id: str
    side: Side
    price: float
    lot: float
    timestamp: datetime
    event_type: str


class AlertSeverity(str, Enum):
    INFO = "INFO"
    WARNING = "WARNING"
    CRITICAL = "CRITICAL"


class AlertType(str, Enum):
    SAHTE_LIKIDITE = "SAHTE_LİKİDİTE"
    SPOOFING_UYARISI = "SPOOFING_UYARISI"
    SPOOFING_ALARM = "SPOOFING_ALARM"
    KURUMSAL_YOGUNLASMA = "KURUMSAL_YOGUNLASMA"
    KARANLIK_ODA = "KARANLIK_ODA_OZETI"
    LAYERING = "LAYERING_ALARM"
    ICEBERG = "ICEBERG_TESPIT"
    CROSS_SYMBOL_KORELASYON = "CAPRAZ_SEMBOL_KORELASYON"


class Alert(BaseModel):
    type: AlertType
    severity: AlertSeverity
    symbol: str
    message: str
    timestamp: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    data: Dict[str, float] = Field(default_factory=dict)


class Order(BaseModel):
    order_id: str
    symbol: str
    side: Side
    price: float
    lot: float
    status: OrderStatus = OrderStatus.NEW
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    filled_lot: float = 0.0


class Position(BaseModel):
    symbol: str
    lot: float
    avg_cost: float
    entry_time: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    stop_price: float
    trailing_stop_price: Optional[float] = None
    highest_price_seen: Optional[float] = None
