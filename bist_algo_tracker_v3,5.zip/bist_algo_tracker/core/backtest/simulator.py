"""
core/backtest/simulator.py
Modul 7 v3.5: Backtest ve Simulasyon Motoru (Laboratuvar Ortami)

KRITIK KURAL - Look-ahead Bias (Gelecek Veri Sizintisi) Onleme:
Bu motor, olaylari KESINLIKLE zaman damgasi sirasina gore, BIRER BIRER
besler. Analitik/karar katmani, su an ISLENMEKTE OLAN olayin zaman
damgasindan SONRAKI hicbir veriye erisim IMKANI BULAMAZ, cunku:

  1) SimulationClock.now, yalnizca son islenen olayin zaman damgasidir
     ve MONOTON ARTAR (asla geriye gitmez).
  2) Olaylar GERIYE SICRARSA (kaynak veri kronolojik degilse) motor
     SESSIZCE YENIDEN SIRALAMAZ - bu, veri hazirlama asamasindaki
     ciddi bir hatayi (ornegin birden fazla kaynagin yanlis
     birlestirilmesi) gizlerdi. Bunun yerine LookAheadViolationError
     firlatir.
  3) Handler'lar (SpoofingDetector, FeatureExtractor, vb.) zaten
     SADECE kendilerine `on_*`/`extract()` cagrilariyla BESLENEN
     veriyi bilir - Simulator onlara asla "gelecekteki" bir olayi
     erken gostermez. Bu, ayri bir "veri sizdirmama" mekanizmasi
     DEGIL, mimarinin dogal bir sonucudur: gelecegi gormek icin
     handler'in gelecege bir REFERANSI olmasi gerekirdi ve boyle bir
     referans hic verilmez.

Gercek "geçmiş derinlik" (Duzey 2 emir defteri) veya OHLCV verisi,
onceden kaydedilmis bir JSON log'undan (core/backtest/historical_player.py
- Simulator'dan BAGIMSIZ, v1'den beri var) veya db/timeseries_client.py'de
saklanan OHLCV barlarindan (v3.5 - bkz. o modul) beslenir.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Dict, Iterable, Optional, Protocol


class LookAheadViolationError(ValueError):
    """Olaylar zaman damgasina gore SIRALI degilse (geriye sicrama) firlatilir."""


@dataclass
class SimulationClock:
    """
    Simulasyonun 'su an'ini tutar. SADECE Simulator._advance_to tarafindan
    ilerletilir - handler'lar bunu OKUYABILIR ama YAZAMAZ (public API'de
    ilerletme metodu yoktur).
    """

    _current_time: Optional[datetime] = field(default=None, init=False, repr=True)

    @property
    def now(self) -> Optional[datetime]:
        return self._current_time

    def _advance_to(self, ts: datetime) -> None:
        if self._current_time is not None and ts < self._current_time:
            raise LookAheadViolationError(
                f"Olay zaman damgasi geriye gidiyor: {ts.isoformat()} < mevcut "
                f"simulasyon zamani {self._current_time.isoformat()}. Backtest "
                f"verisi KESINLIKLE kronolojik sirada olmalidir (look-ahead "
                f"bias riski)."
            )
        self._current_time = ts


class MarketEventHandler(Protocol):
    """Simulator'un HER olay icin cagirdigi arayuz."""

    def on_simulated_event(self, clock: SimulationClock, message: Dict[str, Any]) -> None: ...


@dataclass
class SimulationStats:
    events_processed: int = 0
    start_time: Optional[datetime] = None
    end_time: Optional[datetime] = None

    @property
    def duration_seconds(self) -> Optional[float]:
        if self.start_time is None or self.end_time is None:
            return None
        return (self.end_time - self.start_time).total_seconds()


class Simulator:
    """
    Zaman-sirali olay dizisini ({"channel", "payload": {..., "timestamp": ...}}
    seklinde - SimulatedMarketDataSource/HistoricalDataPlayer ile AYNI sema)
    handler'a birer birer, artan zaman sirasinda besler.
    """

    def __init__(self, handler: MarketEventHandler) -> None:
        self.handler = handler
        self.clock = SimulationClock()
        self.stats = SimulationStats()

    def run(self, events: Iterable[Dict[str, Any]]) -> SimulationStats:
        for message in events:
            ts = self._extract_timestamp(message)
            self.clock._advance_to(ts)  # LookAheadViolationError -> siralama ihlali

            if self.stats.start_time is None:
                self.stats.start_time = ts
            self.stats.end_time = ts
            self.stats.events_processed += 1

            self.handler.on_simulated_event(self.clock, message)

        return self.stats

    @staticmethod
    def _extract_timestamp(message: Dict[str, Any]) -> datetime:
        payload = message.get("payload", {})
        raw_ts = payload.get("timestamp")
        if raw_ts is None:
            raise ValueError(f"Olayda 'timestamp' alani yok: {message!r}")
        if isinstance(raw_ts, datetime):
            return raw_ts if raw_ts.tzinfo else raw_ts.replace(tzinfo=timezone.utc)
        return datetime.fromisoformat(raw_ts)
