"""
core/backtest/analytics_handler.py
Modul 7 v3.5: v1/v2 analitik motorlarini (SpoofingDetector, InstitutionalTracker,
LayeringDetector, IcebergDetector) Simulator.MarketEventHandler arayuzune
uyarlayan somut implementasyon. Boylece backtest, CANLI sistemle (bkz.
api/main_fastapi.py) AYNI tespit mantigini calistirir - iki ayri kod
yolu (ve iki ayri hata kaynagi) OLUSTURULMAZ.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List

from core.analytics.iceberg_detector import IcebergDetector
from core.analytics.institutional import InstitutionalTracker
from core.analytics.layering_detector import LayeringDetector
from core.analytics.spoofing_detector import SpoofingDetector
from core.backtest.simulator import SimulationClock
from core.ingestion.data_parser import parse_akd, parse_order_book, parse_order_event
from models.schemas import Alert, AlertSeverity, AlertType


@dataclass
class AnalyticsEngineHandler:
    symbols: List[str]
    detectors: Dict[str, SpoofingDetector] = field(init=False)
    institutional: Dict[str, InstitutionalTracker] = field(init=False)
    layering: Dict[str, LayeringDetector] = field(init=False)
    iceberg: Dict[str, IcebergDetector] = field(init=False)
    alerts: List[Alert] = field(default_factory=list, init=False)

    def __post_init__(self) -> None:
        self.detectors = {s: SpoofingDetector(s) for s in self.symbols}
        self.institutional = {s: InstitutionalTracker(symbol=s) for s in self.symbols}
        self.layering = {s: LayeringDetector() for s in self.symbols}
        self.iceberg = {s: IcebergDetector() for s in self.symbols}

    def on_simulated_event(self, clock: SimulationClock, message: Dict[str, Any]) -> None:
        channel = message.get("channel")
        payload = message.get("payload", {})
        symbol = payload.get("symbol")
        if symbol is None:
            return

        detector = self.detectors.setdefault(symbol, SpoofingDetector(symbol))
        tracker = self.institutional.setdefault(symbol, InstitutionalTracker(symbol=symbol))
        layering = self.layering.setdefault(symbol, LayeringDetector())
        iceberg = self.iceberg.setdefault(symbol, IcebergDetector())

        if channel == "order_book":
            book = parse_order_book(payload)
            self.alerts.extend(detector.on_book_update(book))

        elif channel == "order_event":
            event = parse_order_event(payload)
            self.alerts.extend(detector.on_order_event(event))

            ts = clock.now.timestamp() if clock.now else 0.0
            if event.event_type == "CANCELED":
                levels = layering.on_order_canceled(event.price, event.lot, ts)
                if levels:
                    self.alerts.append(Alert(
                        type=AlertType.LAYERING, severity=AlertSeverity.CRITICAL, symbol=symbol,
                        message=f"[Backtest] {symbol} - {len(levels)} kademede eszamanli iptal (LAYERING).",
                        data={"level_count": float(len(levels))},
                    ))
            elif event.event_type == "EXECUTED":
                if iceberg.on_execution(event.price, event.lot):
                    self.alerts.append(Alert(
                        type=AlertType.ICEBERG, severity=AlertSeverity.INFO, symbol=symbol,
                        message=f"[Backtest] {symbol} - {event.price:g} kademesinde olasi ICEBERG.",
                        data={"price": event.price},
                    ))

        elif channel == "akd":
            akd = parse_akd(payload)
            inst_alert = tracker.ingest(akd)
            if inst_alert:
                self.alerts.append(inst_alert)
