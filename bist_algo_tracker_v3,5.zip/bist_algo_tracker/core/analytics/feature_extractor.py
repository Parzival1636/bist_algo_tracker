"""
core/analytics/feature_extractor.py
Modul 2/5 v3.5: Ozellik Cikarimi (Feature Engineering)

OBI, z-score sapmalari ve hacim ivmesi gibi ham sinyalleri, otonom karar
motorunun (core/execution/autonomous_engine.py) tuketebilecegi TEMIZ,
STANDARTLASTIRILMIS bir vektore donusturur.

ONEMLI - Sorumluluk Ayrimi: Bu sinif KARAR VERMEZ, sadece SINYAL URETIR.
Sinyalden emire giden karar (ve TUM risk kapilari) autonomous_engine.py'de
yasar - boylece "hangi veri neyi tetikliyor" ile "ne zaman gercekten emir
gonderiliyor" birbirinden net bicimde ayrilmis olur (tek sorumluluk ilkesi,
aynı zamanda denetlenebilirlik/audit icin de onemlidir).
"""
from __future__ import annotations

from collections import deque
from dataclasses import dataclass
from typing import Deque, Optional

from core.analytics.adaptive_thresholds import AdaptiveThresholdTracker
from core.analytics.metrics import compute_obi


@dataclass(frozen=True)
class FeatureVector:
    """Tek bir andaki, standartlastirilmis sinyal kumesi. Degismezdir
    (frozen) - uretildikten sonra hicbir yerde SESSIZCE degistirilemez,
    bu da autonomous_engine.py'deki karar denetimini guvenilir kilar."""

    symbol: str
    obi: float                        # ham OBI, [-1, +1]
    obi_zscore: Optional[float]       # sembolun KENDI tarihsel rejimine gore normalize (None = isinma asamasi)
    volume_momentum: Optional[float]  # son iki yari-pencere arasi hacim degisim orani (None = yetersiz veri)
    is_significant: bool              # OBI z-score esigi asildi mi (ozet bayrak)


class FeatureExtractor:
    """Sembol basina calisir - kendi adaptif esik takipcisini ve hacim
    penceresini tutar (SpoofingDetector ile ayni desen)."""

    def __init__(self, symbol: str, obi_z_threshold: float = 2.0, momentum_window: int = 10) -> None:
        if momentum_window < 2:
            raise ValueError("momentum_window >= 2 olmali")
        self.symbol = symbol
        self.obi_z_threshold = obi_z_threshold
        self._obi_adaptive = AdaptiveThresholdTracker(z_threshold=obi_z_threshold)
        self._volume_history: Deque[float] = deque(maxlen=momentum_window)

    def extract(self, bid_volume: float, ask_volume: float, traded_volume: float) -> FeatureVector:
        obi = compute_obi(bid_volume, ask_volume)
        obi_z = self._obi_adaptive.update(obi)

        self._volume_history.append(traded_volume)
        momentum = self._compute_volume_momentum()

        is_significant = obi_z is not None and abs(obi_z) > self.obi_z_threshold

        return FeatureVector(
            symbol=self.symbol,
            obi=obi,
            obi_zscore=obi_z,
            volume_momentum=momentum,
            is_significant=is_significant,
        )

    def _compute_volume_momentum(self) -> Optional[float]:
        if len(self._volume_history) < (self._volume_history.maxlen or 0):
            return None  # pencere henuz dolmadi - erken/yanlis sinyal uretme

        history = list(self._volume_history)
        half = len(history) // 2
        older, newer = history[:half], history[half:]
        older_avg = sum(older) / len(older)
        newer_avg = sum(newer) / len(newer)

        if older_avg == 0:
            return None  # sifira bolme + anlamsiz sonsuz-yuzde onlenir

        return (newer_avg - older_avg) / older_avg
