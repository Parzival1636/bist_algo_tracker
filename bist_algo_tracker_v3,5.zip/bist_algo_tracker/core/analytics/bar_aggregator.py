"""
core/analytics/bar_aggregator.py
Modul 7 v3.5: Canli gerceklesme (trade/EXECUTED) akisindan OHLCV bar
uretimi. Uretilen barlar db/timeseries_client.py'ye yazilir ve daha
sonra core/backtest/simulator.py ile "gecmis OHLCV verisi" olarak
kronolojik sirada geri oynatilabilir.

Bar, zaman penceresi KAPANDIGINDA (bir sonraki gerceklesme bir SONRAKI
pencereye ait oldugunda) TAMAMLANMIS olarak doner - boylece her bar
TAM OLARAK BIR KEZ, degismez halde uretilir (bkz. Simulator'un
kronolojik-sira garantisi ile uyum).
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from typing import Dict, Optional

from db.timeseries_client import OHLCVBar

_TIMEFRAME_SECONDS = {"1s": 1, "5s": 5, "1m": 60, "5m": 300, "15m": 900, "1h": 3600}


def _bucket_start(ts: datetime, timeframe_seconds: int) -> datetime:
    epoch = ts.timestamp()
    bucket_epoch = epoch - (epoch % timeframe_seconds)
    return datetime.fromtimestamp(bucket_epoch, tz=timezone.utc)


@dataclass
class _OpenBar:
    open: float
    high: float
    low: float
    close: float
    volume: float
    bucket_start: datetime


class BarAggregator:
    """Sembol basina calisir. on_trade() cagrildikca, pencere kapaninca
    TAMAMLANMIS bir OHLCVBar doner (aksi halde None)."""

    def __init__(self, symbol: str, timeframe: str = "1m") -> None:
        if timeframe not in _TIMEFRAME_SECONDS:
            raise ValueError(f"Desteklenmeyen zaman dilimi: {timeframe!r} (secenekler: {list(_TIMEFRAME_SECONDS)})")
        self.symbol = symbol
        self.timeframe = timeframe
        self._timeframe_seconds = _TIMEFRAME_SECONDS[timeframe]
        self._open_bar: Optional[_OpenBar] = None

    def on_trade(self, price: float, lot: float, ts: datetime) -> Optional[OHLCVBar]:
        bucket = _bucket_start(ts, self._timeframe_seconds)

        if self._open_bar is None:
            self._open_bar = _OpenBar(open=price, high=price, low=price, close=price, volume=lot, bucket_start=bucket)
            return None

        if bucket == self._open_bar.bucket_start:
            # AYNI pencere - mevcut bar'i GUNCELLE (henuz tamamlanmadi)
            self._open_bar.high = max(self._open_bar.high, price)
            self._open_bar.low = min(self._open_bar.low, price)
            self._open_bar.close = price
            self._open_bar.volume += lot
            return None

        if bucket < self._open_bar.bucket_start:
            raise ValueError(
                f"BarAggregator'a GERIYE giden bir zaman damgasi geldi ({ts.isoformat()}) - "
                "veri kronolojik sirada olmalidir (bkz. Simulator'un look-ahead korumasi)."
            )

        # YENI bir pencereye gecildi -> ONCEKI bar TAMAMLANDI, geri dondur
        completed = OHLCVBar(
            symbol=self.symbol, timeframe=self.timeframe,
            open=self._open_bar.open, high=self._open_bar.high, low=self._open_bar.low,
            close=self._open_bar.close, volume=self._open_bar.volume, timestamp=self._open_bar.bucket_start,
        )
        self._open_bar = _OpenBar(open=price, high=price, low=price, close=price, volume=lot, bucket_start=bucket)
        return completed

    def flush(self) -> Optional[OHLCVBar]:
        """Akis sona erdiginde, henuz KAPANMAMIS son bar'i (varsa) zorla tamamlar."""
        if self._open_bar is None:
            return None
        completed = OHLCVBar(
            symbol=self.symbol, timeframe=self.timeframe,
            open=self._open_bar.open, high=self._open_bar.high, low=self._open_bar.low,
            close=self._open_bar.close, volume=self._open_bar.volume, timestamp=self._open_bar.bucket_start,
        )
        self._open_bar = None
        return completed
