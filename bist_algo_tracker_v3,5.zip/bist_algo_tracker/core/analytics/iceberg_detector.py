"""core/analytics/iceberg_detector.py - Modul 2 v2: Iceberg (Buzdagi) Emir Tespiti"""
from __future__ import annotations

import statistics
from collections import deque
from typing import Deque, Dict


class IcebergDetector:
    def __init__(self, min_repeats: int = 4, max_relative_stdev: float = 0.15, lookback: int = 8) -> None:
        if min_repeats < 2:
            raise ValueError("min_repeats >= 2 olmali")
        self.min_repeats = min_repeats
        self.max_relative_stdev = max_relative_stdev
        self.lookback = lookback
        self._executions: Dict[float, Deque[float]] = {}

    def on_execution(self, price: float, lot: float) -> bool:
        window = self._executions.setdefault(price, deque(maxlen=self.lookback))
        window.append(lot)
        if len(window) < self.min_repeats:
            return False
        mean = statistics.fmean(window)
        if mean <= 0:
            return False
        relative_stdev = statistics.pstdev(window) / mean
        return relative_stdev <= self.max_relative_stdev
