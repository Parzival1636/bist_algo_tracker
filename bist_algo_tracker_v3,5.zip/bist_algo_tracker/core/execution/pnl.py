"""
core/execution/pnl.py
v3.5: Basit Spot PnL / bakiye hesaplari (backend tarafi).

Frontend'deki dashboard-react/src/lib/pnl.ts ile AYNI is kuralini
uygular: Nema (faiz), tasima maliyeti veya karmasik muhasebe YOKTUR
(kullanici talebi - Kirmizi Cizgi #1). Backend'de bu, otonom karar
motorunun (core/execution/autonomous_engine.py) risk kontrolu icin
GUNCEL portfoy degerini/mevcut sembol maruziyetini hesaplamak amaciyla
kullanilir - boylece %20 pozisyon limiti, statik bir baslangic
degerine degil GERCEK, guncel duruma gore uygulanir.
"""
from __future__ import annotations

from typing import Iterable

from models.schemas import Order, Side


def compute_cash_balance(starting_balance: float, orders: Iterable[Order]) -> float:
    """Baslangic bakiyesi ∓ dolan emirlerin nakit etkisi (basit, kaldıraçsız)."""
    balance = starting_balance
    for order in orders:
        if order.filled_lot <= 0:
            continue
        notional = order.price * order.filled_lot
        balance += -notional if order.side == Side.BID else notional
    return balance


def compute_symbol_exposure(symbol: str, orders: Iterable[Order]) -> float:
    """Bir sembolde, dolmus emirlerin toplam (mutlak) nominal degeri."""
    return sum(
        order.price * order.filled_lot
        for order in orders
        if order.symbol == symbol and order.filled_lot > 0
    )
