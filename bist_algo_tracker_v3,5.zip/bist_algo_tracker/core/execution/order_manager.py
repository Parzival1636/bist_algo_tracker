"""
core/execution/order_manager.py - Modul 4: Akilli Emir Yonetimi

ONEMLI: Gercek bir araci kurum entegrasyonu bilincli olarak yazilmadi.
PaperBrokerAdapter guvenli varsayilandir.
"""
from __future__ import annotations

import uuid
from abc import ABC, abstractmethod
from typing import Dict, List, Optional

from models.schemas import Order, OrderBookSnapshot, OrderStatus, Side


class BrokerAdapter(ABC):
    @abstractmethod
    async def place_order(self, symbol: str, side: Side, price: float, lot: float) -> Order: ...

    @abstractmethod
    async def cancel_order(self, order_id: str) -> bool: ...

    @abstractmethod
    async def replace_order(self, order_id: str, new_price: float) -> Order: ...

    @abstractmethod
    async def get_open_orders(self) -> List[Order]: ...


class PaperBrokerAdapter(BrokerAdapter):
    def __init__(self) -> None:
        self._orders: Dict[str, Order] = {}

    async def place_order(self, symbol: str, side: Side, price: float, lot: float) -> Order:
        order = Order(order_id=str(uuid.uuid4()), symbol=symbol, side=side, price=price, lot=lot)
        self._orders[order.order_id] = order
        return order

    async def cancel_order(self, order_id: str) -> bool:
        order = self._orders.get(order_id)
        if order is None or order.status in (OrderStatus.FILLED, OrderStatus.CANCELED):
            return False
        order.status = OrderStatus.CANCELED
        return True

    async def replace_order(self, order_id: str, new_price: float) -> Order:
        old = self._orders.get(order_id)
        if old is None:
            raise KeyError(f"Emir bulunamadi: {order_id}")
        await self.cancel_order(order_id)
        new_order = await self.place_order(old.symbol, old.side, new_price, old.lot - old.filled_lot)
        new_order.status = OrderStatus.REPLACED
        return new_order

    async def get_open_orders(self) -> List[Order]:
        return [o for o in self._orders.values() if o.status in (OrderStatus.NEW, OrderStatus.PARTIALLY_FILLED)]

    async def get_all_orders(self) -> List[Order]:
        """
        v3: KPI header'daki 'Toplam Kasa' / 'Aktif PnL' hesaplarinin GERCEK
        verilerle calisabilmesi icin eklendi - get_open_orders() FILLED/
        CANCELED emirleri gizler, bu metot TUMUNU (durum farketmeksizin)
        doner. Boylece frontend, dolan emirleri (positions) gorup canli
        mark-to-market PnL hesaplayabilir.
        """
        return list(self._orders.values())

    def simulate_fill(self, order_id: str, lot: float) -> Optional[Order]:
        order = self._orders.get(order_id)
        if order is None:
            return None
        order.filled_lot = min(order.lot, order.filled_lot + lot)
        order.status = OrderStatus.FILLED if order.filled_lot >= order.lot else OrderStatus.PARTIALLY_FILLED
        return order


def should_requeue(order: Order, book: OrderBookSnapshot, competitor_multiplier: float = 1.5) -> bool:
    levels = book.bids if order.side == Side.BID else book.asks
    for level in levels:
        if order.side == Side.BID:
            is_ahead_or_equal = level.price >= order.price
        else:
            is_ahead_or_equal = level.price <= order.price
        if is_ahead_or_equal and level.lot >= order.lot * competitor_multiplier:
            return True
    return False


class OrderManager:
    def __init__(self, broker: BrokerAdapter) -> None:
        self.broker = broker

    async def maybe_requeue(self, order: Order, book: OrderBookSnapshot) -> Optional[Order]:
        if not should_requeue(order, book):
            return None
        if order.side == Side.BID and book.best_bid:
            new_price = book.best_bid.price
        elif order.side == Side.ASK and book.best_ask:
            new_price = book.best_ask.price
        else:
            new_price = order.price
        return await self.broker.replace_order(order.order_id, new_price)
