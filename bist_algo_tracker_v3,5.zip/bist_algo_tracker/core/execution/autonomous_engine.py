"""
core/execution/autonomous_engine.py
Modul 4/5 v3.5: Otonom Tetikleyici - Sinyalden Emire

KIDEMLI MIMAR NOTU - GUVENLIK MIMARISI:
Bu, "sinyalden emire otonom akisin ISKELETI" olarak istenmisti. Iskelet
budur: boru hatti doğru VE guvenli kurulmustur. Gercek paraya/gercek
araci kuruma baglanmak icin (a) settings.autonomous_trading_enabled=True
yapmak VE (b) gercek bir BrokerAdapter implementasyonu yazmak (bilerek
YAZILMADI, bkz. core/execution/order_manager.py) sizin ayri, bilincli
adimlariniz olmalidir.

Otonom bir emir GONDERILMEDEN once TUM asagidaki kapilardan GECMELIDIR
(hicbiri atlanamaz - kod yolu boyle kurgulanmistir):
  1) Global "kill switch": settings.autonomous_trading_enabled
  2) DailyLossGuard: basit SPOT PnL'e dayali gunluk zarar siniri (Nema/
     tasima maliyeti/karmasik muhasebe YOK - kullanici talebi geregi)
  3) OrderRateLimiter: dakikada azami emir sayisi (bir hata/geri
     besleme dongusunun emir spamine donusmesini onler)
  4) RiskEngine.can_open_position: mevcut %20 pozisyon limiti (v1'den)

KARAR MANTIGI KASITLI OLARAK BASIT VE ACIKLANABILIR (kara kutu degil):
  obi_zscore > +esik VE hacim ivmesi > 0  -> ALIS sinyali
  obi_zscore < -esik VE hacim ivmesi < 0  -> SATIS sinyali
  Aksi TUM durumlarda                      -> islem YOK
"""
from __future__ import annotations

import time
from collections import deque
from dataclasses import dataclass, field
from datetime import date, datetime, timezone
from typing import Deque, Optional

from config.logging_config import get_logger
from core.analytics.feature_extractor import FeatureVector
from core.execution.order_manager import BrokerAdapter
from core.execution.risk_engine import RiskEngine
from models.schemas import Order, OrderBookSnapshot, Side

logger = get_logger(__name__)


@dataclass
class DailyLossGuard:
    """
    Basit, GUNLUK spot PnL'e dayali zarar siniri. Nema/tasima maliyeti/
    komisyon HESABA KATILMAZ (kullanici talebi - Kirmizi Cizgi #1).
    Limit asilirsa is_halted() True doner ve YENI GUN baslayana kadar
    (veya manuel reset_for_test/reset ile) OYLE KALIR.
    """

    max_daily_loss: float
    _realized_pnl_today: float = field(default=0.0, init=False)
    _day: Optional[date] = field(default=None, init=False)

    def record_fill_pnl(self, pnl_delta: float, today: Optional[date] = None) -> None:
        today = today or datetime.now(timezone.utc).date()
        if self._day != today:
            self._day = today
            self._realized_pnl_today = 0.0
        self._realized_pnl_today += pnl_delta

    def is_halted(self, today: Optional[date] = None) -> bool:
        today = today or datetime.now(timezone.utc).date()
        if self._day != today:
            return False  # yeni gun - henuz kayitli bir zarar yok
        return self._realized_pnl_today <= -abs(self.max_daily_loss)

    def realized_pnl_today(self, today: Optional[date] = None) -> float:
        today = today or datetime.now(timezone.utc).date()
        if self._day != today:
            return 0.0
        return self._realized_pnl_today


class OrderRateLimiter:
    """Kayan 60 saniyelik pencerede azami emir sayisi - emir-spam korumasi."""

    def __init__(self, max_orders_per_minute: int) -> None:
        if max_orders_per_minute < 1:
            raise ValueError("max_orders_per_minute >= 1 olmali")
        self.max_orders_per_minute = max_orders_per_minute
        self._timestamps: Deque[float] = deque()

    def allow(self, now: float) -> bool:
        while self._timestamps and now - self._timestamps[0] > 60:
            self._timestamps.popleft()
        if len(self._timestamps) >= self.max_orders_per_minute:
            return False
        self._timestamps.append(now)
        return True


@dataclass(frozen=True)
class AutonomousDecision:
    """Denetlenebilirlik icin: HER degerlendirmenin SONUCUNU (emir
    gonderilmese bile NEDEN gonderilmedigini) tasir."""

    symbol: str
    action: str  # "ORDER_PLACED" | "NO_SIGNAL" | "DISABLED" | "DAILY_LOSS_HALTED" | "RATE_LIMITED" | "RISK_REJECTED" | "NO_PRICE"
    order: Optional[Order] = None
    signal_side: Optional[Side] = None


class AutonomousDecisionEngine:
    def __init__(
        self,
        broker: BrokerAdapter,
        risk_engine: RiskEngine,
        daily_loss_guard: DailyLossGuard,
        rate_limiter: OrderRateLimiter,
        enabled: bool,
        default_lot: float = 100.0,
        obi_z_threshold: float = 2.0,
    ) -> None:
        self.broker = broker
        self.risk_engine = risk_engine
        self.daily_loss_guard = daily_loss_guard
        self.rate_limiter = rate_limiter
        self.enabled = enabled
        self.default_lot = default_lot
        self.obi_z_threshold = obi_z_threshold

    async def on_feature_vector(
        self,
        features: FeatureVector,
        book: OrderBookSnapshot,
        portfolio_value: float,
        existing_symbol_value: float = 0.0,
        now: Optional[float] = None,
    ) -> AutonomousDecision:
        """
        TEK giris noktasi - her cagri TAM OLARAK bir AutonomousDecision
        doner (emir gonderilse de gonderilmese de NEDENI ile birlikte).
        """
        if not self.enabled:
            return AutonomousDecision(symbol=features.symbol, action="DISABLED")

        if self.daily_loss_guard.is_halted():
            logger.warning("Gunluk zarar limiti asildi - otonom emir ENGELLENDI (%s).", features.symbol)
            return AutonomousDecision(symbol=features.symbol, action="DAILY_LOSS_HALTED")

        signal_side = self._decide_signal(features)
        if signal_side is None:
            return AutonomousDecision(symbol=features.symbol, action="NO_SIGNAL")

        if not self.rate_limiter.allow(now if now is not None else time.time()):
            logger.warning("Emir hiz siniri asildi - otonom emir ERTELENDI (%s).", features.symbol)
            return AutonomousDecision(symbol=features.symbol, action="RATE_LIMITED", signal_side=signal_side)

        price_level = book.best_ask if signal_side == Side.BID else book.best_bid
        if price_level is None:
            return AutonomousDecision(symbol=features.symbol, action="NO_PRICE", signal_side=signal_side)

        proposed_value = price_level.price * self.default_lot
        if not self.risk_engine.can_open_position(proposed_value, portfolio_value, existing_symbol_value):
            logger.info("Risk motoru otonom pozisyonu REDDETTI (%s, tutar=%.2f).", features.symbol, proposed_value)
            return AutonomousDecision(symbol=features.symbol, action="RISK_REJECTED", signal_side=signal_side)

        order = await self.broker.place_order(features.symbol, signal_side, price_level.price, self.default_lot)
        logger.info(
            "OTONOM EMIR gonderildi: %s %s %.0f lot @ %.2f (obi_z=%.2f, momentum=%.3f)",
            features.symbol, signal_side.value, self.default_lot, price_level.price,
            features.obi_zscore or 0.0, features.volume_momentum or 0.0,
        )
        return AutonomousDecision(symbol=features.symbol, action="ORDER_PLACED", order=order, signal_side=signal_side)

    def _decide_signal(self, features: FeatureVector) -> Optional[Side]:
        if features.obi_zscore is None or features.volume_momentum is None:
            return None
        if features.obi_zscore > self.obi_z_threshold and features.volume_momentum > 0:
            return Side.BID
        if features.obi_zscore < -self.obi_z_threshold and features.volume_momentum < 0:
            return Side.ASK
        return None
