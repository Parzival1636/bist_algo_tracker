"""
core/ai_rag/kap_sentiment.py
Modul 5: RAG ve LLM Strateji Katmani - KAP Haberleri Sentiment Analizi
"""
from __future__ import annotations

from enum import Enum
from typing import Optional


class SentimentLabel(str, Enum):
    POZITIF = "Pozitif"
    NOTR = "Nötr"
    NEGATIF = "Negatif"


POSITIVE_TERMS = [
    "kâr artışı", "kar artışı", "rekor", "temettü", "büyüme", "ihracat artışı",
    "yeni sözleşme", "stratejik ortaklık", "hedef fiyat yükseltildi",
    "kapasite artışı", "teşvik", "başarıyla tamamla",
]
NEGATIVE_TERMS = [
    "zarar", "iflas", "soruşturma", "üretim durdu", "dava açıldı",
    "ceza", "temettü iptal", "hedef fiyat düşürüldü", "iflas erteleme",
    "borç yapılandırma", "kredi notu düşürüldü", "grev",
]


class LexiconSentimentScorer:
    def score(self, text: str) -> SentimentLabel:
        lowered = text.lower()
        pos_hits = sum(1 for term in POSITIVE_TERMS if term in lowered)
        neg_hits = sum(1 for term in NEGATIVE_TERMS if term in lowered)
        if pos_hits > neg_hits:
            return SentimentLabel.POZITIF
        if neg_hits > pos_hits:
            return SentimentLabel.NEGATIF
        return SentimentLabel.NOTR


class LLMSentimentScorer:
    def __init__(self, api_key: str, model: str = "claude-sonnet-4-6") -> None:
        self.api_key = api_key
        self.model = model

    def score(self, text: str) -> SentimentLabel:
        try:
            import anthropic
        except ImportError as exc:
            raise RuntimeError("LLMSentimentScorer icin 'anthropic' paketi gerekli: pip install anthropic") from exc

        client = anthropic.Anthropic(api_key=self.api_key)
        prompt = (
            "Asagidaki KAP (Kamuyu Aydinlatma Platformu) duyurusunu sadece "
            "'Pozitif', 'Nötr' veya 'Negatif' kelimelerinden biriyle etiketle, "
            f"baska hicbir sey yazma.\n\nDuyuru:\n{text}"
        )
        response = client.messages.create(
            model=self.model, max_tokens=10,
            messages=[{"role": "user", "content": prompt}],
        )
        raw = response.content[0].text.strip() if response.content else ""
        for label in SentimentLabel:
            if label.value.lower() in raw.lower():
                return label
        return SentimentLabel.NOTR


def get_default_scorer(use_llm: bool = False, api_key: Optional[str] = None):
    if use_llm and api_key:
        return LLMSentimentScorer(api_key=api_key)
    return LexiconSentimentScorer()
