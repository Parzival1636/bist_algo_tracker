"""
core/ai_rag/strategy_reasoner.py
Modul 5: RAG destekli strateji skorlayici
"""
from __future__ import annotations

from dataclasses import dataclass

from core.ai_rag.kap_sentiment import SentimentLabel

SENTIMENT_WEIGHT = 0.4
OBI_WEIGHT = 0.6

_SENTIMENT_SCORE = {
    SentimentLabel.POZITIF: 1.0,
    SentimentLabel.NOTR: 0.0,
    SentimentLabel.NEGATIF: -1.0,
}


@dataclass
class StrategyScore:
    value: float
    sentiment: SentimentLabel
    obi: float

    @property
    def bias_pct(self) -> float:
        return self.value * 0.20


def combine_signals(sentiment: SentimentLabel, obi: float) -> StrategyScore:
    obi_clamped = max(-1.0, min(1.0, obi))
    value = SENTIMENT_WEIGHT * _SENTIMENT_SCORE[sentiment] + OBI_WEIGHT * obi_clamped
    value = max(-1.0, min(1.0, value))
    return StrategyScore(value=value, sentiment=sentiment, obi=obi)
