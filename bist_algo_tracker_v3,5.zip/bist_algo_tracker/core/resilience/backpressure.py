"""
core/resilience/backpressure.py
Modul 1 v2 (Dayaniklilik): Sinirli boyutlu, "en eskiyi at" politikali kuyruk.

Veri saglayicidan gelen veri isleme hizindan daha hizli akarsa (burst -
orn. acilis/kapanis anlari), sinirsiz bir kuyruk bellek sismesine (OOM)
yol acar. BoundedDropOldestQueue, maxsize'a ulasildiginda EN ESKI
elemani atip yenisini kabul eder - sistem en guncel veriyi kaybetmeden
ayakta kalir.
"""
from __future__ import annotations

import asyncio
from typing import Generic, TypeVar

T = TypeVar("T")


class BoundedDropOldestQueue(Generic[T]):
    def __init__(self, maxsize: int) -> None:
        if maxsize <= 0:
            raise ValueError("maxsize > 0 olmali")
        self._queue: "asyncio.Queue[T]" = asyncio.Queue(maxsize=maxsize)
        self.dropped_count = 0

    async def put(self, item: T) -> None:
        if self._queue.full():
            try:
                self._queue.get_nowait()
                self.dropped_count += 1
            except asyncio.QueueEmpty:
                pass
        await self._queue.put(item)

    async def get(self) -> T:
        return await self._queue.get()

    def qsize(self) -> int:
        return self._queue.qsize()
