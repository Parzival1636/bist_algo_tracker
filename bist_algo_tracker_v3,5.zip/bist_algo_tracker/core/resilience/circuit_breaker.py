"""
core/resilience/circuit_breaker.py
Modul 1 v2 (Dayaniklilik): pybreaker uzerinden hazir bir devre kesici.

Downstream bir bagimlilik (DB, bildirim servisi) art arda hata verirse
devre "acilir" ve bir sure o bagimliliga hic istek gonderilmez - boylece
ana analiz/alarm akisi bloklanmaz. API pybreaker>=1.4 uzerinde dogrulandi
(fail_max, reset_timeout, listeners, name; call_async destegi mevcut).
"""
from __future__ import annotations

import pybreaker

from config.logging_config import get_logger

logger = get_logger(__name__)


class LoggingBreakerListener(pybreaker.CircuitBreakerListener):
    def state_change(self, cb, old_state, new_state) -> None:
        old_name = old_state.name if old_state is not None else "None"
        logger.warning("Circuit breaker '%s': %s -> %s", cb.name, old_name, new_state.name)


def make_breaker(name: str, fail_max: int = 3, reset_timeout: float = 10.0) -> pybreaker.CircuitBreaker:
    return pybreaker.CircuitBreaker(
        fail_max=fail_max,
        reset_timeout=reset_timeout,
        listeners=[LoggingBreakerListener()],
        name=name,
    )
