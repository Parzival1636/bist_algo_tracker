"""
core/ingestion/data_parser.py
Modul 1: Raw veriyi ic modellere donusturucu
"""
from __future__ import annotations

from datetime import datetime, timezone
from typing import Any, Dict

from models.schemas import AKDEntry, AKDSnapshot, OrderBookLevel, OrderBookSnapshot, OrderEvent, Side, Trade


def _parse_timestamp(value: Any) -> datetime:
    if isinstance(value, (int, float)):
        return datetime.fromtimestamp(value, tz=timezone.utc)
    if isinstance(value, str):
        return datetime.fromisoformat(value)
    if isinstance(value, datetime):
        return value
    raise ValueError(f"Bilinmeyen zaman damgasi formati: {value!r}")


def parse_order_book(raw: Dict[str, Any]) -> OrderBookSnapshot:
    return OrderBookSnapshot(
        symbol=raw["symbol"],
        timestamp=_parse_timestamp(raw["timestamp"]),
        bids=[OrderBookLevel(price=b["price"], lot=b["lot"], order_count=b.get("order_count")) for b in raw.get("bids", [])],
        asks=[OrderBookLevel(price=a["price"], lot=a["lot"], order_count=a.get("order_count")) for a in raw.get("asks", [])],
    )


def parse_akd(raw: Dict[str, Any]) -> AKDSnapshot:
    return AKDSnapshot(
        symbol=raw["symbol"],
        timestamp=_parse_timestamp(raw["timestamp"]),
        is_end_of_day=raw.get("is_end_of_day", True),
        entries=[
            AKDEntry(institution=e["institution"], buy_lot=e.get("buy_lot", 0.0), sell_lot=e.get("sell_lot", 0.0), avg_cost=e.get("avg_cost"))
            for e in raw.get("entries", [])
        ],
    )


def parse_trade(raw: Dict[str, Any]) -> Trade:
    return Trade(
        symbol=raw["symbol"], price=raw["price"], lot=raw["lot"],
        timestamp=_parse_timestamp(raw["timestamp"]),
        side=Side(raw["side"]) if raw.get("side") else None,
    )


def parse_order_event(raw: Dict[str, Any]) -> OrderEvent:
    return OrderEvent(
        symbol=raw["symbol"], order_id=raw["order_id"], side=Side(raw["side"]),
        price=raw["price"], lot=raw["lot"],
        timestamp=_parse_timestamp(raw["timestamp"]), event_type=raw["event_type"],
    )
